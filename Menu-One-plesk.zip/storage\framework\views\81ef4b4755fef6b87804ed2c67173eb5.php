<?php if(\App\Support\CaptchaPolicy::registrationEnabled()): ?>
<div class="register-overlay" id="registerOverlay" aria-hidden="true" hidden>
    <div class="register-panel" id="registerPanel" role="dialog" aria-modal="true" aria-labelledby="registerTitle">
        <button type="button" class="register-close" id="registerClose" aria-label="<?php echo e(__('menu.close')); ?>">
            <i class="fa fa-times"></i>
        </button>

        <div class="text-center mb-3">
            <a href="<?php echo e(route('home')); ?>" class="text-decoration-none d-inline-block">
                <img src="<?php echo e(\App\Support\Branding::logoUrl()); ?>" alt="<?php echo e(\App\Support\SiteConfig::name()); ?>"
                     style="height: <?php echo e(\App\Support\Branding::registerLogoHeight()); ?>px; width: auto; max-width: 100%; object-fit: contain;">
            </a>
        </div>
        <h2 class="login-title" id="registerTitle"><?php echo e(__('menu.register_welcome')); ?></h2>
        <p class="login-subtitle"><?php echo e(__('menu.register_subtitle')); ?></p>

        <?php if($errors->any()): ?>
            <div class="alert alert-danger alert-login">
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div><?php echo e($error); ?></div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        <?php endif; ?>

        <form method="POST" action="<?php echo e(route('register')); ?>" id="registerForm">
            <?php echo csrf_field(); ?>
            <input type="hidden" name="captcha_check" value="1">

            <div class="mb-3">
                <input type="text" name="name" class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                       value="<?php echo e(old('name')); ?>" placeholder="<?php echo e(__('menu.full_name')); ?>" required autocomplete="name">
            </div>

            <div class="mb-3">
                <input type="email" name="email" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                       value="<?php echo e(old('email')); ?>" placeholder="<?php echo e(__('menu.email')); ?>" required autocomplete="email">
            </div>

            <div class="mb-3">
                <div class="input-group">
                    <input type="password" name="password" id="registerPassword"
                           class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                           placeholder="<?php echo e(__('menu.password')); ?>" required autocomplete="new-password">
                    <button class="btn-eye" type="button" data-toggle-target="registerPassword" title="<?php echo e(__('menu.toggle_password')); ?>">
                        <i class="fa fa-eye-slash"></i>
                    </button>
                </div>
            </div>

            <div class="mb-3">
                <div class="input-group">
                    <input type="password" name="password_confirmation" id="registerPasswordConfirm"
                           class="form-control" placeholder="<?php echo e(__('menu.password_confirm')); ?>" required autocomplete="new-password">
                    <button class="btn-eye" type="button" data-toggle-target="registerPasswordConfirm" title="<?php echo e(__('menu.toggle_password')); ?>">
                        <i class="fa fa-eye-slash"></i>
                    </button>
                </div>
            </div>

            <div class="mb-2">
                <input type="text" name="phone" class="form-control <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                       value="<?php echo e(old('phone')); ?>" placeholder="<?php echo e(__('menu.phone')); ?>" required autocomplete="tel">
                <div class="form-text register-phone-hint"><?php echo e(__('menu.register_phone_hint')); ?></div>
            </div>

            <?php echo $__env->make('theme::partials.auth.captcha', ['context' => \App\Support\CaptchaPolicy::CONTEXT_REGISTER], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

            <button type="submit" class="btn-login w-100 mt-3"><?php echo e(__('menu.register')); ?></button>
        </form>

        <?php echo $__env->make('theme::partials.auth.oauth-buttons', ['intent' => 'register'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    </div>
</div>
<?php endif; ?>
<?php /**PATH C:\Users\faltun\Desktop\Menu-One\themes/adminlte4/partials/auth/register-panel.blade.php ENDPATH**/ ?>