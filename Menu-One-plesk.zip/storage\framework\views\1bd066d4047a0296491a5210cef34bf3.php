

<?php $__env->startSection('title', __('menu.edit_product')); ?>
<?php $__env->startSection('page-title', __('menu.edit_product')); ?>

<?php $__env->startSection('content'); ?>
<div class="card mo-product-modal">
    <div class="card-header">
        <h5 class="mb-0"><?php echo e(__('menu.edit_product')); ?>: <?php echo e($product->name); ?></h5>
    </div>
    <div class="card-body">
        <?php echo $__env->make('theme::partials.admin.product-form', [
            'product' => $product,
            'formAction' => route('admin.products.update', $product),
            'formMethod' => 'PUT',
            'categories' => $categories,
            'submitLabel' => __('menu.update'),
            'showCancel' => false,
        ], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('theme::layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\faltun\Desktop\Menu-One\themes/adminlte4/pages/admin/products/edit.blade.php ENDPATH**/ ?>