<?php use \App\Enums\ReservationStatus; ?>


<?php $__env->startSection('title', __('menu.reservations')); ?>
<?php $__env->startSection('page-title', __('menu.reservations')); ?>
<?php $__env->startSection('content'); ?>
<div class="d-flex justify-content-between align-items-center mb-3 flex-wrap gap-2">
    <p class="text-muted mb-0"><?php echo e(__('menu.reservations_hint')); ?></p>
    <a href="<?php echo e(route('reservations.create')); ?>" class="btn btn-primary"><?php echo e(__('menu.add_reservation')); ?></a>
</div>

<form method="GET" action="<?php echo e(route('reservations.index')); ?>" class="card mb-3">
    <div class="card-body">
        <div class="row g-2 align-items-end">
            <div class="col-md-6">
                <label class="form-label" for="reservationSearch"><?php echo e(__('menu.search')); ?></label>
                <input type="search" id="reservationSearch" name="search" class="form-control"
                       value="<?php echo e($search); ?>" placeholder="<?php echo e(__('menu.reservation_search_placeholder')); ?>">
            </div>
            <div class="col-md-3">
                <label class="form-label" for="perPage"><?php echo e(__('menu.per_page')); ?></label>
                <select id="perPage" name="per_page" class="form-select">
                    <?php $__currentLoopData = [10, 50, 150]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $size): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($size); ?>" <?php if($perPage === $size): echo 'selected'; endif; ?>><?php echo e($size); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div class="col-md-3 d-flex gap-2">
                <button type="submit" class="btn btn-outline-primary flex-grow-1"><?php echo e(__('menu.search')); ?></button>
                <?php if($search !== ''): ?>
                    <a href="<?php echo e(route('reservations.index', ['per_page' => $perPage])); ?>" class="btn btn-outline-secondary"><?php echo e(__('menu.clear')); ?></a>
                <?php endif; ?>
            </div>
        </div>
    </div>
</form>

<div class="card">
    <div class="card-body p-0">
        <table class="table mb-0">
            <thead>
                <tr>
                    <th><?php echo e(__('menu.table')); ?></th>
                    <th><?php echo e(__('menu.reservation_guest')); ?></th>
                    <th><?php echo e(__('menu.phone')); ?></th>
                    <th><?php echo e(__('menu.reservation_party_size')); ?></th>
                    <th><?php echo e(__('menu.reservation_period')); ?></th>
                    <th><?php echo e(__('menu.reservation_created_by')); ?></th>
                    <th><?php echo e(__('menu.status')); ?></th>
                    <th></th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $reservations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reservation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td>
                            <a href="<?php echo e(route('waiter.tables.show', $reservation->cafeTable)); ?>"><?php echo e($reservation->cafeTable->name); ?></a>
                        </td>
                        <td><?php echo e($reservation->guest_name); ?></td>
                        <td class="text-nowrap">
                            <?php if($reservation->guest_phone): ?>
                                <div><?php echo e($reservation->guest_phone); ?></div>
                                <?php echo $__env->make('theme::pages.reservations._call', ['reservation' => $reservation], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                            <?php else: ?>
                                <span class="text-muted">—</span>
                            <?php endif; ?>
                        </td>
                        <td><?php echo e($reservation->party_size); ?> <?php echo e(__('menu.seats')); ?></td>
                        <td><?php echo $__env->make('theme::pages.reservations._period', ['reservation' => $reservation], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?></td>
                        <td><?php echo e($reservation->user?->name ?? '—'); ?></td>
                        <td>
                            <?php if($reservation->status === ReservationStatus::Completed): ?>
                                <span class="badge text-bg-secondary"><?php echo e(__('menu.reservation_completed')); ?></span>
                            <?php elseif($reservation->isCurrent()): ?>
                                <span class="badge text-bg-danger"><?php echo e(__('menu.reservation_in_progress')); ?></span>
                            <?php else: ?>
                                <span class="badge text-bg-warning"><?php echo e(__('menu.reservation_upcoming')); ?></span>
                            <?php endif; ?>
                        </td>
                        <td class="text-end text-nowrap">
                            <?php if($reservation->status === ReservationStatus::Active): ?>
                            <a href="<?php echo e(route('reservations.edit', $reservation)); ?>" class="btn btn-sm btn-outline-primary"><?php echo e(__('menu.edit')); ?></a>
                            <?php echo $__env->make('theme::pages.reservations._complete', ['reservation' => $reservation], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                            <form method="POST" action="<?php echo e(route('reservations.destroy', $reservation)); ?>" class="d-inline"
                                  onsubmit="return confirm('<?php echo e(__('menu.confirm_cancel_reservation')); ?>')">
                                <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="btn btn-sm btn-outline-danger"><?php echo e(__('menu.reservation_cancel')); ?></button>
                            </form>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <?php if($reservation->notes): ?>
                        <tr>
                            <td colspan="8" class="pt-0 pb-3 text-muted small"><?php echo e($reservation->notes); ?></td>
                        </tr>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr><td colspan="8" class="text-muted p-4"><?php echo e(__('menu.no_reservations')); ?></td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
    <?php if($reservations->hasPages() || $reservations->total() > 0): ?>
        <div class="card-footer d-flex justify-content-between align-items-center flex-wrap gap-2">
            <small class="text-muted"><?php echo e(__('menu.showing_results', ['from' => $reservations->firstItem() ?? 0, 'to' => $reservations->lastItem() ?? 0, 'total' => $reservations->total()])); ?></small>
            <?php echo e($reservations->links()); ?>

        </div>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('theme::layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\faltun\Desktop\Menu-One\themes/adminlte4/pages/reservations/index.blade.php ENDPATH**/ ?>