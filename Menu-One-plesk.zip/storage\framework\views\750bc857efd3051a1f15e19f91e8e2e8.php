<?php
    $isPublicPage = $isPublicPage ?? true;
    $pageTitle = $pageTitle ?? null;
    $pageDescription = $pageDescription ?? null;
    $inject = \App\Support\SeoPolicy::shouldInject($isPublicPage);
    $metaTitle = $pageTitle ?: \App\Support\SeoPolicy::metaTitle();
    $metaDescription = $pageDescription ?: \App\Support\SeoPolicy::metaDescription();
    $canonical = \App\Support\SeoPolicy::canonicalUrl();
    $ogImage = \App\Support\SeoPolicy::ogImageUrl();
    $gtmId = \App\Support\SeoPolicy::tagManagerId();
    $gaId = \App\Support\SeoPolicy::analyticsId();
    $adsId = \App\Support\SeoPolicy::adsId();
    $gscVerification = \App\Support\SeoPolicy::searchConsoleVerification();
    $yandexVerification = \App\Support\SeoPolicy::yandexWebmasterVerification();
    $yandexMetrikaId = \App\Support\SeoPolicy::yandexMetrikaId();
    $schema = \App\Support\SeoPolicy::organizationSchema();
?>
<?php if($inject): ?>
    <?php if($gscVerification !== ''): ?>
        <meta name="google-site-verification" content="<?php echo e($gscVerification); ?>">
    <?php endif; ?>

    <?php if($yandexVerification !== ''): ?>
        <meta name="yandex-verification" content="<?php echo e($yandexVerification); ?>">
    <?php endif; ?>

    <?php if(! $isPublicPage): ?>
        <meta name="robots" content="noindex, nofollow">
    <?php elseif(! \App\Support\SeoPolicy::indexPublic()): ?>
        <meta name="robots" content="noindex, nofollow">
    <?php endif; ?>

    <?php if($metaDescription !== ''): ?>
        <meta name="description" content="<?php echo e($metaDescription); ?>">
    <?php endif; ?>
    <?php if(\App\Support\SeoPolicy::metaKeywords() !== ''): ?>
        <meta name="keywords" content="<?php echo e(\App\Support\SeoPolicy::metaKeywords()); ?>">
    <?php endif; ?>
    <link rel="canonical" href="<?php echo e($canonical); ?>">

    <meta property="og:type" content="website">
    <meta property="og:title" content="<?php echo e($metaTitle); ?>">
    <meta property="og:description" content="<?php echo e($metaDescription); ?>">
    <meta property="og:url" content="<?php echo e($canonical); ?>">
    <?php if($ogImage): ?>
        <meta property="og:image" content="<?php echo e($ogImage); ?>">
    <?php endif; ?>
    <meta name="twitter:card" content="summary_large_image">
    <meta name="twitter:title" content="<?php echo e($metaTitle); ?>">
    <meta name="twitter:description" content="<?php echo e($metaDescription); ?>">
    <?php if($ogImage): ?>
        <meta name="twitter:image" content="<?php echo e($ogImage); ?>">
    <?php endif; ?>

    <?php if($schema): ?>
        <script type="application/ld+json"><?php echo json_encode($schema, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES); ?></script>
    <?php endif; ?>

    <?php if($gtmId !== ''): ?>
        <script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
        new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
        j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
        'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
        })(window,document,'script','dataLayer','<?php echo e($gtmId); ?>');</script>
    <?php elseif($gaId !== '' || $adsId !== ''): ?>
        <script async src="https://www.googletagmanager.com/gtag/js?id=<?php echo e($gaId !== '' ? $gaId : $adsId); ?>"></script>
        <script>
            window.dataLayer = window.dataLayer || [];
            function gtag(){dataLayer.push(arguments);}
            gtag('js', new Date());
            <?php if($gaId !== ''): ?>
            gtag('config', <?php echo json_encode($gaId, 15, 512) ?>);
            <?php endif; ?>
            <?php if($adsId !== ''): ?>
            gtag('config', <?php echo json_encode($adsId, 15, 512) ?>);
            <?php endif; ?>
        </script>
    <?php endif; ?>

    <?php if($yandexMetrikaId !== ''): ?>
        <script>
            (function(m,e,t,r,i,k,a){m[i]=m[i]||function(){(m[i].a=m[i].a||[]).push(arguments)};
            m[i].l=1*new Date();
            for (var j = 0; j < document.scripts.length; j++) {if (document.scripts[j].src === r) { return; }}
            k=e.createElement(t),a=e.getElementsByTagName(t)[0],k.async=1,k.src=r,a.parentNode.insertBefore(k,a)})
            (window, document, "script", "https://mc.yandex.ru/metrika/tag.js", "ym");
            ym(<?php echo e($yandexMetrikaId); ?>, "init", {
                clickmap:true,
                trackLinks:true,
                accurateTrackBounce:true,
                webvisor:true
            });
        </script>
    <?php endif; ?>
<?php elseif(! $isPublicPage): ?>
    <meta name="robots" content="noindex, nofollow">
<?php endif; ?>
<?php /**PATH C:\Users\faltun\Desktop\Menu-One\themes/adminlte4/partials/seo-head.blade.php ENDPATH**/ ?>