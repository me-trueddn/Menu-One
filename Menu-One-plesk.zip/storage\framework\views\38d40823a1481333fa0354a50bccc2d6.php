
<?php $__env->startSection('title', 'Kategoriler'); ?>
<?php $__env->startSection('page-title', 'Kategoriler'); ?>
<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="card-header d-flex justify-content-between"><h5 class="mb-0">Kategoriler</h5><a href="<?php echo e(route('admin.categories.create')); ?>" class="btn btn-primary btn-sm">Ekle</a></div>
    <div class="card-body table-responsive p-0">
        <table class="table mb-0"><thead><tr><th>Ad</th><th>Sıra</th><th class="text-end">İşlem</th></tr></thead>
        <tbody><?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><tr><td><?php echo e($cat->name); ?></td><td><?php echo e($cat->sort_order); ?></td>
        <td class="text-end"><a href="<?php echo e(route('admin.categories.edit', $cat)); ?>" class="btn btn-sm btn-outline-primary">Düzenle</a>
        <form action="<?php echo e(route('admin.categories.destroy', $cat)); ?>" method="POST" class="d-inline" onsubmit="return confirm('Silinsin mi?')"><?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?><button class="btn btn-sm btn-outline-danger">Sil</button></form></td></tr><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></tbody></table>
    </div>
    <?php if($categories->hasPages()): ?><div class="card-footer"><?php echo e($categories->links()); ?></div><?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('theme::layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\faltun\Desktop\Menu-One\themes/adminlte4/pages/admin/categories/index.blade.php ENDPATH**/ ?>