

<?php $__env->startSection('title', __('menu.seo_settings')); ?>
<?php $__env->startSection('page-title', __('menu.seo_settings')); ?>

<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="card-header">
        <h5 class="mb-0"><?php echo e(__('menu.seo_tools_title')); ?></h5>
    </div>
    <div class="card-body">
        <form method="POST" action="<?php echo e(route('platform.settings.seo.update')); ?>" enctype="multipart/form-data">
            <?php echo csrf_field(); ?> <?php echo method_field('PUT'); ?>

            <div class="alert alert-light border mb-4">
                <div class="fw-semibold mb-1"><?php echo e(__('menu.seo_public_urls')); ?></div>
                <div><code><?php echo e($settings['sitemap_url']); ?></code></div>
                <div class="mt-1"><code><?php echo e($settings['robots_url']); ?></code></div>
            </div>

            <div class="mb-4">
                <input type="hidden" name="seo_enabled" value="0">
                <div class="form-check form-switch">
                    <input class="form-check-input" type="checkbox" name="seo_enabled" id="seo_enabled" value="1"
                           <?php if(old('seo_enabled', $settings['seo_enabled'])): echo 'checked'; endif; ?>>
                    <label class="form-check-label" for="seo_enabled"><?php echo e(__('menu.seo_enabled')); ?></label>
                </div>
                <div class="form-text"><?php echo e(__('menu.seo_enabled_hint')); ?></div>
            </div>

            <div class="row mb-4">
                <div class="col-md-6">
                    <input type="hidden" name="seo_index_public" value="0">
                    <div class="form-check">
                        <input class="form-check-input" type="checkbox" name="seo_index_public" id="seo_index_public" value="1"
                               <?php if(old('seo_index_public', $settings['seo_index_public'])): echo 'checked'; endif; ?>>
                        <label class="form-check-label" for="seo_index_public"><?php echo e(__('menu.seo_index_public')); ?></label>
                    </div>
                </div>
                <div class="col-md-6">
                    <input type="hidden" name="seo_track_authenticated" value="0">
                    <div class="form-check">
                        <input class="form-check-input" type="checkbox" name="seo_track_authenticated" id="seo_track_authenticated" value="1"
                               <?php if(old('seo_track_authenticated', $settings['seo_track_authenticated'])): echo 'checked'; endif; ?>>
                        <label class="form-check-label" for="seo_track_authenticated"><?php echo e(__('menu.seo_track_authenticated')); ?></label>
                    </div>
                </div>
            </div>

            <h6 class="border-bottom pb-2 mb-3"><?php echo e(__('menu.seo_meta_section')); ?></h6>
            <div class="row">
                <div class="col-md-6 mb-3">
                    <label class="form-label" for="seo_meta_title"><?php echo e(__('menu.seo_meta_title')); ?></label>
                    <input type="text" name="seo_meta_title" id="seo_meta_title" class="form-control"
                           value="<?php echo e(old('seo_meta_title', $settings['seo_meta_title'])); ?>" maxlength="120">
                </div>
                <div class="col-md-6 mb-3">
                    <label class="form-label" for="seo_organization_name"><?php echo e(__('menu.seo_organization_name')); ?></label>
                    <input type="text" name="seo_organization_name" id="seo_organization_name" class="form-control"
                           value="<?php echo e(old('seo_organization_name', $settings['seo_organization_name'])); ?>" maxlength="120">
                </div>
                <div class="col-12 mb-3">
                    <label class="form-label" for="seo_meta_description"><?php echo e(__('menu.seo_meta_description')); ?></label>
                    <textarea name="seo_meta_description" id="seo_meta_description" class="form-control" rows="3"
                              maxlength="320"><?php echo e(old('seo_meta_description', $settings['seo_meta_description'])); ?></textarea>
                </div>
                <div class="col-md-6 mb-3">
                    <label class="form-label" for="seo_meta_keywords"><?php echo e(__('menu.seo_meta_keywords')); ?></label>
                    <input type="text" name="seo_meta_keywords" id="seo_meta_keywords" class="form-control"
                           value="<?php echo e(old('seo_meta_keywords', $settings['seo_meta_keywords'])); ?>" maxlength="255">
                </div>
                <div class="col-md-6 mb-3">
                    <label class="form-label" for="seo_organization_url"><?php echo e(__('menu.seo_organization_url')); ?></label>
                    <input type="url" name="seo_organization_url" id="seo_organization_url" class="form-control"
                           value="<?php echo e(old('seo_organization_url', $settings['seo_organization_url'])); ?>" maxlength="255">
                </div>
                <div class="col-md-6 mb-3">
                    <label class="form-label" for="seo_og_image"><?php echo e(__('menu.seo_og_image')); ?></label>
                    <input type="file" name="seo_og_image" id="seo_og_image" class="form-control" accept="image/*">
                    <?php if($settings['seo_og_image_url']): ?>
                        <img src="<?php echo e($settings['seo_og_image_url']); ?>" alt="" class="img-thumbnail mt-2" style="max-height:120px">
                    <?php endif; ?>
                </div>
            </div>

            <h6 class="border-bottom pb-2 mb-3 mt-2"><?php echo e(__('menu.seo_google_section')); ?></h6>

            <h6 class="mb-3 text-muted"><?php echo e(__('menu.seo_google_tag_manager')); ?></h6>
            <div class="mb-3">
                <label class="form-label" for="google_tag_manager_id"><?php echo e(__('menu.seo_gtm_id')); ?></label>
                <input type="text" name="google_tag_manager_id" id="google_tag_manager_id" class="form-control"
                       value="<?php echo e(old('google_tag_manager_id', $settings['google_tag_manager_id'])); ?>"
                       placeholder="GTM-XXXXXXX">
                <div class="form-text"><?php echo e(__('menu.seo_gtm_hint')); ?></div>
                <?php $__errorArgs = ['google_tag_manager_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="text-danger small"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <h6 class="border-bottom pb-2 mb-3"><?php echo e(__('menu.seo_google_analytics')); ?></h6>
            <div class="mb-3">
                <label class="form-label" for="google_analytics_id"><?php echo e(__('menu.seo_ga4_id')); ?></label>
                <input type="text" name="google_analytics_id" id="google_analytics_id" class="form-control"
                       value="<?php echo e(old('google_analytics_id', $settings['google_analytics_id'])); ?>"
                       placeholder="G-XXXXXXXXXX">
                <div class="form-text"><?php echo e(__('menu.seo_ga4_hint')); ?></div>
                <?php $__errorArgs = ['google_analytics_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="text-danger small"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <h6 class="border-bottom pb-2 mb-3"><?php echo e(__('menu.seo_google_search_console')); ?></h6>
            <div class="mb-3">
                <label class="form-label" for="google_search_console_verification"><?php echo e(__('menu.seo_gsc_verification')); ?></label>
                <input type="text" name="google_search_console_verification" id="google_search_console_verification" class="form-control"
                       value="<?php echo e(old('google_search_console_verification', $settings['google_search_console_verification'])); ?>">
                <div class="form-text"><?php echo e(__('menu.seo_gsc_hint')); ?></div>
                <?php $__errorArgs = ['google_search_console_verification'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="text-danger small"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <h6 class="border-bottom pb-2 mb-3"><?php echo e(__('menu.seo_google_ads')); ?></h6>
            <div class="row">
                <div class="col-md-6 mb-3">
                    <label class="form-label" for="google_ads_id"><?php echo e(__('menu.seo_ads_id')); ?></label>
                    <input type="text" name="google_ads_id" id="google_ads_id" class="form-control"
                           value="<?php echo e(old('google_ads_id', $settings['google_ads_id'])); ?>"
                           placeholder="AW-XXXXXXXXX">
                    <?php $__errorArgs = ['google_ads_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="text-danger small"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="col-md-6 mb-3">
                    <label class="form-label" for="google_ads_conversion_label"><?php echo e(__('menu.seo_ads_conversion_label')); ?></label>
                    <input type="text" name="google_ads_conversion_label" id="google_ads_conversion_label" class="form-control"
                           value="<?php echo e(old('google_ads_conversion_label', $settings['google_ads_conversion_label'])); ?>">
                    <div class="form-text"><?php echo e(__('menu.seo_ads_hint')); ?></div>
                </div>
            </div>

            <h6 class="border-bottom pb-2 mb-3 mt-4"><?php echo e(__('menu.seo_yandex_section')); ?></h6>

            <div class="mb-3">
                <label class="form-label" for="yandex_webmaster_verification"><?php echo e(__('menu.seo_yandex_webmaster_verification')); ?></label>
                <input type="text" name="yandex_webmaster_verification" id="yandex_webmaster_verification" class="form-control"
                       value="<?php echo e(old('yandex_webmaster_verification', $settings['yandex_webmaster_verification'])); ?>">
                <div class="form-text"><?php echo e(__('menu.seo_yandex_webmaster_hint')); ?></div>
                <?php $__errorArgs = ['yandex_webmaster_verification'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="text-danger small"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="mb-3">
                <label class="form-label" for="yandex_metrika_id"><?php echo e(__('menu.seo_yandex_metrika_id')); ?></label>
                <input type="text" name="yandex_metrika_id" id="yandex_metrika_id" class="form-control"
                       value="<?php echo e(old('yandex_metrika_id', $settings['yandex_metrika_id'])); ?>"
                       placeholder="12345678" inputmode="numeric" pattern="\d{5,12}">
                <div class="form-text"><?php echo e(__('menu.seo_yandex_metrika_hint')); ?></div>
                <?php $__errorArgs = ['yandex_metrika_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="text-danger small"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <button type="submit" class="btn btn-primary"><?php echo e(__('menu.save')); ?></button>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('theme::layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\faltun\Desktop\Menu-One\themes/adminlte4/pages/platform/settings/seo.blade.php ENDPATH**/ ?>