

<?php $__env->startSection('title', __('menu.profile')); ?>
<?php $__env->startSection('page-title', __('menu.profile')); ?>

<?php $__env->startSection('content'); ?>
<?php echo $__env->make('theme::partials.license-expired-banner', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

<div class="card shadow-sm mb-3">
    <div class="card-body">
        <div class="row align-items-center g-3">
            <div class="col-auto">
                <div class="rounded-circle bg-primary-subtle text-primary d-flex align-items-center justify-content-center"
                     style="width: 56px; height: 56px; font-size: 1.5rem;">
                    <i class="bi bi-person-fill"></i>
                </div>
            </div>
            <div class="col">
                <h4 class="mb-1"><?php echo e($user->name); ?></h4>
                <div class="text-muted small"><?php echo e($user->email); ?></div>
            </div>
            <div class="col-sm-auto text-sm-end">
                <div class="small text-muted"><?php echo e(__('menu.account_type')); ?></div>
                <span class="badge <?php echo e($user->accountSubscriptionBadgeClass()); ?>"><?php echo e($user->accountSubscriptionLabel()); ?></span>
            </div>
        </div>
    </div>
</div>

<div class="card shadow-sm">
    <div class="card-header border-bottom-0 pb-0">
        <ul class="nav nav-tabs card-header-tabs" role="tablist">
            <li class="nav-item">
                <a class="nav-link <?php echo e($tab === 'profile' ? 'active' : ''); ?>"
                   href="<?php echo e(route('profile.edit', ['tab' => 'profile'])); ?>">
                    <i class="bi bi-person me-1"></i><?php echo e(__('menu.profile_tab')); ?>

                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link <?php echo e($tab === 'security' ? 'active' : ''); ?>"
                   href="<?php echo e(route('profile.edit', ['tab' => 'security'])); ?>">
                    <i class="bi bi-shield-lock me-1"></i><?php echo e(__('menu.security_tab')); ?>

                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link <?php echo e($tab === 'cafe' ? 'active' : ''); ?>"
                   href="<?php echo e(route('profile.edit', ['tab' => 'cafe'])); ?>">
                    <i class="bi bi-shop me-1"></i><?php echo e(__('menu.create_cafe_tab')); ?>

                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link <?php echo e($tab === 'licensing' ? 'active' : ''); ?>"
                   href="<?php echo e(route('profile.edit', ['tab' => 'licensing'])); ?>">
                    <i class="bi bi-award me-1"></i><?php echo e(__('menu.licensing_tab')); ?>

                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link <?php echo e($tab === 'ticket' ? 'active' : ''); ?>"
                   href="<?php echo e(route('profile.edit', ['tab' => 'ticket'])); ?>">
                    <i class="bi bi-ticket-perforated me-1"></i><?php echo e(__('menu.ticket')); ?>

                </a>
            </li>
        </ul>
    </div>

    <div class="card-body">
        <?php if($tab === 'profile'): ?>
            <div class="row g-4">
                <div class="col-md-6">
                    <label class="form-label text-muted small"><?php echo e(__('menu.user_id')); ?></label>
                    <div><code><?php echo e($user->public_id); ?></code></div>
                </div>
                <div class="col-md-6">
                    <label class="form-label text-muted small"><?php echo e(__('menu.language')); ?></label>
                    <div class="d-flex gap-2">
                        <?php $__currentLoopData = config('locale.available', []); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $code): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <a href="<?php echo e(route('locale.switch', $code)); ?>"
                               class="btn btn-sm <?php echo e(app()->getLocale() === $code ? 'btn-primary' : 'btn-outline-secondary'); ?>">
                                <?php echo e(config('locale.names.'.$code, $code)); ?>

                            </a>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>

                <div class="col-12"><hr class="my-0"></div>

                <div class="col-12">
                    <form method="POST" action="<?php echo e(route('profile.update')); ?>">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('patch'); ?>

                        <div class="row g-3">
                            <div class="col-md-6">
                                <label class="form-label" for="name"><?php echo e(__('menu.full_name')); ?></label>
                                <input type="text" id="name" name="name"
                                       class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                       value="<?php echo e(old('name', $user->name)); ?>" required autocomplete="name">
                                <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="invalid-feedback"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="col-md-6">
                                <label class="form-label" for="phone"><?php echo e(__('menu.phone')); ?></label>
                                <input type="text" id="phone" name="phone"
                                       class="form-control <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                       value="<?php echo e(old('phone', $user->phone)); ?>" autocomplete="tel">
                                <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="invalid-feedback"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="col-md-6">
                                <label class="form-label"><?php echo e(__('menu.email')); ?></label>
                                <input type="email" class="form-control" value="<?php echo e($user->email); ?>" disabled>
                                <div class="form-text"><?php echo e(__('menu.email_change_in_security')); ?></div>
                            </div>
                            <div class="col-md-6">
                                <label class="form-label"><?php echo e(__('menu.account_type')); ?></label>
                                <input type="text" class="form-control" value="<?php echo e($user->accountSubscriptionLabel()); ?>" disabled>
                            </div>
                        </div>

                        <div class="mt-4">
                            <button type="submit" class="btn btn-primary"><?php echo e(__('menu.save')); ?></button>
                        </div>
                    </form>
                </div>

                <?php if($user->isCustomer() && $user->linkedTenants()->isNotEmpty()): ?>
                    <div class="col-12"><hr class="my-0"></div>
                    <div class="col-12">
                        <h6 class="fw-semibold"><?php echo e(__('menu.my_cafes')); ?></h6>
                        <p class="text-muted small"><?php echo e(__('menu.my_cafes_hint')); ?></p>
                        <ul class="list-group">
                            <?php $__currentLoopData = $user->linkedTenants(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $linkedTenant): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li class="list-group-item d-flex justify-content-between align-items-center flex-wrap gap-2">
                                    <div>
                                        <strong><?php echo e($linkedTenant->name); ?></strong>
                                        <code class="ms-2"><?php echo e($linkedTenant->id); ?></code>
                                        <span class="badge <?php echo e($linkedTenant->isPremiumLicensed() ? 'text-bg-warning' : 'text-bg-info'); ?> ms-1">
                                            <?php echo e($linkedTenant->subscriptionLabel()); ?>

                                        </span>
                                        <?php if(($activeTenantId ?? null) === $linkedTenant->id): ?>
                                            <span class="badge text-bg-primary ms-1"><?php echo e(__('menu.active_cafe')); ?></span>
                                        <?php endif; ?>
                                    </div>
                                    <?php if(!empty($canSwitchTenants) && $canSwitchTenants && ($activeTenantId ?? null) !== $linkedTenant->id): ?>
                                        <form method="POST" action="<?php echo e(route('tenant.select.store')); ?>">
                                            <?php echo csrf_field(); ?>
                                            <input type="hidden" name="tenant_id" value="<?php echo e($linkedTenant->id); ?>">
                                            <input type="hidden" name="redirect" value="<?php echo e(route('profile.edit', ['tab' => 'profile'])); ?>">
                                            <button type="submit" class="btn btn-sm btn-outline-primary"><?php echo e(__('menu.switch_cafe')); ?></button>
                                        </form>
                                    <?php endif; ?>
                                </li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                        <?php if(!empty($canSwitchTenants) && $canSwitchTenants && ! \App\Support\TenantLicenseGate::licenseExpiredForUser($user)): ?>
                            <a href="<?php echo e(route('admin.dashboard')); ?>" class="btn btn-sm btn-primary mt-3"><?php echo e(__('menu.go_to_cafe_panel')); ?></a>
                        <?php endif; ?>
                    </div>
                <?php endif; ?>
            </div>
        <?php endif; ?>

        <?php if($tab === 'security'): ?>
            <div class="row g-4">
                <div class="col-12">
                    <h6 class="fw-semibold"><?php echo e(__('menu.change_password')); ?></h6>
                    <p class="text-muted small"><?php echo e(__('menu.change_password_hint')); ?></p>
                    <form method="POST" action="<?php echo e(route('password.update')); ?>" class="row g-3">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('put'); ?>
                        <div class="col-md-4">
                            <label class="form-label" for="current_password"><?php echo e(__('menu.current_password')); ?></label>
                            <input type="password" id="current_password" name="current_password"
                                   class="form-control <?php $__errorArgs = ['current_password', 'updatePassword'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                   autocomplete="current-password">
                            <?php $__errorArgs = ['current_password', 'updatePassword'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="invalid-feedback"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="col-md-4">
                            <label class="form-label" for="password"><?php echo e(__('menu.new_password')); ?></label>
                            <input type="password" id="password" name="password"
                                   class="form-control <?php $__errorArgs = ['password', 'updatePassword'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                   autocomplete="new-password">
                            <?php $__errorArgs = ['password', 'updatePassword'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="invalid-feedback"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="col-md-4">
                            <label class="form-label" for="password_confirmation"><?php echo e(__('menu.password_confirm')); ?></label>
                            <input type="password" id="password_confirmation" name="password_confirmation"
                                   class="form-control" autocomplete="new-password">
                        </div>
                        <div class="col-12">
                            <button type="submit" class="btn btn-primary"><?php echo e(__('menu.change_password')); ?></button>
                        </div>
                    </form>
                </div>

                <div class="col-12"><hr></div>

                <div class="col-12">
                    <h6 class="fw-semibold"><?php echo e(__('menu.change_email')); ?></h6>
                    <p class="text-muted small"><?php echo e(__('menu.change_email_hint')); ?></p>
                    <form method="POST" action="<?php echo e(route('profile.change-email')); ?>" class="row g-3">
                        <?php echo csrf_field(); ?>
                        <div class="col-md-6">
                            <label class="form-label" for="email"><?php echo e(__('menu.new_email')); ?></label>
                            <input type="email" id="email" name="email"
                                   class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                   value="<?php echo e(old('email', $user->email)); ?>" required>
                            <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="invalid-feedback"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label" for="email_password"><?php echo e(__('menu.current_password')); ?></label>
                            <input type="password" id="email_password" name="password"
                                   class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required>
                            <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="invalid-feedback"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="col-12">
                            <button type="submit" class="btn btn-primary"><?php echo e(__('menu.change_email')); ?></button>
                        </div>
                    </form>
                </div>

                <div class="col-12"><hr></div>

                <div class="col-12">
                    <h6 class="fw-semibold"><?php echo e(__('menu.two_factor_auth')); ?></h6>
                    <p class="text-muted small"><?php echo e(__('menu.two_factor_hint')); ?></p>

                    <?php if (! ($twoFactorGloballyEnabled)): ?>
                        <div class="alert alert-secondary mb-0"><?php echo e(__('menu.two_factor_disabled_globally')); ?></div>
                    <?php else: ?>
                        <?php if($user->hasTwoFactorConfigured()): ?>
                            <div class="d-flex align-items-center gap-2 mb-3">
                                <span class="badge text-bg-success"><?php echo e(__('menu.two_factor_status_on')); ?></span>
                                <span class="small text-muted"><?php echo e(__('menu.two_factor_enabled_since', ['date' => $user->two_factor_confirmed_at?->format('d.m.Y H:i')])); ?></span>
                            </div>

                            <form method="POST" action="<?php echo e(route('profile.two-factor.disable')); ?>" class="row g-3">
                                <?php echo csrf_field(); ?>
                                <div class="col-md-4">
                                    <label class="form-label" for="disable_code"><?php echo e(__('menu.two_factor_code')); ?></label>
                                    <input type="text" id="disable_code" name="code" inputmode="numeric" maxlength="6"
                                           class="form-control <?php $__errorArgs = ['two_factor_code'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required>
                                    <?php $__errorArgs = ['two_factor_code'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="invalid-feedback"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <?php if (! ($user->registeredViaOAuth())): ?>
                                    <div class="col-md-4">
                                        <label class="form-label" for="disable_password"><?php echo e(__('menu.current_password')); ?></label>
                                        <input type="password" id="disable_password" name="password"
                                               class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required>
                                        <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="invalid-feedback"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                <?php endif; ?>
                                <div class="col-12">
                                    <button type="submit" class="btn btn-outline-danger"><?php echo e(__('menu.disable_2fa')); ?></button>
                                </div>
                            </form>
                        <?php elseif($twoFactorSetup): ?>
                            <div class="alert alert-info"><?php echo e(__('menu.two_factor_scan_qr')); ?></div>
                            <div class="row g-4 align-items-start">
                                <div class="col-md-auto text-center">
                                    <div class="border rounded p-2 bg-white d-inline-block">
                                        <img src="<?php echo e($twoFactorSetup['qr_inline']); ?>"
                                             alt="<?php echo e(__('menu.two_factor_qr_alt')); ?>"
                                             width="200" height="200"
                                             class="d-block">
                                    </div>
                                </div>
                                <div class="col-md">
                                    <p class="small text-muted mb-2"><?php echo e(__('menu.two_factor_manual_key')); ?></p>
                                    <code class="user-select-all d-block mb-3"><?php echo e($twoFactorSetup['secret']); ?></code>

                                    <form method="POST" action="<?php echo e(route('profile.two-factor.confirm')); ?>" class="row g-3">
                                        <?php echo csrf_field(); ?>
                                        <div class="col-md-6">
                                            <label class="form-label" for="confirm_code"><?php echo e(__('menu.two_factor_code')); ?></label>
                                            <input type="text" id="confirm_code" name="code" inputmode="numeric" maxlength="6"
                                                   class="form-control <?php $__errorArgs = ['two_factor_code'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required autofocus>
                                            <?php $__errorArgs = ['two_factor_code'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="invalid-feedback"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                        <div class="col-12">
                                            <button type="submit" class="btn btn-primary"><?php echo e(__('menu.two_factor_confirm_setup')); ?></button>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        <?php else: ?>
                            <div class="d-flex align-items-center gap-2 mb-3">
                                <span class="badge text-bg-secondary"><?php echo e(__('menu.two_factor_status_off')); ?></span>
                            </div>
                            <form method="POST" action="<?php echo e(route('profile.two-factor.setup')); ?>">
                                <?php echo csrf_field(); ?>
                                <button type="submit" class="btn btn-outline-primary"><?php echo e(__('menu.enable_2fa')); ?></button>
                            </form>
                        <?php endif; ?>
                    <?php endif; ?>
                </div>

                <div class="col-12"><hr></div>

                <div class="col-12">
                    <h6 class="fw-semibold text-danger"><?php echo e(__('menu.delete_account')); ?></h6>
                    <?php if($hasCafeLinks): ?>
                        <p class="text-muted small"><?php echo e(__('menu.delete_account_cafe_warning')); ?></p>
                    <?php else: ?>
                        <p class="text-muted small"><?php echo e(__('menu.delete_account_hint')); ?></p>
                    <?php endif; ?>
                    <button type="button" class="btn btn-outline-danger" data-bs-toggle="modal" data-bs-target="#deleteAccountModal">
                        <?php echo e(__('menu.delete_account')); ?>

                    </button>
                </div>
            </div>

            <div class="modal fade" id="deleteAccountModal" tabindex="-1" aria-hidden="true">
                <div class="modal-dialog">
                    <div class="modal-content">
                        <form method="POST" action="<?php echo e(route('profile.destroy')); ?>">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('delete'); ?>
                            <div class="modal-header">
                                <h5 class="modal-title"><?php echo e(__('menu.delete_account')); ?></h5>
                                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                            </div>
                            <div class="modal-body">
                                <p><?php echo e(__('menu.delete_account_confirm')); ?></p>
                                <label class="form-label" for="delete_password"><?php echo e(__('menu.password')); ?></label>
                                <input type="password" id="delete_password" name="password"
                                       class="form-control <?php $__errorArgs = ['password', 'userDeletion'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required>
                                <?php $__errorArgs = ['password', 'userDeletion'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="invalid-feedback"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal"><?php echo e(__('menu.cancel')); ?></button>
                                <button type="submit" class="btn btn-danger"><?php echo e(__('menu.delete_account')); ?></button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        <?php endif; ?>

        <?php if($tab === 'cafe'): ?>
            <?php if($ownedCafes->isNotEmpty()): ?>
                <h6 class="fw-semibold"><?php echo e(__('menu.my_cafes')); ?></h6>
                <div class="list-group mb-4">
                    <?php $__currentLoopData = $ownedCafes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ownedCafe): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="list-group-item">
                            <div class="d-flex justify-content-between align-items-start flex-wrap gap-2">
                                <div>
                                    <strong><?php echo e($ownedCafe->name); ?></strong>
                                    <code class="ms-2"><?php echo e($ownedCafe->id); ?></code>
                                    <?php echo $__env->make('theme::partials.cafe-license-info', ['cafe' => $ownedCafe], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                                </div>
                                <div class="d-flex gap-2 flex-wrap">
                                    <?php if($ownedCafe->hasValidLicense()): ?>
                                        <a href="<?php echo e(route('admin.dashboard')); ?>" class="btn btn-sm btn-outline-primary"><?php echo e(__('menu.go_to_cafe_panel')); ?></a>
                                    <?php endif; ?>
                                    <?php if(! $ownedCafe->isPremiumLicensed()): ?>
                                        <form method="POST" action="<?php echo e(route('profile.cafe.destroy', $ownedCafe)); ?>"
                                              onsubmit="return confirm('<?php echo e(__('menu.confirm_delete_cafe')); ?>')">
                                            <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                                            <button type="submit" class="btn btn-sm btn-outline-danger"><?php echo e(__('menu.delete_cafe')); ?></button>
                                        </form>
                                    <?php else: ?>
                                        <span class="small text-muted align-self-center"><?php echo e(__('menu.premium_cafe_delete_blocked')); ?></span>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            <?php endif; ?>

            <?php if($canCreateCafe): ?>
                <h6 class="fw-semibold"><?php echo e(__('menu.create_cafe')); ?></h6>
                <p class="text-muted small"><?php echo e(__('menu.create_cafe_hint')); ?></p>
                <form method="POST" action="<?php echo e(route('profile.cafe.store')); ?>" enctype="multipart/form-data" class="row g-3">
                    <?php echo csrf_field(); ?>
                    <div class="col-md-6">
                        <label class="form-label" for="cafe_name"><?php echo e(__('menu.cafe_name')); ?></label>
                        <input type="text" id="cafe_name" name="name"
                               class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                               value="<?php echo e(old('name')); ?>" required>
                        <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="invalid-feedback"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="col-md-6">
                        <label class="form-label" for="cafe_slug">Slug</label>
                        <input type="text" id="cafe_slug" name="slug"
                               class="form-control <?php $__errorArgs = ['slug'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                               value="<?php echo e(old('slug')); ?>" required pattern="[a-zA-Z0-9_-]+">
                        <?php $__errorArgs = ['slug'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="invalid-feedback"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        <div class="form-text"><?php echo e(__('menu.cafe_slug_hint')); ?></div>
                    </div>
                    <?php echo $__env->make('theme::partials.company-fields', ['values' => $companyDefaults], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                    <div class="col-md-6">
                        <label class="form-label"><?php echo e(__('menu.cafe_logo')); ?></label>
                        <input type="file" name="logo" class="form-control" accept="image/*">
                    </div>
                    <div class="col-12">
                        <button type="submit" class="btn btn-primary"><?php echo e(__('menu.create_cafe')); ?></button>
                    </div>
                </form>
            <?php elseif($ownedCafes->isEmpty()): ?>
                <div class="alert alert-warning mb-0">
                    <h6 class="alert-heading"><?php echo e(__('menu.cafe_create_cooldown_title')); ?></h6>
                    <p class="mb-0">
                        <?php echo e(__('menu.cafe_create_cooldown_hint', [
                            'date' => $cafeCooldownEndsAt?->format('d.m.Y'),
                            'days' => $daysUntilCanCreateCafe,
                        ])); ?>

                    </p>
                </div>
            <?php else: ?>
                <div class="alert alert-info mb-0">
                    <p class="mb-0"><?php echo e(__('menu.cafe_already_exists_hint')); ?></p>
                </div>
            <?php endif; ?>

            <?php if($user->assignedTenants->isNotEmpty()): ?>
                <h6 class="fw-semibold mt-4"><?php echo e(__('menu.assigned_cafes')); ?></h6>
                <ul class="list-group">
                    <?php $__currentLoopData = $user->assignedTenants; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $assignedTenant): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($ownedCafes->contains('id', $assignedTenant->id)) continue; ?>
                        <li class="list-group-item">
                            <strong><?php echo e($assignedTenant->name); ?></strong>
                            <code class="ms-2"><?php echo e($assignedTenant->id); ?></code>
                            <?php echo $__env->make('theme::partials.cafe-license-info', ['cafe' => $assignedTenant], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            <?php endif; ?>
        <?php endif; ?>

        <?php if($tab === 'licensing'): ?>
            <div class="text-center py-4">
                <i class="bi bi-award display-4 text-muted"></i>
                <h5 class="mt-3"><?php echo e(__('menu.licensing_tab')); ?></h5>
                <p class="text-muted"><?php echo e(__('menu.licensing_coming_soon')); ?></p>
                <a href="<?php echo e(route('profile.edit', ['tab' => 'ticket'])); ?>" class="btn btn-outline-primary btn-sm">
                    <i class="bi bi-ticket-perforated me-1"></i><?php echo e(__('menu.ticket')); ?>

                </a>
            </div>
        <?php endif; ?>

        <?php if($tab === 'ticket'): ?>
            <div class="text-center py-4">
                <i class="bi bi-ticket-perforated display-4 text-muted"></i>
                <h5 class="mt-3"><?php echo e(__('menu.ticket')); ?></h5>
                <p class="text-muted mb-0"><?php echo e(__('menu.ticket_coming_soon')); ?></p>
            </div>
        <?php endif; ?>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<?php if($tab === 'security' && $errors->userDeletion->isNotEmpty()): ?>
<script>
document.addEventListener('DOMContentLoaded', function () {
    new bootstrap.Modal(document.getElementById('deleteAccountModal')).show();
});
</script>
<?php endif; ?>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('theme::layouts.profile', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\faltun\Desktop\Menu-One\themes/adminlte4/pages/profile/edit.blade.php ENDPATH**/ ?>