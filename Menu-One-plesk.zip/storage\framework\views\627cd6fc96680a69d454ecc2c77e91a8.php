<?php $__env->startSection('title', __('menu.customers')); ?>
<?php $__env->startSection('page-title', __('menu.customers')); ?>

<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="card-header">
        <div class="row g-2 align-items-center">
            <div class="col-md-4">
                <h5 class="mb-0"><?php echo e(__('menu.registered_customers')); ?></h5>
            </div>
            <div class="col-md-8">
                <form method="GET" action="<?php echo e(route('platform.customers.index')); ?>" class="row g-2 justify-content-end">
                    <div class="col-auto">
                        <select name="search_field" class="form-select form-select-sm">
                            <option value="email" <?php if($searchField === 'email'): echo 'selected'; endif; ?>><?php echo e(__('menu.email')); ?></option>
                            <option value="phone" <?php if($searchField === 'phone'): echo 'selected'; endif; ?>><?php echo e(__('menu.phone')); ?></option>
                            <option value="tenant" <?php if($searchField === 'tenant'): echo 'selected'; endif; ?>><?php echo e(__('menu.tenant')); ?></option>
                        </select>
                    </div>
                    <div class="col-auto">
                        <input type="search" name="q" value="<?php echo e(request('q')); ?>" class="form-control form-control-sm"
                               placeholder="<?php echo e(__('menu.search')); ?>">
                    </div>
                    <div class="col-auto">
                        <select name="per_page" class="form-select form-select-sm" onchange="this.form.submit()">
                            <?php $__currentLoopData = [20, 50, 100, 200]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $size): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($size); ?>" <?php if($perPage === $size): echo 'selected'; endif; ?>><?php echo e($size); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="col-auto">
                        <button class="btn btn-sm btn-outline-primary"><?php echo e(__('menu.search')); ?></button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <div class="card-body table-responsive p-0">
        <table class="table table-hover mb-0 align-middle">
            <thead>
                <tr>
                    <th><?php echo e(__('menu.user_id')); ?></th>
                    <th><?php echo e(__('menu.full_name')); ?></th>
                    <th><?php echo e(__('menu.email')); ?></th>
                    <th><?php echo e(__('menu.phone')); ?></th>
                    <th><?php echo e(__('menu.registration_method')); ?></th>
                    <th><?php echo e(__('menu.account_type')); ?></th>
                    <th><?php echo e(__('menu.tenant')); ?></th>
                    <th><?php echo e(__('menu.status')); ?></th>
                    <th><?php echo e(__('menu.email_verification')); ?></th>
                    <th><?php echo e(__('menu.date')); ?></th>
                    <th class="text-end"><?php echo e(__('menu.actions')); ?></th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td><code><?php echo e($customer->public_id); ?></code></td>
                        <td><?php echo e($customer->name); ?></td>
                        <td><?php echo e($customer->email); ?></td>
                        <td><?php echo e($customer->phone ?? '—'); ?></td>
                        <td>
                            <span class="badge <?php echo e($customer->registrationMethodBadgeClass()); ?>">
                                <?php echo e($customer->registrationMethodLabel()); ?>

                            </span>
                        </td>
                        <td>
                            <span class="badge <?php echo e($customer->accountSubscriptionBadgeClass()); ?>">
                                <?php echo e($customer->accountSubscriptionLabel()); ?>

                            </span>
                        </td>
                        <td>
                            <?php if($customer->linkedTenants()->isEmpty()): ?>
                                <span class="text-muted"><?php echo e(__('menu.no_tenant')); ?></span>
                            <?php else: ?>
                                <ul class="list-unstyled mb-0 small">
                                    <?php $__currentLoopData = $customer->linkedTenants(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $linkedTenant): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li class="mb-1">
                                            <span><?php echo e($linkedTenant->name); ?></span>
                                            <code class="ms-1"><?php echo e($linkedTenant->id); ?></code>
                                            <span class="badge <?php echo e($linkedTenant->isPremiumLicensed() ? 'text-bg-warning' : 'text-bg-info'); ?> ms-1">
                                                <?php echo e($linkedTenant->subscriptionLabel()); ?>

                                            </span>
                                            <?php if($customer->ownsTenant($linkedTenant)): ?>
                                                <span class="badge text-bg-primary ms-1"><?php echo e(__('menu.tenant_owner')); ?></span>
                                            <?php endif; ?>
                                        </li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            <?php endif; ?>
                        </td>
                        <td>
                            <span class="badge <?php echo e($customer->is_active ? 'text-bg-success' : 'text-bg-secondary'); ?>">
                                <?php echo e($customer->is_active ? __('menu.active') : __('menu.inactive')); ?>

                            </span>
                        </td>
                        <td>
                            <?php if($customer->registeredViaOAuth()): ?>
                                <span class="badge text-bg-success"><?php echo e(__('menu.verified')); ?></span>
                            <?php else: ?>
                                <span class="badge <?php echo e($customer->hasVerifiedEmail() ? 'text-bg-success' : 'text-bg-warning'); ?>">
                                    <?php echo e($customer->hasVerifiedEmail() ? __('menu.verified') : __('menu.unverified')); ?>

                                </span>
                            <?php endif; ?>
                        </td>
                        <td><?php echo e($customer->created_at?->format('d.m.Y H:i')); ?></td>
                        <td class="text-end">
                            <div class="btn-group btn-group-sm flex-wrap justify-content-end">
                                <button type="button" class="btn btn-outline-secondary" data-bs-toggle="modal" data-bs-target="#resetPwd<?php echo e($customer->id); ?>"><?php echo e(__('menu.reset_password')); ?></button>
                                <form action="<?php echo e(route('platform.customers.toggle-email-verification', $customer)); ?>" method="POST" class="d-inline">
                                    <?php echo csrf_field(); ?>
                                    <button class="btn btn-outline-<?php echo e($customer->hasVerifiedEmail() ? 'warning' : 'success'); ?>">
                                        <?php echo e($customer->hasVerifiedEmail() ? __('menu.revoke_verification') : __('menu.verify_email')); ?>

                                    </button>
                                </form>
                                <form action="<?php echo e(route('platform.customers.toggle-2fa', $customer)); ?>" method="POST" class="d-inline">
                                    <?php echo csrf_field(); ?>
                                    <button class="btn btn-outline-secondary" <?php if(!\App\Support\SecurityPolicy::bool('security_2fa_enabled_globally') || ! $customer->hasTwoFactorConfigured()): echo 'disabled'; endif; ?>>
                                        <?php echo e(__('menu.disable_2fa')); ?>

                                    </button>
                                </form>
                                <form action="<?php echo e(route('platform.customers.reset-2fa', $customer)); ?>" method="POST" class="d-inline" onsubmit="return confirm('<?php echo e(__('menu.two_factor_reset_confirm')); ?>')">
                                    <?php echo csrf_field(); ?>
                                    <button class="btn btn-outline-warning" <?php if(!\App\Support\SecurityPolicy::bool('security_2fa_enabled_globally') || ! $customer->hasTwoFactorConfigured()): echo 'disabled'; endif; ?>>
                                        <?php echo e(__('menu.reset_2fa')); ?>

                                    </button>
                                </form>
                                <button type="button" class="btn btn-outline-secondary" data-bs-toggle="modal" data-bs-target="#changeEmail<?php echo e($customer->id); ?>"><?php echo e(__('menu.change_email')); ?></button>
                                <form action="<?php echo e(route('platform.customers.send-reset-link', $customer)); ?>" method="POST" class="d-inline">
                                    <?php echo csrf_field(); ?>
                                    <button class="btn btn-outline-info"><?php echo e(__('menu.send_reset_link')); ?></button>
                                </form>
                                <form action="<?php echo e(route('platform.customers.toggle-active', $customer)); ?>" method="POST" class="d-inline">
                                    <?php echo csrf_field(); ?>
                                    <button class="btn btn-outline-warning"><?php echo e($customer->is_active ? __('menu.deactivate') : __('menu.activate')); ?></button>
                                </form>
                                <button type="button" class="btn btn-outline-primary" data-bs-toggle="modal" data-bs-target="#tenantModal<?php echo e($customer->id); ?>"><?php echo e(__('menu.tenant')); ?></button>
                                <form action="<?php echo e(route('platform.customers.destroy', $customer)); ?>" method="POST" class="d-inline" onsubmit="return confirm('<?php echo e(__('menu.confirm_delete')); ?>')">
                                    <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                                    <button class="btn btn-outline-danger"><?php echo e(__('menu.delete')); ?></button>
                                </form>
                            </div>

                            <div class="modal fade" id="resetPwd<?php echo e($customer->id); ?>" tabindex="-1">
                                <div class="modal-dialog">
                                    <div class="modal-content">
                                        <form method="POST" action="<?php echo e(route('platform.customers.reset-password', $customer)); ?>">
                                            <?php echo csrf_field(); ?>
                                            <div class="modal-header"><h5 class="modal-title"><?php echo e(__('menu.reset_password')); ?></h5><button type="button" class="btn-close" data-bs-dismiss="modal"></button></div>
                                            <div class="modal-body">
                                                <div class="mb-3"><label class="form-label"><?php echo e(__('menu.password')); ?></label><input type="password" name="password" class="form-control" required></div>
                                                <div class="mb-3"><label class="form-label"><?php echo e(__('menu.password_confirm')); ?></label><input type="password" name="password_confirmation" class="form-control" required></div>
                                            </div>
                                            <div class="modal-footer"><button class="btn btn-primary"><?php echo e(__('menu.save')); ?></button></div>
                                        </form>
                                    </div>
                                </div>
                            </div>

                            <div class="modal fade" id="changeEmail<?php echo e($customer->id); ?>" tabindex="-1">
                                <div class="modal-dialog">
                                    <div class="modal-content">
                                        <form method="POST" action="<?php echo e(route('platform.customers.change-email', $customer)); ?>">
                                            <?php echo csrf_field(); ?>
                                            <div class="modal-header"><h5 class="modal-title"><?php echo e(__('menu.change_email')); ?></h5><button type="button" class="btn-close" data-bs-dismiss="modal"></button></div>
                                            <div class="modal-body">
                                                <input type="email" name="email" class="form-control" value="<?php echo e($customer->email); ?>" required>
                                            </div>
                                            <div class="modal-footer"><button class="btn btn-primary"><?php echo e(__('menu.save')); ?></button></div>
                                        </form>
                                    </div>
                                </div>
                            </div>

                            <div class="modal fade" id="tenantModal<?php echo e($customer->id); ?>" tabindex="-1">
                                <div class="modal-dialog">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <h5 class="modal-title"><?php echo e(__('menu.assign_tenant')); ?></h5>
                                            <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                                        </div>
                                        <div class="modal-body">
                                            <p class="text-muted small"><?php echo e(__('menu.assign_tenant_hint')); ?></p>

                                            <?php ($linkedTenants = $customer->linkedTenants()); ?>
                                            <?php if($linkedTenants->isNotEmpty()): ?>
                                                <ul class="list-group mb-3">
                                                    <?php $__currentLoopData = $linkedTenants; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $linkedTenant): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <li class="list-group-item d-flex justify-content-between align-items-center">
                                                            <div>
                                                                <strong><?php echo e($linkedTenant->name); ?></strong>
                                                                <code class="ms-2"><?php echo e($linkedTenant->id); ?></code>
                                                                <?php if($customer->ownsTenant($linkedTenant)): ?>
                                                                    <span class="badge text-bg-primary ms-1"><?php echo e(__('menu.tenant_owner')); ?></span>
                                                                <?php endif; ?>
                                                            </div>
                                                            <?php if($customer->isLinkedToTenant($linkedTenant)): ?>
                                                                <form action="<?php echo e(route('platform.customers.tenants.detach', [$customer, $linkedTenant])); ?>" method="POST"
                                                                      onsubmit="return confirm('<?php echo e(__('menu.confirm_remove_tenant')); ?>')">
                                                                    <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                                                                    <button class="btn btn-sm btn-outline-danger"><?php echo e(__('menu.remove_tenant')); ?></button>
                                                                </form>
                                                            <?php endif; ?>
                                                        </li>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </ul>
                                            <?php else: ?>
                                                <p class="text-muted"><?php echo e(__('menu.no_tenant')); ?></p>
                                            <?php endif; ?>

                                            <form method="POST" action="<?php echo e(route('platform.customers.tenants.attach', $customer)); ?>">
                                                <?php echo csrf_field(); ?>
                                                <label class="form-label"><?php echo e(__('menu.add_tenant_assignment')); ?></label>
                                                <div class="input-group">
                                                    <input type="text" name="tenant_id" class="form-control font-monospace"
                                                           placeholder="123-456" pattern="\d{3}-\d{3}" maxlength="7">
                                                    <button class="btn btn-primary"><?php echo e(__('menu.add')); ?></button>
                                                </div>
                                                <div class="form-text"><?php echo e(__('menu.assign_tenant_id_hint')); ?></div>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr><td colspan="11" class="text-center text-muted"><?php echo e(__('menu.no_data')); ?></td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
    <?php if($customers->hasPages()): ?>
        <div class="card-footer"><?php echo e($customers->links()); ?></div>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('theme::layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\faltun\Desktop\Menu-One\themes/adminlte4/pages/platform/customers/index.blade.php ENDPATH**/ ?>