<?php if(count($providers = \App\Support\OAuthPolicy::enabledProviders()) > 0): ?>
    <div class="oauth-divider"><?php echo e(__('menu.or_continue_with')); ?></div>
    <div class="oauth-buttons">
        <?php if(in_array('google', $providers, true) && ($intent !== 'register' || \App\Support\OAuthPolicy::allowRegister()) && ($intent !== 'login' || \App\Support\OAuthPolicy::allowLogin())): ?>
            <a href="<?php echo e(route('oauth.redirect', ['provider' => 'google', 'intent' => $intent ?? 'login'])); ?>" class="oauth-btn oauth-btn-google">
                <i class="fab fa-google"></i> Google
            </a>
        <?php endif; ?>
        <?php if(in_array('microsoft', $providers, true) && ($intent !== 'register' || \App\Support\OAuthPolicy::allowRegister()) && ($intent !== 'login' || \App\Support\OAuthPolicy::allowLogin())): ?>
            <a href="<?php echo e(route('oauth.redirect', ['provider' => 'microsoft', 'intent' => $intent ?? 'login'])); ?>" class="oauth-btn oauth-btn-microsoft">
                <i class="fab fa-microsoft"></i> Microsoft
            </a>
        <?php endif; ?>
    </div>
<?php endif; ?>
<?php /**PATH C:\Users\faltun\Desktop\Menu-One\themes/adminlte4/partials/auth/oauth-buttons.blade.php ENDPATH**/ ?>