<?php ($license = $cafe->currentLicense); ?>
<span class="badge <?php echo e($cafe->isPremiumLicensed() ? 'text-bg-warning' : 'text-bg-info'); ?>"><?php echo e($cafe->subscriptionLabel()); ?></span>
<?php if($license): ?>
    <div class="small text-muted mt-1">
        <div><?php echo e(__('menu.license_type')); ?>: <strong><?php echo e($license->licenseType?->name ?? '—'); ?></strong></div>
        <div><?php echo e(__('menu.license_starts_at')); ?>: <?php echo e($license->starts_at?->format('d.m.Y H:i') ?? '—'); ?></div>
        <div><?php echo e(__('menu.license_expires_at')); ?>: <?php echo e($license->expires_at?->format('d.m.Y H:i') ?? '—'); ?></div>
    </div>
<?php else: ?>
    <div class="small text-muted mt-1"><?php echo e(__('menu.no_license')); ?></div>
<?php endif; ?>
<?php /**PATH C:\Users\faltun\Desktop\Menu-One\themes/adminlte4/partials/cafe-license-info.blade.php ENDPATH**/ ?>