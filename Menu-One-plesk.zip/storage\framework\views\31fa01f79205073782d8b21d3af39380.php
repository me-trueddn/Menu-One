<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <?php if(auth()->guard()->check()): ?>
    <meta name="login-url" content="<?php echo e(route('login')); ?>">
    <?php endif; ?>
    <title><?php echo $__env->yieldContent('title', config('app.name')); ?></title>
    <link rel="icon" href="<?php echo e(\App\Support\Branding::faviconUrl()); ?>">
    <?php echo $__env->make('theme::partials.seo-head', ['isPublicPage' => false], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/themes/adminlte4.css', 'resources/js/themes/adminlte4.js']); ?>
    <?php echo $__env->yieldPushContent('styles'); ?>
    <?php if(auth()->guard()->check()): ?>
    <?php echo $__env->make('theme::partials.branding-styles', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <?php endif; ?>
</head>
<body class="layout-fixed sidebar-expand-lg bg-body-tertiary">
<?php echo $__env->make('theme::partials.seo-body', ['isPublicPage' => false], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php ($currentUser = auth()->user()); ?>
<?php echo $__env->make('theme::partials.impersonation-banner', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php echo $__env->make('theme::partials.support-banner', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<div class="app-wrapper">
    <?php echo $__env->make('theme::partials.navbar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <?php echo $__env->make('theme::partials.sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <main class="app-main">
        <div class="app-content-header">
            <div class="container-fluid">
                <div class="row align-items-center">
                    <div class="col-sm-6">
                        <h3 class="mb-0"><?php echo $__env->yieldContent('page-title', config('app.name')); ?></h3>
                    </div>
                    <div class="col-sm-6">
                        <div class="float-sm-end d-flex gap-2 flex-wrap">
                            <?php echo $__env->yieldContent('page-actions'); ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="app-content">
            <div class="container-fluid">
                <?php echo $__env->make('theme::partials.alerts', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                <?php echo $__env->yieldContent('content'); ?>
            </div>
        </div>
    </main>

    <?php echo $__env->make('theme::partials.footer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
</div>
<?php echo $__env->yieldPushContent('scripts'); ?>
</body>
</html>
<?php /**PATH C:\Users\faltun\Desktop\Menu-One\themes/adminlte4/layouts/app.blade.php ENDPATH**/ ?>