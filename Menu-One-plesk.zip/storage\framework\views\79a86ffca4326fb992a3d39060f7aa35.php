<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title><?php echo $__env->yieldContent('seo_title', \App\Support\SeoPolicy::metaTitle(config('app.name').' - '.__('menu.login'))); ?></title>
    <link rel="icon" href="<?php echo e(\App\Support\Branding::faviconUrl()); ?>">
    <?php echo $__env->make('theme::partials.seo-head', ['isPublicPage' => true], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <?php if(\App\Support\CaptchaPolicy::configured()): ?>
        <?php if(\App\Support\CaptchaPolicy::provider() === 'google'): ?>
            <script src="https://www.google.com/recaptcha/api.js" async defer></script>
        <?php elseif(\App\Support\CaptchaPolicy::provider() === 'turnstile'): ?>
            <script src="https://challenges.cloudflare.com/turnstile/v0/api.js" async defer></script>
        <?php endif; ?>
    <?php endif; ?>
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/themes/login.css', 'resources/js/themes/login.js']); ?>
</head>
<body>
<?php echo $__env->make('theme::partials.seo-body', ['isPublicPage' => true], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

<div class="login-wrapper">
    <?php echo $__env->make('theme::partials.auth.login-slider', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <div class="login-right">
        <?php echo $__env->yieldContent('content'); ?>
    </div>
</div>

<?php if(\App\Support\CaptchaPolicy::registrationEnabled()): ?>
    <?php echo $__env->make('theme::partials.auth.register-panel', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php endif; ?>

<?php echo $__env->yieldPushContent('scripts'); ?>
</body>
</html>
<?php /**PATH C:\Users\faltun\Desktop\Menu-One\themes/adminlte4/layouts/auth.blade.php ENDPATH**/ ?>