<div class="card mt-3">
    <div class="card-header d-flex justify-content-between align-items-center">
        <h6 class="mb-0"><?php echo e(__('menu.cafe_staff')); ?></h6>
    </div>
    <div class="card-body">
        <form method="POST" action="<?php echo e(route('platform.tenants.staff.store', $tenant)); ?>" class="row g-2 align-items-end mb-3" id="platformStaffForm">
            <?php echo csrf_field(); ?>
            <div class="col-md-5">
                <label class="form-label"><?php echo e(__('menu.email')); ?></label>
                <div class="input-group">
                    <input type="email" name="email" id="platformStaffEmail" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e(old('email')); ?>" required>
                    <button type="button" class="btn btn-outline-secondary" id="platformStaffLookup"><?php echo e(__('menu.search_user')); ?></button>
                </div>
                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="invalid-feedback d-block"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="col-md-4">
                <label class="form-label"><?php echo e(__('menu.role')); ?></label>
                <select name="role" class="form-select">
                    <?php $__currentLoopData = \App\Services\CafeStaffService::assignableRoles(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($role); ?>"><?php echo e(__('menu.role_'.$role)); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div class="col-md-3">
                <button type="submit" class="btn btn-primary w-100" id="platformStaffSubmit" disabled><?php echo e(__('menu.send_invitation')); ?></button>
            </div>
        </form>
        <div id="platformStaffResult" class="alert d-none small"></div>

        <?php echo $__env->make('theme::partials.staff-invitations-panel', [
            'invitations' => $tenant->staffInvitations,
            'revokeRoute' => fn ($invitation) => route('platform.tenants.staff.invitations.revoke', [$tenant, $invitation]),
        ], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

        <div class="table-responsive">
            <table class="table table-sm mb-0">
                <thead>
                    <tr>
                        <th><?php echo e(__('menu.full_name')); ?></th>
                        <th><?php echo e(__('menu.email')); ?></th>
                        <th><?php echo e(__('menu.role')); ?></th>
                        <th class="text-end"><?php echo e(__('menu.actions')); ?></th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $tenant->staffUsers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $member): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <?php if($member->hasAnyRole(\App\Services\CafeStaffService::assignableRoles())): ?>
                            <tr>
                                <td><?php echo e($member->name); ?></td>
                                <td><?php echo e($member->email); ?></td>
                                <td>
                                    <form method="POST" action="<?php echo e(route('platform.tenants.staff.update', [$tenant, $member])); ?>" class="d-flex gap-1">
                                        <?php echo csrf_field(); ?> <?php echo method_field('PUT'); ?>
                                        <select name="role" class="form-select form-select-sm" onchange="this.form.submit()">
                                            <?php $__currentLoopData = \App\Services\CafeStaffService::assignableRoles(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($role); ?>" <?php if($member->hasRole($role)): echo 'selected'; endif; ?>><?php echo e(__('menu.role_'.$role)); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </form>
                                </td>
                                <td class="text-end">
                                    <form action="<?php echo e(route('platform.tenants.staff.impersonate', [$tenant, $member])); ?>" method="POST" class="d-inline">
                                        <?php echo csrf_field(); ?>
                                        <button class="btn btn-sm btn-outline-info" title="<?php echo e(__('menu.connect_as_user')); ?>"><i class="bi bi-box-arrow-in-right"></i></button>
                                    </form>
                                    <form action="<?php echo e(route('platform.tenants.staff.destroy', [$tenant, $member])); ?>" method="POST" class="d-inline" onsubmit="return confirm('<?php echo e(__('menu.confirm_remove_staff')); ?>')">
                                        <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                                        <button class="btn btn-sm btn-outline-danger"><i class="bi bi-trash"></i></button>
                                    </form>
                                </td>
                            </tr>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr><td colspan="4" class="text-muted text-center"><?php echo e(__('menu.no_staff')); ?></td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php $__env->startPush('scripts'); ?>
<script>
document.addEventListener('DOMContentLoaded', function () {
    const emailInput = document.getElementById('platformStaffEmail');
    const lookupBtn = document.getElementById('platformStaffLookup');
    const resultBox = document.getElementById('platformStaffResult');
    const submitBtn = document.getElementById('platformStaffSubmit');
    if (!emailInput || !lookupBtn) return;
    const csrf = document.querySelector('meta[name="csrf-token"]').content;

    lookupBtn.addEventListener('click', async function () {
        resultBox.classList.add('d-none');
        submitBtn.disabled = true;
        const response = await fetch(<?php echo json_encode(route('platform.tenants.staff.lookup', $tenant), 512) ?>, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json', 'X-CSRF-TOKEN': csrf, 'Accept': 'application/json' },
            body: JSON.stringify({ email: emailInput.value }),
        });
        const data = await response.json();
        resultBox.classList.remove('d-none', 'alert-success', 'alert-danger');
        if (data.found) {
            resultBox.classList.add('alert-success');
            resultBox.textContent = data.name + ' (' + data.email + ')';
            submitBtn.disabled = false;
        } else {
            resultBox.classList.add('alert-danger');
            resultBox.textContent = data.message;
        }
    });
});
</script>
<?php $__env->stopPush(); ?>
<?php /**PATH C:\Users\faltun\Desktop\Menu-One\themes/adminlte4/partials/tenant-staff-panel.blade.php ENDPATH**/ ?>