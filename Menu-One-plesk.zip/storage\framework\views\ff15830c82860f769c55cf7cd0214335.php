

<?php $__env->startSection('title', __('menu.mail_configuration')); ?>
<?php $__env->startSection('page-title', __('menu.mail_configuration')); ?>

<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="card-header">
        <h5 class="mb-0"><?php echo e(__('menu.mail_settings')); ?></h5>
    </div>
    <div class="card-body">
        <form method="POST" action="<?php echo e(route('platform.settings.mail.update')); ?>" id="mailSettingsForm">
            <?php echo csrf_field(); ?> <?php echo method_field('PUT'); ?>

            <div class="mb-4">
                <label class="form-label"><?php echo e(__('menu.mail_provider_preset')); ?></label>
                <select id="mailProviderPreset" class="form-select">
                    <option value=""><?php echo e(__('menu.mail_provider_custom')); ?></option>
                    <?php $__currentLoopData = $mailProviders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $provider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($key); ?>"
                                data-host="<?php echo e($provider['host']); ?>"
                                data-port="<?php echo e($provider['port']); ?>"
                                data-encryption="<?php echo e($provider['encryption']); ?>">
                            <?php echo e($provider['label']); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <div class="form-text"><?php echo e(__('menu.mail_provider_hint')); ?></div>
                <div id="yandexSetupHint" class="alert alert-info small mt-3 mb-0 d-none">
                    <strong><?php echo e(__('menu.mail_yandex_setup_title')); ?></strong>
                    <p class="mb-0 mt-1"><?php echo e(__('menu.mail_yandex_setup_body')); ?></p>
                </div>
            </div>

            <div class="row">
                <div class="col-md-4 mb-3">
                    <label class="form-label"><?php echo e(__('menu.mail_driver')); ?></label>
                    <select name="mail_mailer" id="mail_mailer" class="form-select <?php $__errorArgs = ['mail_mailer'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required>
                        <option value="smtp" <?php if(old('mail_mailer', $settings['mail_mailer']) === 'smtp'): echo 'selected'; endif; ?>>SMTP</option>
                        <option value="log" <?php if(old('mail_mailer', $settings['mail_mailer']) === 'log'): echo 'selected'; endif; ?>>Log</option>
                        <option value="sendmail" <?php if(old('mail_mailer', $settings['mail_mailer']) === 'sendmail'): echo 'selected'; endif; ?>>Sendmail</option>
                    </select>
                    <?php $__errorArgs = ['mail_mailer'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="invalid-feedback"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="col-md-4 mb-3">
                    <label class="form-label"><?php echo e(__('menu.mail_encryption')); ?></label>
                    <select name="mail_encryption" id="mail_encryption" class="form-select <?php $__errorArgs = ['mail_encryption'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                        <option value="tls" <?php if(old('mail_encryption', $settings['mail_encryption'] ?: 'tls') === 'tls'): echo 'selected'; endif; ?>>TLS</option>
                        <option value="ssl" <?php if(old('mail_encryption', $settings['mail_encryption']) === 'ssl'): echo 'selected'; endif; ?>>SSL</option>
                        <option value="none" <?php if(old('mail_encryption', $settings['mail_encryption']) === '' || old('mail_encryption', $settings['mail_encryption']) === 'none'): echo 'selected'; endif; ?>><?php echo e(__('menu.none')); ?></option>
                    </select>
                    <?php $__errorArgs = ['mail_encryption'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="invalid-feedback"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="col-md-4 mb-3">
                    <label class="form-label"><?php echo e(__('menu.mail_port')); ?></label>
                    <input name="mail_port" id="mail_port" type="number" class="form-control <?php $__errorArgs = ['mail_port'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                           value="<?php echo e(old('mail_port', $settings['mail_port'])); ?>">
                    <?php $__errorArgs = ['mail_port'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="invalid-feedback"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>

            <div class="row">
                <div class="col-md-6 mb-3">
                    <label class="form-label"><?php echo e(__('menu.mail_host')); ?></label>
                    <input name="mail_host" id="mail_host" class="form-control <?php $__errorArgs = ['mail_host'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                           value="<?php echo e(old('mail_host', $settings['mail_host'])); ?>" placeholder="smtp.example.com">
                    <?php $__errorArgs = ['mail_host'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="invalid-feedback"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="col-md-6 mb-3">
                    <label class="form-label"><?php echo e(__('menu.mail_username')); ?></label>
                    <input name="mail_username" class="form-control <?php $__errorArgs = ['mail_username'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                           value="<?php echo e(old('mail_username', $settings['mail_username'])); ?>">
                    <?php $__errorArgs = ['mail_username'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="invalid-feedback"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>

            <div class="mb-3">
                <label class="form-label"><?php echo e(__('menu.mail_password')); ?></label>
                <input type="password" name="mail_password" class="form-control <?php $__errorArgs = ['mail_password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                       placeholder="<?php echo e($settings['has_password'] ? '••••••••' : ''); ?>" autocomplete="new-password">
                <?php $__errorArgs = ['mail_password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="invalid-feedback"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                <?php if($settings['has_password']): ?>
                    <div class="form-text"><?php echo e(__('menu.mail_password_hint')); ?></div>
                <?php endif; ?>
            </div>

            <div class="row">
                <div class="col-md-4 mb-3">
                    <label class="form-label"><?php echo e(__('menu.mail_timeout_seconds')); ?></label>
                    <input name="mail_timeout_seconds" type="number" min="5" max="120"
                           class="form-control <?php $__errorArgs = ['mail_timeout_seconds'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                           value="<?php echo e(old('mail_timeout_seconds', $settings['mail_timeout_seconds'])); ?>" required>
                    <?php $__errorArgs = ['mail_timeout_seconds'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="invalid-feedback"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    <div class="form-text"><?php echo e(__('menu.mail_timeout_hint')); ?></div>
                </div>
            </div>

            <hr>

            <div class="row">
                <div class="col-md-6 mb-3">
                    <label class="form-label"><?php echo e(__('menu.mail_from_address')); ?></label>
                    <input name="mail_from_address" type="email" class="form-control <?php $__errorArgs = ['mail_from_address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                           value="<?php echo e(old('mail_from_address', $settings['mail_from_address'])); ?>">
                    <?php $__errorArgs = ['mail_from_address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="invalid-feedback"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="col-md-6 mb-3">
                    <label class="form-label"><?php echo e(__('menu.mail_from_name')); ?></label>
                    <input name="mail_from_name" class="form-control <?php $__errorArgs = ['mail_from_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                           value="<?php echo e(old('mail_from_name', $settings['mail_from_name'])); ?>">
                    <?php $__errorArgs = ['mail_from_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="invalid-feedback"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>

            <button type="submit" class="btn btn-primary"><?php echo e(__('menu.save')); ?></button>
        </form>
    </div>
</div>

<div class="card mt-3">
    <div class="card-header">
        <h5 class="mb-0"><?php echo e(__('menu.mail_test_title')); ?></h5>
    </div>
    <div class="card-body">
        <p class="text-muted small mb-3"><?php echo e(__('menu.mail_test_hint')); ?></p>
        <form method="POST" action="<?php echo e(route('platform.settings.mail.test')); ?>" id="mailTestForm">
            <?php echo csrf_field(); ?>
            <div class="row align-items-end g-3">
                <div class="col-md-8">
                    <label class="form-label" for="test_email"><?php echo e(__('menu.mail_test_recipient')); ?></label>
                    <input type="email" id="test_email" name="test_email"
                           class="form-control <?php $__errorArgs = ['test_email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                           value="<?php echo e(old('test_email', auth()->user()->email)); ?>"
                           placeholder="ornek@firma.com" required>
                    <?php $__errorArgs = ['test_email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="invalid-feedback d-block"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="col-md-4">
                    <button type="submit" class="btn btn-outline-primary w-100">
                        <i class="bi bi-send"></i> <?php echo e(__('menu.mail_test_send')); ?>

                    </button>
                </div>
            </div>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
function toggleYandexHint() {
    const host = (document.getElementById('mail_host')?.value || '').toLowerCase();
    const hint = document.getElementById('yandexSetupHint');
    if (!hint) return;
    hint.classList.toggle('d-none', !host.includes('yandex'));
}

document.getElementById('mailProviderPreset')?.addEventListener('change', function () {
    const opt = this.selectedOptions[0];
    if (!opt || !opt.value) return;
    document.getElementById('mail_host').value = opt.dataset.host || '';
    document.getElementById('mail_port').value = opt.dataset.port || '';
    document.getElementById('mail_encryption').value = opt.dataset.encryption || 'tls';
    document.getElementById('mail_mailer').value = 'smtp';
    toggleYandexHint();
});

document.getElementById('mail_host')?.addEventListener('input', toggleYandexHint);
toggleYandexHint();

document.getElementById('mailTestForm')?.addEventListener('submit', function () {
    const src = document.getElementById('mailSettingsForm');
    const fields = ['mail_mailer', 'mail_host', 'mail_port', 'mail_username', 'mail_password', 'mail_encryption', 'mail_from_address', 'mail_from_name'];
    fields.forEach(function (name) {
        let input = document.querySelector('#mailTestForm input[name="' + name + '"]');
        if (!input) {
            input = document.createElement('input');
            input.type = 'hidden';
            input.name = name;
            document.getElementById('mailTestForm').appendChild(input);
        }
        const source = src.querySelector('[name="' + name + '"]');
        input.value = source ? source.value : '';
    });
});
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('theme::layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\faltun\Desktop\Menu-One\themes/adminlte4/pages/platform/settings/mail.blade.php ENDPATH**/ ?>