<?php $__env->startSection('content'); ?>
<div class="locale-row">
    <?php echo $__env->make('theme::partials.auth.locale-switcher', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
</div>

<div class="brand-name">
    <a href="<?php echo e(route('home')); ?>"><img src="<?php echo e(\App\Support\Branding::logoUrl()); ?>" alt="<?php echo e(\App\Support\SiteConfig::name()); ?>" style="height: <?php echo e(\App\Support\Branding::logoHeight()); ?>px;"></a>
</div>

<h1 class="login-title"><?php echo e(__('menu.login_welcome')); ?></h1>
<p class="login-subtitle">
    <a href="<?php echo e(\App\Support\SiteConfig::mainSiteUrl()); ?>" target="_blank" rel="noopener"><?php echo e(parse_url(\App\Support\SiteConfig::mainSiteUrl(), PHP_URL_HOST)); ?></a>
    <?php echo e(__('menu.login_portal')); ?>

</p>

<?php if(session('status')): ?>
    <div class="alert alert-success alert-login"><?php echo e(session('status')); ?></div>
<?php endif; ?>

<?php if(session('error')): ?>
    <div class="alert alert-danger alert-login"><?php echo e(session('error')); ?></div>
<?php endif; ?>

<?php if($errors->any() && ! $errors->has('name') && ! $errors->has('phone')): ?>
    <div class="alert alert-danger alert-login">
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div><?php echo e($error); ?></div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
<?php endif; ?>

<form method="POST" action="<?php echo e(route('login')); ?>">
    <?php echo csrf_field(); ?>
    <input type="hidden" name="captcha_check" value="1">

    <div class="mb-3">
        <input id="email" type="email" name="email" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
               value="<?php echo e(old('email')); ?>" placeholder="<?php echo e(__('menu.email')); ?>" autocomplete="username" required autofocus>
    </div>

    <div class="mb-2">
        <div class="input-group">
            <input id="password" type="password" name="password"
                   class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                   placeholder="<?php echo e(__('menu.password')); ?>" autocomplete="current-password" required>
            <button class="btn-eye" type="button" id="togglePwd" title="<?php echo e(__('menu.toggle_password')); ?>">
                <i class="fa fa-eye-slash" id="eyeIcon"></i>
            </button>
        </div>
    </div>

    <?php $__errorArgs = ['captcha'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <div class="text-danger small mb-2"><?php echo e($message); ?></div>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

    <?php echo $__env->make('theme::partials.auth.captcha', ['context' => \App\Support\CaptchaPolicy::CONTEXT_LOGIN], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <div class="mb-4 d-flex justify-content-between align-items-center">
        <div class="form-check mb-0">
            <input type="checkbox" name="remember" class="form-check-input" id="remember">
            <label class="form-check-label" for="remember" style="font-size:13px;"><?php echo e(__('menu.remember_me')); ?></label>
        </div>
        <?php if(Route::has('password.request')): ?>
            <a href="<?php echo e(route('password.request')); ?>" class="forgot-link"><?php echo e(__('menu.forgot_password')); ?></a>
        <?php endif; ?>
    </div>

    <div class="d-flex gap-3 flex-wrap">
        <button type="submit" class="btn-login"><?php echo e(__('menu.login')); ?></button>
        <?php if(Route::has('register') && \App\Support\CaptchaPolicy::registrationEnabled()): ?>
            <button type="button" class="btn-register" id="openRegisterPanel"><?php echo e(__('menu.register_free')); ?></button>
        <?php endif; ?>
    </div>
</form>

<?php echo $__env->make('theme::partials.auth.oauth-buttons', ['intent' => 'login'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

<hr class="divider">

<p class="contact-title"><?php echo e(__('menu.contact_title')); ?></p>
<?php if($phone = \App\Support\SiteConfig::contactPhone()): ?>
    <div class="contact-item"><i class="fa fa-phone"></i><a href="tel:<?php echo e(preg_replace('/\s+/', '', $phone)); ?>"><?php echo e($phone); ?></a></div>
<?php endif; ?>
<?php if($email = \App\Support\SiteConfig::supportEmail()): ?>
    <div class="contact-item"><i class="fa fa-envelope"></i><a href="mailto:<?php echo e($email); ?>"><?php echo e($email); ?></a></div>
<?php endif; ?>
<div class="contact-item">
    <i class="fa fa-globe"></i>
    <a href="<?php echo e(\App\Support\SiteConfig::mainSiteUrl()); ?>" target="_blank" rel="noopener"><?php echo e(parse_url(\App\Support\SiteConfig::mainSiteUrl(), PHP_URL_HOST)); ?></a>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<?php if($errors->any() && ($errors->has('name') || $errors->has('phone'))): ?>
<script>
document.addEventListener('DOMContentLoaded', function () {
    const overlay = document.getElementById('registerOverlay');
    if (!overlay) return;
    overlay.hidden = false;
    overlay.classList.add('open');
    overlay.setAttribute('aria-hidden', 'false');
    document.body.classList.add('register-open');
});
</script>
<?php elseif(request()->boolean('register')): ?>
<script>
document.addEventListener('DOMContentLoaded', function () {
    const overlay = document.getElementById('registerOverlay');
    if (!overlay) return;
    overlay.hidden = false;
    overlay.classList.add('open');
    overlay.setAttribute('aria-hidden', 'false');
    document.body.classList.add('register-open');
});
</script>
<?php endif; ?>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('theme::layouts.auth', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\faltun\Desktop\Menu-One\resources\views/auth/login.blade.php ENDPATH**/ ?>