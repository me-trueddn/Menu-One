

<?php $__env->startSection('title', __('menu.products')); ?>
<?php $__env->startSection('page-title', __('menu.products')); ?>

<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="card-header">
        <div class="row g-2 align-items-center">
            <div class="col-md-4 d-flex align-items-center gap-2">
                <h5 class="mb-0"><?php echo e(__('menu.products')); ?></h5>
                <button type="button" class="btn btn-primary btn-sm" data-bs-toggle="modal" data-bs-target="#productFormModal">
                    <i class="bi bi-plus-lg"></i> <?php echo e(__('menu.add_product')); ?>

                </button>
            </div>
            <div class="col-md-8">
                <form method="GET" action="<?php echo e(route('admin.products.index')); ?>" class="row g-2 justify-content-end">
                    <div class="col-auto flex-grow-1" style="min-width:12rem">
                        <input type="search" name="q" value="<?php echo e($search ?? ''); ?>" class="form-control form-control-sm"
                               placeholder="<?php echo e(__('menu.product_search_placeholder')); ?>">
                    </div>
                    <div class="col-auto">
                        <button type="submit" class="btn btn-sm btn-outline-primary"><?php echo e(__('menu.search')); ?></button>
                    </div>
                    <?php if(!empty($search)): ?>
                        <div class="col-auto">
                            <a href="<?php echo e(route('admin.products.index')); ?>" class="btn btn-sm btn-outline-secondary"><?php echo e(__('menu.clear')); ?></a>
                        </div>
                    <?php endif; ?>
                </form>
            </div>
        </div>
    </div>
    <div class="card-body table-responsive p-0">
        <table class="table table-hover mb-0 align-middle">
            <thead>
                <tr>
                    <th><?php echo e(__('menu.product_name')); ?></th>
                    <th><?php echo e(__('menu.product_code')); ?></th>
                    <th><?php echo e(__('menu.product_categories')); ?></th>
                    <th><?php echo e(__('menu.product_sale_price')); ?></th>
                    <th><?php echo e(__('menu.product_status')); ?></th>
                    <th class="text-end"><?php echo e(__('menu.actions')); ?></th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $listedProduct): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td>
                            <div class="d-flex align-items-center gap-2">
                                <?php if($url = \App\Support\ImageStorage::url($listedProduct->image_path)): ?>
                                    <img src="<?php echo e($url); ?>" alt="" class="rounded" style="width:32px;height:32px;object-fit:cover">
                                <?php endif; ?>
                                <span><?php echo e($listedProduct->name); ?></span>
                            </div>
                        </td>
                        <td><code><?php echo e($listedProduct->code ?? '—'); ?></code></td>
                        <td><?php echo e($listedProduct->category->name); ?></td>
                        <td><?php echo e(number_format($listedProduct->price, 2)); ?> ₺</td>
                        <td>
                            <span class="badge <?php echo e($listedProduct->is_active ? 'text-bg-success' : 'text-bg-secondary'); ?>">
                                <?php echo e($listedProduct->is_active ? __('menu.product_active') : __('menu.product_inactive')); ?>

                            </span>
                        </td>
                        <td class="text-end">
                            <a href="<?php echo e(route('admin.products.edit', $listedProduct)); ?>" class="btn btn-sm btn-outline-primary"><?php echo e(__('menu.edit')); ?></a>
                            <form action="<?php echo e(route('admin.products.destroy', $listedProduct)); ?>" method="POST" class="d-inline"
                                  onsubmit="return confirm('<?php echo e(__('menu.confirm_delete')); ?>')">
                                <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                                <button class="btn btn-sm btn-outline-danger"><?php echo e(__('menu.delete')); ?></button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="6" class="text-center text-muted py-4">
                            <?php echo e(!empty($search) ? __('menu.no_products_found') : __('menu.no_data')); ?>

                        </td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
    <?php if($products->hasPages()): ?>
        <div class="card-footer"><?php echo e($products->links()); ?></div>
    <?php endif; ?>
</div>

<?php echo $__env->make('theme::partials.admin.product-form-modal', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('theme::layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\faltun\Desktop\Menu-One\themes/adminlte4/pages/admin/products/index.blade.php ENDPATH**/ ?>