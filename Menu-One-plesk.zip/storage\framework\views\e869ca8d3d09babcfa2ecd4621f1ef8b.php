<?php echo e($reservation->starts_at->format('d.m.Y H:i')); ?>

–
<?php echo e($reservation->ends_at->format('d.m.Y H:i')); ?>

<?php if($reservation->leftEarly()): ?>
    <div class="small text-muted mt-1">
        <?php echo e(__('menu.reservation_scheduled_ends_at')); ?>:
        <?php echo e($reservation->scheduled_ends_at->format('d.m.Y H:i')); ?>

    </div>
<?php endif; ?>
<?php /**PATH C:\Users\faltun\Desktop\Menu-One\themes/adminlte4/pages/reservations/_period.blade.php ENDPATH**/ ?>