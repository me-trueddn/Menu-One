
<?php
    $splitLocked = $order->splitPaidCount() > 0;
    $activeSplitCount = $splitLocked ? (int) $order->split_count : (int) old('split_count', $table->capacity);
    $activeDiscount = $splitLocked ? (float) $order->discount_percent : (float) old('discount_percent', 0);
    $nextPayment = $splitLocked ? $order->nextPaymentAmount() : $order->amountDue($activeDiscount);
    if (! $splitLocked && $activeSplitCount > 0) {
        $perPerson = round($order->amountDue($activeDiscount) / $activeSplitCount, 2);
        $nextPayment = $perPerson;
    } elseif (! $splitLocked && $activeSplitCount <= 0) {
        $nextPayment = $order->amountDue($activeDiscount);
    }
    $currentPayment = $splitLocked ? $order->splitPaidCount() + 1 : 1;
    $showSplitProgress = $splitLocked && $order->split_count > 0;
    $confirmSplitTemplate = __('menu.confirm_split_payment', [
        'amount' => ':amount',
        'current' => ':current',
        'total' => ':total',
    ]);
?>
<?php $__env->startSection('title', __('menu.take_payment')); ?>
<?php $__env->startSection('page-title', $table->name.' — '.__('menu.take_payment')); ?>
<?php $__env->startSection('content'); ?>
<div class="row g-3">
    <div class="col-lg-7">
        <div class="card">
            <div class="card-header d-flex justify-content-between align-items-center flex-wrap gap-2">
                <h5 class="mb-0"><?php echo e(__('menu.order_summary')); ?></h5>
                <span class="badge <?php echo e($order->status->badgeClass()); ?>"><?php echo e($order->status->label()); ?></span>
            </div>
            <div class="card-body p-0">
                <table class="table mb-0 align-middle">
                    <thead><tr><th><?php echo e(__('menu.products')); ?></th><th><?php echo e(__('menu.qty')); ?></th><th><?php echo e(__('menu.total')); ?></th></tr></thead>
                    <tbody>
                        <?php $__currentLoopData = $order->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td>
                                    <div class="d-flex align-items-center gap-2">
                                        <img src="<?php echo e($item->product->imageUrl()); ?>" alt="<?php echo e($item->product->name); ?>"
                                             class="payment-product-thumb rounded flex-shrink-0">
                                        <span><?php echo e($item->product->name); ?></span>
                                    </div>
                                </td>
                                <td><?php echo e($item->qty); ?></td>
                                <td><?php echo e(number_format($item->lineTotal(), 2)); ?> ₺</td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                    <tfoot>
                        <tr><th colspan="2"><?php echo e(__('menu.subtotal')); ?></th><th><?php echo e(number_format($order->total, 2)); ?> ₺</th></tr>
                    </tfoot>
                </table>
            </div>
        </div>
    </div>
    <div class="col-lg-5">
        <div class="card">
            <div class="card-header"><h5 class="mb-0"><?php echo e(__('menu.payment')); ?></h5></div>
            <div class="card-body">
                <?php if($showSplitProgress): ?>
                    <div class="alert alert-info py-2">
                        <div class="fw-semibold"><?php echo e(__('menu.split_payment_progress', ['paid' => $order->split_paid_count, 'total' => $order->split_count])); ?></div>
                    </div>
                <?php endif; ?>
                <form method="POST" action="<?php echo e(route('cashier.orders.pay', $order)); ?>" id="paymentForm">
                    <?php echo csrf_field(); ?>
                    <div class="mb-3">
                        <label class="form-label"><?php echo e(__('menu.payment_method')); ?></label>
                        <div class="d-flex flex-column gap-2">
                            <?php $__currentLoopData = $paymentMethods; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="form-check">
                                    <input class="form-check-input" type="radio" name="payment_method" id="pay_<?php echo e($value); ?>"
                                           value="<?php echo e($value); ?>" <?php if(old('payment_method', 'cash') === $value): echo 'checked'; endif; ?> required>
                                    <label class="form-check-label" for="pay_<?php echo e($value); ?>"><?php echo e($label); ?></label>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                        <?php $__errorArgs = ['payment_method'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="text-danger small"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="mb-3">
                        <label class="form-label" for="discountPercent"><?php echo e(__('menu.discount_percent')); ?></label>
                        <div class="input-group">
                            <input type="number" name="discount_percent" id="discountPercent" class="form-control"
                                   min="0" max="100" step="0.01"
                                   value="<?php echo e($activeDiscount); ?>"
                                   <?php if($splitLocked): echo 'disabled'; endif; ?>>
                            <span class="input-group-text">%</span>
                        </div>
                        <?php if($splitLocked): ?>
                            <input type="hidden" name="discount_percent" value="<?php echo e($activeDiscount); ?>">
                        <?php endif; ?>
                        <div class="form-text"><?php echo e(__('menu.discount_percent_hint')); ?></div>
                        <?php $__errorArgs = ['discount_percent'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="text-danger small"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="mb-3">
                        <label class="form-label"><?php echo e(__('menu.split_count')); ?></label>
                        <input type="number" name="split_count" id="splitCount" class="form-control" min="0" max="99"
                               value="<?php echo e($activeSplitCount); ?>" required <?php if($splitLocked): echo 'disabled'; endif; ?>>
                        <?php if($splitLocked): ?>
                            <input type="hidden" name="split_count" value="<?php echo e($activeSplitCount); ?>">
                        <?php endif; ?>
                        <div class="form-text"><?php echo e(__('menu.split_count_hint')); ?></div>
                        <?php $__errorArgs = ['split_count'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="text-danger small"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="alert alert-light border mb-3">
                        <div class="d-flex justify-content-between">
                            <span><?php echo e(__('menu.subtotal')); ?></span>
                            <strong id="subtotalAmount"><?php echo e(number_format($order->total, 2)); ?> ₺</strong>
                        </div>
                        <div class="d-flex justify-content-between mt-2 text-danger d-none" id="discountRow">
                            <span><?php echo e(__('menu.discount_amount')); ?></span>
                            <strong id="discountAmount">-0,00 ₺</strong>
                        </div>
                        <div class="d-flex justify-content-between mt-2 border-top pt-2">
                            <span><?php echo e(__('menu.amount_due')); ?></span>
                            <strong id="amountDue"><?php echo e(number_format($order->amountDue($activeDiscount), 2)); ?> ₺</strong>
                        </div>
                        <div class="d-flex justify-content-between mt-2">
                            <span id="paymentAmountLabel"><?php echo e($activeSplitCount > 0 ? __('menu.per_person') : __('menu.payment_full_total')); ?></span>
                            <strong id="perPersonAmount"><?php echo e(number_format($nextPayment, 2)); ?> ₺</strong>
                        </div>
                    </div>
                    <button type="submit" class="btn btn-success w-100" id="paymentSubmitBtn">
                        <?php if($showSplitProgress): ?>
                            <?php echo e(__('menu.collect_split_payment', ['current' => $currentPayment, 'total' => $order->split_count])); ?>

                        <?php else: ?>
                            <?php echo e(__('menu.complete_payment')); ?>

                        <?php endif; ?>
                    </button>
                </form>
            </div>
        </div>
    </div>
</div>
<a href="<?php echo e(route('cashier.tables.index')); ?>" class="btn btn-secondary mt-3">← <?php echo e(__('menu.back_to_tables')); ?></a>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('styles'); ?>
<style>
    .payment-product-thumb {
        width: 72px;
        height: 72px;
        object-fit: cover;
        background: var(--bs-tertiary-bg);
    }
</style>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
document.addEventListener('DOMContentLoaded', function () {
    const splitLocked = <?php echo json_encode($splitLocked, 15, 512) ?>;
    const subtotal = <?php echo e((float) $order->total); ?>;
    const splitInput = document.getElementById('splitCount');
    const discountInput = document.getElementById('discountPercent');
    const discountAmountEl = document.getElementById('discountAmount');
    const discountRow = document.getElementById('discountRow');
    const amountDueEl = document.getElementById('amountDue');
    const perPerson = document.getElementById('perPersonAmount');
    const amountLabel = document.getElementById('paymentAmountLabel');
    const paymentForm = document.getElementById('paymentForm');
    const perPersonLabel = <?php echo json_encode(__('menu.per_person'), 15, 512) ?>;
    const fullTotalLabel = <?php echo json_encode(__('menu.payment_full_total'), 15, 512) ?>;
    const confirmPayment = <?php echo json_encode(__('menu.confirm_payment'), 15, 512) ?>;
    const confirmSplitTemplate = <?php echo json_encode($confirmSplitTemplate, 15, 512) ?>;

    const formatMoney = (value) => value.toLocaleString('tr-TR', {
        minimumFractionDigits: 2,
        maximumFractionDigits: 2,
    }) + ' ₺';

    const clampPercent = (value) => Math.min(100, Math.max(0, value));

    const getDiscountPercent = () => {
        if (splitLocked) {
            return <?php echo e($activeDiscount); ?>;
        }
        const raw = parseFloat(discountInput.value);
        return Number.isNaN(raw) ? 0 : clampPercent(raw);
    };

    const getSplitCount = () => {
        if (splitLocked) {
            return <?php echo e($activeSplitCount); ?>;
        }
        const raw = parseInt(splitInput.value, 10);
        return Number.isNaN(raw) ? 0 : raw;
    };

    const getAmountDue = () => {
        const percent = getDiscountPercent();
        return Math.round(subtotal * (1 - percent / 100) * 100) / 100;
    };

    const getNextPaymentAmount = () => {
        const due = getAmountDue();
        const split = getSplitCount();

        if (split <= 0) {
            return due;
        }

        <?php if($showSplitProgress): ?>
        const paid = <?php echo e($order->split_paid_count); ?>;
        const perPerson = Math.round((due / split) * 100) / 100;
        if (paid >= split - 1) {
            return Math.round((due - perPerson * Math.max(0, split - 1)) * 100) / 100;
        }
        return perPerson;
        <?php else: ?>
        return Math.round((due / split) * 100) / 100;
        <?php endif; ?>
    };

    function updateAmounts() {
        const amountDue = getAmountDue();
        const discountAmount = Math.round((subtotal - amountDue) * 100) / 100;
        const split = getSplitCount();
        const nextAmount = getNextPaymentAmount();

        amountDueEl.textContent = formatMoney(amountDue);

        if (discountAmount > 0) {
            discountRow.classList.remove('d-none');
            discountAmountEl.textContent = '-' + formatMoney(discountAmount);
        } else {
            discountRow.classList.add('d-none');
            discountAmountEl.textContent = '-0,00 ₺';
        }

        if (split <= 0) {
            amountLabel.textContent = fullTotalLabel;
            perPerson.textContent = formatMoney(amountDue);
            return;
        }

        amountLabel.textContent = perPersonLabel;
        perPerson.textContent = formatMoney(nextAmount);
    }

    if (! splitLocked) {
        splitInput.addEventListener('input', updateAmounts);
        discountInput.addEventListener('input', updateAmounts);
    }

    paymentForm.addEventListener('submit', function (event) {
        const split = getSplitCount();
        const nextAmount = formatMoney(getNextPaymentAmount());

        if (split > 0) {
            const current = <?php echo e($showSplitProgress ? $currentPayment : 1); ?>;
            const message = confirmSplitTemplate
                .replace(':amount', nextAmount)
                .replace(':current', String(current))
                .replace(':total', String(split));

            if (! window.confirm(message)) {
                event.preventDefault();
            }
            return;
        }

        if (! window.confirm(confirmPayment)) {
            event.preventDefault();
        }
    });

    updateAmounts();
});
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('theme::layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\faltun\Desktop\Menu-One\themes/adminlte4/pages/cashier/tables/show.blade.php ENDPATH**/ ?>