<?php ($order = $table->payableOrder); ?>
<div class="col-md-3 col-sm-6 mb-3">
    <a href="<?php echo e($order ? route('cashier.tables.show', $table) : '#'); ?>"
       class="text-decoration-none <?php echo e($order ? '' : 'pe-none'); ?>"
       <?php if (! ($order)): ?> tabindex="-1" <?php endif; ?>>
        <div class="card h-100 border-<?php echo e($order ? 'primary' : 'secondary'); ?> <?php echo e($order ? '' : 'opacity-50'); ?>">
            <div class="card-body text-center">
                <h4 class="card-title mb-1"><?php echo e($table->name); ?></h4>
                <p class="mb-1">
                    <span class="badge <?php echo e($table->displayStatus()->badgeClass()); ?>"><?php echo e($table->displayStatus()->label()); ?></span>
                </p>
                <small class="text-muted"><?php echo e($table->capacity); ?> <?php echo e(__('menu.seats')); ?></small>
                <?php if($order): ?>
                    <div class="mt-2">
                        <span class="badge <?php echo e($order->status->badgeClass()); ?>"><?php echo e($order->status->label()); ?></span>
                    </div>
                    <div class="mt-2 fw-semibold"><?php echo e(number_format($order->total, 2)); ?> ₺</div>
                    <div class="mt-1"><span class="badge text-bg-success"><?php echo e(__('menu.take_payment')); ?></span></div>
                <?php endif; ?>
            </div>
        </div>
    </a>
</div>
<?php /**PATH C:\Users\faltun\Desktop\Menu-One\themes/adminlte4/partials/cashier-table-card.blade.php ENDPATH**/ ?>