<div class="modal fade mo-product-modal" id="productFormModal" tabindex="-1" aria-labelledby="productFormModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-xl modal-dialog-scrollable">
        <div class="modal-content">
            <div class="modal-header border-0 pb-0">
                <h5 class="modal-title" id="productFormModalLabel"><?php echo e(__('menu.add_product')); ?></h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="<?php echo e(__('menu.cancel')); ?>"></button>
            </div>
            <div class="modal-body pt-2">
                <?php echo $__env->make('theme::partials.admin.product-form', [
                    'product' => null,
                    'formAction' => route('admin.products.store'),
                    'formMethod' => 'POST',
                    'categories' => $categories,
                    'submitLabel' => __('menu.save'),
                    'showCancel' => true,
                ], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
            </div>
        </div>
    </div>
</div>

<?php if(session('open_product_modal') || ($errors->any() && !request()->routeIs('admin.products.edit'))): ?>
    <?php $__env->startPush('scripts'); ?>
    <script>
        document.addEventListener('DOMContentLoaded', function () {
            const modalEl = document.getElementById('productFormModal');
            if (modalEl) {
                bootstrap.Modal.getOrCreateInstance(modalEl).show();
            }
        });
    </script>
    <?php $__env->stopPush(); ?>
<?php endif; ?>
<?php /**PATH C:\Users\faltun\Desktop\Menu-One\themes/adminlte4/partials/admin/product-form-modal.blade.php ENDPATH**/ ?>