<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title><?php echo $__env->yieldContent('title', config('app.name')); ?></title>
    <link rel="icon" href="<?php echo e(\App\Support\Branding::faviconUrl()); ?>">
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/themes/adminlte4.css', 'resources/js/themes/adminlte4.js']); ?>
    <?php echo $__env->make('theme::partials.branding-styles', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <?php echo $__env->yieldPushContent('styles'); ?>
</head>
<body class="bg-body-tertiary">
<?php ($currentUser = auth()->user()); ?>
<div class="app-wrapper">
    <nav class="app-header navbar navbar-expand bg-body border-bottom">
        <div class="container-fluid">
            <a href="<?php echo e(route('home')); ?>" class="navbar-brand d-flex align-items-center py-0">
                <img src="<?php echo e(\App\Support\Branding::logoUrl()); ?>" alt="<?php echo e(\App\Support\SiteConfig::name()); ?>" class="navbar-brand-logo"
                     style="height: <?php echo e(\App\Support\Branding::sidebarLogoHeight()); ?>px; width: auto; max-width: 12rem; object-fit: contain;">
            </a>
            <ul class="navbar-nav ms-auto align-items-center gap-2">
                <?php if(!empty($canSwitchTenants) && $canSwitchTenants): ?>
                    <li class="nav-item"><?php echo $__env->make('theme::partials.tenant-switcher', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?></li>
                <?php endif; ?>
                <li class="nav-item"><?php echo $__env->make('theme::partials.locale-switcher', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?></li>
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" data-bs-toggle="dropdown">
                        <i class="bi bi-person-circle"></i> <?php echo e($currentUser->name); ?>

                    </a>
                    <ul class="dropdown-menu dropdown-menu-end">
                        <li><a class="dropdown-item active" href="<?php echo e(route('profile.edit')); ?>"><?php echo e(__('menu.profile')); ?></a></li>
                        <li><hr class="dropdown-divider"></li>
                        <li>
                            <form method="POST" action="<?php echo e(route('logout')); ?>">
                                <?php echo csrf_field(); ?>
                                <button type="submit" class="dropdown-item"><?php echo e(__('menu.logout')); ?></button>
                            </form>
                        </li>
                    </ul>
                </li>
            </ul>
        </div>
    </nav>

    <main class="app-main">
        <div class="app-content py-4">
            <div class="container-fluid" style="max-width: 960px;">
                <?php echo $__env->make('theme::partials.alerts', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                <?php echo $__env->yieldContent('content'); ?>
            </div>
        </div>
    </main>
</div>
<?php echo $__env->yieldPushContent('scripts'); ?>
</body>
</html>
<?php /**PATH C:\Users\faltun\Desktop\Menu-One\themes/adminlte4/layouts/profile.blade.php ENDPATH**/ ?>