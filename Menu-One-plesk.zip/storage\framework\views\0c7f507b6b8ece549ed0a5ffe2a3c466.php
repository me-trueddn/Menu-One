

<?php $__env->startSection('title', __('menu.licenses')); ?>
<?php $__env->startSection('page-title', __('menu.licenses')); ?>

<?php $__env->startSection('page-actions'); ?>
<a href="<?php echo e(route('platform.licenses.create')); ?>" class="btn btn-primary btn-sm"><i class="bi bi-plus-lg"></i> <?php echo e(__('menu.add')); ?></a>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="card-body table-responsive p-0">
        <table class="table table-hover mb-0">
            <thead>
                <tr>
                    <th><?php echo e(__('menu.name')); ?></th>
                    <th><?php echo e(__('menu.duration_days')); ?></th>
                    <th><?php echo e(__('menu.status')); ?></th>
                    <th class="text-end"><?php echo e(__('menu.actions')); ?></th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $licenses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $license): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td>
                            <?php echo e($license->name); ?>

                            <?php if($license->is_default): ?><span class="badge text-bg-info ms-1"><?php echo e(__('menu.default')); ?></span><?php endif; ?>
                        </td>
                        <td><?php echo e($license->duration_days); ?></td>
                        <td>
                            <span class="badge <?php echo e($license->is_active ? 'text-bg-success' : 'text-bg-secondary'); ?>">
                                <?php echo e($license->is_active ? __('menu.active') : __('menu.inactive')); ?>

                            </span>
                        </td>
                        <td class="text-end">
                            <a href="<?php echo e(route('platform.licenses.edit', $license)); ?>" class="btn btn-sm btn-outline-primary"><?php echo e(__('menu.edit')); ?></a>
                            <?php if (! ($license->is_default)): ?>
                                <form action="<?php echo e(route('platform.licenses.destroy', $license)); ?>" method="POST" class="d-inline" onsubmit="return confirm('<?php echo e(__('menu.confirm_delete')); ?>')">
                                    <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                                    <button class="btn btn-sm btn-outline-danger"><?php echo e(__('menu.delete')); ?></button>
                                </form>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr><td colspan="4" class="text-center text-muted"><?php echo e(__('menu.no_data')); ?></td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
    <?php if($licenses->hasPages()): ?><div class="card-footer"><?php echo e($licenses->links()); ?></div><?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('theme::layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\faltun\Desktop\Menu-One\themes/adminlte4/pages/platform/licenses/index.blade.php ENDPATH**/ ?>