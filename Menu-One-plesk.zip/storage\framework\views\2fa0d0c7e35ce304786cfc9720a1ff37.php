<nav class="app-header navbar navbar-expand bg-body">
    <div class="container-fluid">
        <ul class="navbar-nav">
            <li class="nav-item">
                <a class="nav-link" data-lte-toggle="sidebar" href="#" role="button">
                    <i class="bi bi-list"></i>
                </a>
            </li>
        </ul>
        <ul class="navbar-nav ms-auto align-items-center gap-2">
            <?php if(!empty($inSupportMode)): ?>
                <li class="nav-item">
                    <form method="POST" action="<?php echo e(route('platform.support.disconnect')); ?>" class="mb-0">
                        <?php echo csrf_field(); ?>
                        <button type="submit" class="btn btn-sm btn-warning">
                            <i class="bi bi-box-arrow-left"></i> <?php echo e(__('menu.exit_support')); ?>

                        </button>
                    </form>
                </li>
            <?php endif; ?>
            <?php if(!empty($canSwitchTenants) && $canSwitchTenants): ?>
                <li class="nav-item"><?php echo $__env->make('theme::partials.tenant-switcher', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?></li>
            <?php endif; ?>
            <li class="nav-item"><?php echo $__env->make('theme::partials.locale-switcher', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?></li>
            <li class="nav-item dropdown">
                <a class="nav-link dropdown-toggle" href="#" data-bs-toggle="dropdown">
                    <i class="bi bi-person-circle"></i> <?php echo e($currentUser->name); ?>

                </a>
                <ul class="dropdown-menu dropdown-menu-end">
                    <li><a class="dropdown-item" href="<?php echo e(route('profile.edit')); ?>"><?php echo e(__('menu.profile')); ?></a></li>
                    <li><hr class="dropdown-divider"></li>
                    <li>
                        <form method="POST" action="<?php echo e(route('logout')); ?>">
                            <?php echo csrf_field(); ?>
                            <button type="submit" class="dropdown-item"><?php echo e(__('menu.logout')); ?></button>
                        </form>
                    </li>
                </ul>
            </li>
        </ul>
    </div>
</nav>
<?php /**PATH C:\Users\faltun\Desktop\Menu-One\themes/adminlte4/partials/navbar.blade.php ENDPATH**/ ?>