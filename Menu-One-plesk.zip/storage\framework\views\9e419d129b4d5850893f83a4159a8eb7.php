

<?php $__env->startSection('title', __('menu.tenants')); ?>
<?php $__env->startSection('page-title', __('menu.tenants')); ?>

<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="card-header">
        <div class="row g-2 align-items-center">
            <div class="col-md-4 d-flex align-items-center gap-2">
                <h5 class="mb-0"><?php echo e(__('menu.registered_cafes')); ?></h5>
                <a href="<?php echo e(route('platform.tenants.create')); ?>" class="btn btn-primary btn-sm"><i class="bi bi-plus-lg"></i> <?php echo e(__('menu.add')); ?></a>
            </div>
            <div class="col-md-8">
                <form method="GET" action="<?php echo e(route('platform.tenants.index')); ?>" class="row g-2 justify-content-end">
                    <div class="col-auto flex-grow-1" style="min-width:12rem">
                        <input type="search" name="q" value="<?php echo e(request('q')); ?>" class="form-control form-control-sm" placeholder="<?php echo e(__('menu.tenant_search_placeholder')); ?>">
                    </div>
                    <div class="col-auto"><button class="btn btn-sm btn-outline-primary"><?php echo e(__('menu.search')); ?></button></div>
                </form>
            </div>
        </div>
    </div>
    <div class="card-body table-responsive p-0">
        <table class="table table-hover mb-0 align-middle">
            <thead>
                <tr>
                    <th><?php echo e(__('menu.tenant_id')); ?></th>
                    <th><?php echo e(__('menu.site_name')); ?></th>
                    <th><?php echo e(__('menu.owner_email')); ?></th>
                    <th><?php echo e(__('menu.account_type')); ?></th>
                    <th><?php echo e(__('menu.created_at')); ?></th>
                    <th><?php echo e(__('menu.license_expires')); ?></th>
                    <th><?php echo e(__('menu.status')); ?></th>
                    <th class="text-end"><?php echo e(__('menu.actions')); ?></th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $tenants; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tenant): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td><code><?php echo e($tenant->id); ?></code></td>
                        <td>
                            <img src="<?php echo e(\App\Support\Branding::cafeLogoUrl($tenant)); ?>" alt="" style="height:24px" class="me-1">
                            <?php echo e($tenant->name); ?>

                        </td>
                        <td><?php echo e($tenant->owner?->email ?? '—'); ?></td>
                        <td><?php echo $__env->make('theme::partials.cafe-subscription-badge', ['cafe' => $tenant], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?></td>
                        <td><?php echo e($tenant->created_at?->format('d.m.Y') ?? '—'); ?></td>
                        <td><?php echo e($tenant->currentLicense?->expires_at?->format('d.m.Y') ?? '—'); ?></td>
                        <td>
                            <?php if($tenant->isStopped()): ?>
                                <span class="badge text-bg-danger"><?php echo e(__('menu.stopped')); ?></span>
                            <?php elseif($tenant->is_active): ?>
                                <span class="badge text-bg-success"><?php echo e(__('menu.active')); ?></span>
                            <?php else: ?>
                                <span class="badge text-bg-secondary"><?php echo e(__('menu.inactive')); ?></span>
                            <?php endif; ?>
                        </td>
                        <td class="text-end">
                            <form action="<?php echo e(route('platform.tenants.connect', $tenant)); ?>" method="POST" class="d-inline"><?php echo csrf_field(); ?>
                                <button class="btn btn-sm btn-outline-info" title="<?php echo e(__('menu.connect_support')); ?>"><i class="bi bi-box-arrow-in-right"></i></button>
                            </form>
                            <a href="<?php echo e(route('platform.tenants.edit', $tenant)); ?>" class="btn btn-sm btn-outline-primary"><?php echo e(__('menu.edit')); ?></a>
                            <form action="<?php echo e(route('platform.tenants.destroy', $tenant)); ?>" method="POST" class="d-inline" onsubmit="return confirm('<?php echo e(__('menu.confirm_delete')); ?>')">
                                <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                                <button class="btn btn-sm btn-outline-danger"><?php echo e(__('menu.delete')); ?></button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr><td colspan="8" class="text-center text-muted"><?php echo e(__('menu.no_data')); ?></td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
    <?php if($tenants->hasPages()): ?><div class="card-footer"><?php echo e($tenants->links()); ?></div><?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('theme::layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\faltun\Desktop\Menu-One\themes/adminlte4/pages/platform/tenants/index.blade.php ENDPATH**/ ?>