<?php ($reservation = $table->nextReservation()); ?>
<?php ($displayStatus = $table->displayStatus()); ?>
<?php ($readyCount = ($readyCountsByTable ?? [])[$table->id] ?? 0); ?>
<?php ($hasReady = $readyCount > 0); ?>
<?php ($borderClass = $hasReady ? 'warning' : ($displayStatus->value === 'occupied' ? 'danger' : ($displayStatus->value === 'reserved' ? 'warning' : 'success'))); ?>
<div class="col-md-3 col-sm-6 mb-3" data-waiter-table-card data-table-id="<?php echo e($table->id); ?>" data-table-status="<?php echo e($displayStatus->value); ?>">
    <a href="<?php echo e(route('waiter.tables.show', $table)); ?>" class="text-decoration-none">
        <div class="card h-100 border-<?php echo e($borderClass); ?> <?php echo e($hasReady ? 'bg-warning-subtle' : ''); ?>" data-table-card>
            <div class="card-body text-center">
                <h4 class="card-title"><?php echo e($table->name); ?></h4>
                <p class="mb-1"><span class="badge <?php echo e($displayStatus->badgeClass()); ?>"><?php echo e($displayStatus->label()); ?></span></p>
                <small class="text-muted"><?php echo e($table->capacity); ?> <?php echo e(__('menu.seats')); ?></small>
                <div data-ready-banner class="<?php echo e($hasReady ? '' : 'd-none'); ?> mt-2">
                    <span class="badge text-bg-warning"><?php echo e(__('menu.table_orders_ready')); ?></span>
                    <div class="small text-muted mt-1" data-ready-count>
                        <?php if($hasReady): ?>
                            <?php echo e(trans_choice('menu.table_ready_items_count', $readyCount, ['count' => $readyCount])); ?>

                        <?php endif; ?>
                    </div>
                </div>
                <?php if($reservation): ?>
                    <div class="mt-2 small text-start border-top pt-2">
                        <span class="badge text-bg-warning"><?php echo e(__('menu.reserved')); ?></span>
                        <div class="mt-1"><strong><?php echo e($reservation->guest_name); ?></strong></div>
                        <div><?php echo e($reservation->party_size); ?> <?php echo e(__('menu.seats')); ?></div>
                        <div class="text-muted">
                            <?php echo e($reservation->starts_at->format('d.m.Y H:i')); ?>

                            – <?php echo e($reservation->ends_at->format('H:i')); ?>

                        </div>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </a>
</div>
<?php /**PATH C:\Users\faltun\Desktop\Menu-One\themes/adminlte4/partials/table-card.blade.php ENDPATH**/ ?>