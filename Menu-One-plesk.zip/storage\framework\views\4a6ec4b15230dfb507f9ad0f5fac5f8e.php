

<?php $__env->startSection('title', __('menu.ticket')); ?>
<?php $__env->startSection('page-title', __('menu.ticket')); ?>

<?php $__env->startSection('content'); ?>
<?php echo $__env->make('theme::partials.license-expired-banner', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

<div class="card shadow-sm">
    <div class="card-body text-center py-5">
        <i class="bi bi-ticket-perforated display-4 text-muted"></i>
        <h5 class="mt-3"><?php echo e(__('menu.ticket')); ?></h5>
        <p class="text-muted mb-0"><?php echo e(__('menu.ticket_coming_soon')); ?></p>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('theme::layouts.profile', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\faltun\Desktop\Menu-One\themes/adminlte4/pages/ticket/index.blade.php ENDPATH**/ ?>