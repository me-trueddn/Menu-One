<?php $__env->startSection('title', __('menu.edit_cafe')); ?>
<?php $__env->startSection('page-title', __('menu.edit_cafe')); ?>

<?php $__env->startSection('content'); ?>
<div class="row g-3">
    <div class="col-lg-8">
        <div class="card">
            <div class="card-body">
                <form method="POST" action="<?php echo e(route('platform.tenants.update', $tenant)); ?>" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?> <?php echo method_field('PUT'); ?>
                    <div class="row g-3">
                        <div class="col-md-6">
                            <label class="form-label"><?php echo e(__('menu.cafe_name')); ?></label>
                            <input type="text" name="name" class="form-control" value="<?php echo e(old('name', $tenant->name)); ?>" required>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label"><?php echo e(__('menu.slug')); ?></label>
                            <input type="text" name="slug" class="form-control" value="<?php echo e(old('slug', $tenant->slug)); ?>" required>
                        </div>
                        <?php echo $__env->make('theme::partials.company-fields', ['values' => $tenant->only(['company_name','company_tax_number','company_phone','company_email','company_address'])], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                        <div class="col-md-6">
                            <label class="form-label"><?php echo e(__('menu.cafe_logo')); ?></label>
                            <input type="file" name="logo" class="form-control" accept="image/*">
                            <img src="<?php echo e(\App\Support\Branding::cafeLogoUrl($tenant)); ?>" alt="" class="mt-2" style="height:48px">
                        </div>
                        <div class="col-md-6">
                            <label class="form-label"><?php echo e(__('menu.assign_license')); ?></label>
                            <select name="license_type_id" class="form-select">
                                <option value=""><?php echo e(__('menu.keep_current_license')); ?></option>
                                <?php $__currentLoopData = $licenseTypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $licenseType): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($licenseType->id); ?>" <?php if(old('license_type_id') == $licenseType->id): echo 'selected'; endif; ?>>
                                        <?php echo e($licenseType->name); ?> (<?php echo e($licenseType->duration_days); ?> <?php echo e(__('menu.duration_days')); ?>)
                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <div class="form-text"><?php echo e(__('menu.assign_license_hint')); ?></div>
                        </div>
                    </div>
                    <div class="mt-3">
                        <button type="submit" class="btn btn-primary"><?php echo e(__('menu.update')); ?></button>
                        <a href="<?php echo e(route('platform.tenants.index')); ?>" class="btn btn-secondary"><?php echo e(__('menu.cancel')); ?></a>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <div class="col-lg-4">
        <div class="card mb-3">
            <div class="card-body">
                <h6><?php echo e(__('menu.cafe_info')); ?></h6>
                <p class="mb-1 small text-muted"><?php echo e(__('menu.created_at')); ?></p>
                <p><?php echo e($tenant->created_at?->format('d.m.Y H:i') ?? '—'); ?></p>
                <?php if($tenant->currentLicense): ?>
                    <p class="mb-1 small text-muted"><?php echo e(__('menu.current_license')); ?></p>
                    <p><?php echo e($tenant->currentLicense->licenseType?->name ?? '—'); ?></p>
                    <p class="mb-1 small text-muted"><?php echo e(__('menu.license_expires')); ?></p>
                    <p><?php echo e($tenant->currentLicense->expires_at->format('d.m.Y H:i')); ?></p>
                <?php endif; ?>
                <?php if($tenant->isStopped()): ?>
                    <div class="alert alert-warning small">
                        <strong><?php echo e(__('menu.cafe_stopped')); ?></strong><br>
                        <?php echo e($tenant->stop_note); ?><br>
                        <span class="text-muted"><?php echo e($tenant->stoppedBy?->name); ?> · <?php echo e($tenant->stoppedBy?->email); ?></span>
                    </div>
                    <form method="POST" action="<?php echo e(route('platform.tenants.resume', $tenant)); ?>"><?php echo csrf_field(); ?>
                        <button class="btn btn-sm btn-success"><?php echo e(__('menu.cafe_resume')); ?></button>
                    </form>
                <?php else: ?>
                    <button class="btn btn-sm btn-outline-danger" data-bs-toggle="modal" data-bs-target="#stopCafeModal"><?php echo e(__('menu.cafe_stop')); ?></button>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<?php echo $__env->make('theme::partials.tenant-staff-panel', ['tenant' => $tenant], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

<div class="modal fade" id="stopCafeModal" tabindex="-1">
    <div class="modal-dialog">
        <form method="POST" action="<?php echo e(route('platform.tenants.stop', $tenant)); ?>" class="modal-content">
            <?php echo csrf_field(); ?>
            <div class="modal-header"><h5 class="modal-title"><?php echo e(__('menu.cafe_stop')); ?></h5><button type="button" class="btn-close" data-bs-dismiss="modal"></button></div>
            <div class="modal-body">
                <label class="form-label"><?php echo e(__('menu.stop_note')); ?></label>
                <textarea name="stop_note" class="form-control" rows="4" required></textarea>
            </div>
            <div class="modal-footer"><button class="btn btn-danger"><?php echo e(__('menu.cafe_stop')); ?></button></div>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('theme::layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\faltun\Desktop\Menu-One\themes/adminlte4/pages/platform/tenants/edit.blade.php ENDPATH**/ ?>