<?php $__env->startSection('title', __('menu.staff')); ?>
<?php $__env->startSection('page-title', __('menu.staff')); ?>
<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="card-header d-flex justify-content-between">
        <h5 class="mb-0"><?php echo e(__('menu.staff')); ?></h5>
        <a href="<?php echo e(route('admin.staff.create')); ?>" class="btn btn-primary btn-sm"><?php echo e(__('menu.add_staff')); ?></a>
    </div>
    <div class="card-body table-responsive p-0">
        <table class="table mb-0">
            <thead>
                <tr>
                    <th><?php echo e(__('menu.full_name')); ?></th>
                    <th><?php echo e(__('menu.email')); ?></th>
                    <th><?php echo e(__('menu.role')); ?></th>
                    <th class="text-end"><?php echo e(__('menu.actions')); ?></th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $staff; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td><?php echo e($user->name); ?></td>
                        <td><?php echo e($user->email); ?></td>
                        <td><?php echo e(__('menu.role_'.$user->getRoleNames()->first())); ?></td>
                        <td class="text-end">
                            <a href="<?php echo e(route('admin.staff.edit', $user)); ?>" class="btn btn-sm btn-outline-primary"><?php echo e(__('menu.edit')); ?></a>
                            <?php if($user->id !== auth()->id()): ?>
                                <form action="<?php echo e(route('admin.staff.destroy', $user)); ?>" method="POST" class="d-inline" onsubmit="return confirm('<?php echo e(__('menu.confirm_remove_staff')); ?>')">
                                    <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                                    <button class="btn btn-sm btn-outline-danger"><?php echo e(__('menu.remove')); ?></button>
                                </form>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr><td colspan="4" class="text-center text-muted py-4"><?php echo e(__('menu.no_staff')); ?></td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
    <?php if($staff->hasPages()): ?><div class="card-footer"><?php echo e($staff->links()); ?></div><?php endif; ?>
</div>

<?php echo $__env->make('theme::partials.staff-invitations-panel', [
    'invitations' => $invitations,
    'revokeRoute' => fn ($invitation) => route('admin.staff.invitations.revoke', $invitation),
], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('theme::layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\faltun\Desktop\Menu-One\themes/adminlte4/pages/admin/staff/index.blade.php ENDPATH**/ ?>