

<?php $__env->startSection('title', __('menu.tables')); ?>
<?php $__env->startSection('page-title', __('menu.tables')); ?>

<?php $__env->startSection('content'); ?>
<div class="card mb-3">
    <div class="card-header d-flex flex-wrap gap-2 justify-content-between align-items-center">
        <h5 class="mb-0"><?php echo e(__('menu.tables')); ?></h5>
        <div class="d-flex flex-wrap gap-2">
            <a href="<?php echo e(route('admin.table-categories.create')); ?>" class="btn btn-outline-primary btn-sm">
                <i class="bi bi-folder-plus"></i> <?php echo e(__('menu.add_table_category')); ?>

            </a>
            <a href="<?php echo e(route('admin.tables.create')); ?>" class="btn btn-primary btn-sm">
                <i class="bi bi-plus-lg"></i> <?php echo e(__('menu.add_table')); ?>

            </a>
        </div>
    </div>
</div>

<?php if($categories->isEmpty() && $uncategorizedTables->isEmpty()): ?>
    <div class="card">
        <div class="card-body text-center text-muted py-5">
            <p class="mb-3"><?php echo e(__('menu.no_tables_setup')); ?></p>
            <a href="<?php echo e(route('admin.table-categories.create')); ?>" class="btn btn-outline-primary btn-sm me-2"><?php echo e(__('menu.add_table_category')); ?></a>
            <a href="<?php echo e(route('admin.tables.create')); ?>" class="btn btn-primary btn-sm"><?php echo e(__('menu.add_table')); ?></a>
        </div>
    </div>
<?php else: ?>
    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="card mb-3">
            <div class="card-header d-flex flex-wrap gap-2 justify-content-between align-items-center">
                <div>
                    <h5 class="mb-0"><?php echo e($category->name); ?></h5>
                    <small class="text-muted"><?php echo e(trans_choice('menu.table_count', $category->tables->count(), ['count' => $category->tables->count()])); ?></small>
                </div>
                <div class="d-flex flex-wrap gap-2">
                    <a href="<?php echo e(route('admin.tables.create', ['table_category_id' => $category->id])); ?>" class="btn btn-sm btn-outline-primary">
                        <i class="bi bi-plus-lg"></i> <?php echo e(__('menu.add_table')); ?>

                    </a>
                    <a href="<?php echo e(route('admin.table-categories.edit', $category)); ?>" class="btn btn-sm btn-outline-secondary"><?php echo e(__('menu.edit')); ?></a>
                    <form action="<?php echo e(route('admin.table-categories.destroy', $category)); ?>" method="POST" class="d-inline"
                          onsubmit="return confirm('<?php echo e(__('menu.confirm_delete_table_category')); ?>')">
                        <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                        <button class="btn btn-sm btn-outline-danger"><?php echo e(__('menu.delete')); ?></button>
                    </form>
                </div>
            </div>
            <div class="card-body table-responsive p-0">
                <?php if($category->tables->isEmpty()): ?>
                    <p class="text-muted mb-0 p-3"><?php echo e(__('menu.no_tables_in_category')); ?></p>
                <?php else: ?>
                    <table class="table table-hover mb-0">
                        <thead>
                            <tr>
                                <th><?php echo e(__('menu.table_name')); ?></th>
                                <th><?php echo e(__('menu.table_capacity_label')); ?></th>
                                <th><?php echo e(__('menu.table_status')); ?></th>
                                <th class="text-end"><?php echo e(__('menu.actions')); ?></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $category->tables; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $table): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php echo $__env->make('theme::partials.admin.table-row', ['table' => $table], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                <?php endif; ?>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    <?php if($uncategorizedTables->isNotEmpty()): ?>
        <div class="card mb-3">
            <div class="card-header d-flex flex-wrap gap-2 justify-content-between align-items-center">
                <div>
                    <h5 class="mb-0"><?php echo e(__('menu.uncategorized_tables')); ?></h5>
                    <small class="text-muted"><?php echo e(trans_choice('menu.table_count', $uncategorizedTables->count(), ['count' => $uncategorizedTables->count()])); ?></small>
                </div>
                <a href="<?php echo e(route('admin.tables.create')); ?>" class="btn btn-sm btn-outline-primary">
                    <i class="bi bi-plus-lg"></i> <?php echo e(__('menu.add_table')); ?>

                </a>
            </div>
            <div class="card-body table-responsive p-0">
                <table class="table table-hover mb-0">
                    <thead>
                        <tr>
                            <th><?php echo e(__('menu.table_name')); ?></th>
                            <th><?php echo e(__('menu.table_capacity_label')); ?></th>
                            <th><?php echo e(__('menu.table_status')); ?></th>
                            <th class="text-end"><?php echo e(__('menu.actions')); ?></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $uncategorizedTables; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $table): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php echo $__env->make('theme::partials.admin.table-row', ['table' => $table], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    <?php endif; ?>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('theme::layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\faltun\Desktop\Menu-One\themes/adminlte4/pages/admin/tables/index.blade.php ENDPATH**/ ?>