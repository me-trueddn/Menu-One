<div class="locale-pills">
    <?php $__currentLoopData = config('locale.available', []); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $code): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <a href="<?php echo e(route('locale.switch', $code)); ?>"
           class="locale-pill <?php echo e(app()->getLocale() === $code ? 'active' : ''); ?>"
           title="<?php echo e(config('locale.names.'.$code, $code)); ?>">
            <?php echo e(strtoupper($code)); ?>

        </a>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<?php /**PATH C:\Users\faltun\Desktop\Menu-One\themes/adminlte4/partials/auth/locale-switcher.blade.php ENDPATH**/ ?>