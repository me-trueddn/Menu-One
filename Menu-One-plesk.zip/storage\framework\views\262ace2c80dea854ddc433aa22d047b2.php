<?php $__env->startSection('title', __('menu.tables')); ?>
<?php $__env->startSection('page-title', __('menu.waiter').' — '.__('menu.tables')); ?>
<?php $__env->startSection('content'); ?>
<div class="d-flex justify-content-end mb-3">
    <a href="<?php echo e(route('reservations.index')); ?>" class="btn btn-outline-primary btn-sm"><?php echo e(__('menu.reservations')); ?></a>
</div>

<?php if($categories->isEmpty() && $uncategorizedTables->isEmpty()): ?>
    <p class="text-muted"><?php echo e(__('menu.no_tables')); ?></p>
<?php else: ?>
    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if($category->tables->isNotEmpty()): ?>
            <h5 class="mb-3 mt-2"><?php echo e($category->name); ?></h5>
            <div class="row mb-4">
                <?php $__currentLoopData = $category->tables; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $table): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php echo $__env->make('theme::partials.table-card', ['table' => $table, 'readyCountsByTable' => $readyCountsByTable], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    <?php if($uncategorizedTables->isNotEmpty()): ?>
        <?php if($categories->isNotEmpty()): ?>
            <h5 class="mb-3 mt-2"><?php echo e(__('menu.uncategorized_tables')); ?></h5>
        <?php endif; ?>
        <div class="row">
            <?php $__currentLoopData = $uncategorizedTables; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $table): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php echo $__env->make('theme::partials.table-card', ['table' => $table, 'readyCountsByTable' => $readyCountsByTable], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    <?php endif; ?>
<?php endif; ?>

<div id="ready-alert" class="alert alert-warning d-none"></div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>
<script>
const readyCountMany = <?php echo json_encode(trans_choice('menu.table_ready_items_count', 2, ['count' => ':count'])) ?>;

const formatReadyCount = (count) => readyCountMany.replace(':count', count);

const updateTableCards = (tables) => {
    document.querySelectorAll('[data-waiter-table-card]').forEach((wrapper) => {
        const tableId = wrapper.dataset.tableId;
        const count = Number(tables[tableId] || 0);
        const card = wrapper.querySelector('[data-table-card]');
        const banner = wrapper.querySelector('[data-ready-banner]');
        const countEl = wrapper.querySelector('[data-ready-count]');
        const status = wrapper.dataset.tableStatus;

        card.classList.remove('border-warning', 'border-danger', 'border-success', 'bg-warning-subtle');

        if (count > 0) {
            card.classList.add('border-warning', 'bg-warning-subtle');
            banner.classList.remove('d-none');
            countEl.textContent = formatReadyCount(count);
            return;
        }

        banner.classList.add('d-none');
        countEl.textContent = '';

        const borderClass = status === 'occupied' ? 'border-danger' : (status === 'reserved' ? 'border-warning' : 'border-success');
        card.classList.add(borderClass);
    });
};

const pollReadyItems = async () => {
    const res = await fetch('<?php echo e(route('waiter.ready-items.poll')); ?>');
    const data = await res.json();

    updateTableCards(data.tables || {});

    const el = document.getElementById('ready-alert');
    if (data.items.length) {
        el.classList.remove('d-none');
        el.textContent = '<?php echo e(__('menu.ready_orders')); ?>: ' + data.items.map(i => i.table + ' - ' + i.product).join(', ');
    } else {
        el.classList.add('d-none');
    }
};

pollReadyItems();
setInterval(pollReadyItems, 5000);
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('theme::layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\faltun\Desktop\Menu-One\themes/adminlte4/pages/waiter/tables/index.blade.php ENDPATH**/ ?>