<?php ($licenseExpired = auth()->check() && \App\Support\TenantLicenseGate::licenseExpiredForUser(auth()->user())); ?>
<?php if($licenseExpired): ?>
    <div class="alert alert-warning d-flex align-items-start gap-2 mb-3" role="alert">
        <i class="bi bi-exclamation-triangle-fill mt-1"></i>
        <div>
            <div class="fw-semibold"><?php echo e(__('menu.cafe_license_expired_title')); ?></div>
            <div class="small"><?php echo e(__('menu.cafe_license_expired_profile')); ?></div>
            <a href="<?php echo e(route('profile.edit', ['tab' => 'ticket'])); ?>" class="alert-link small"><?php echo e(__('menu.open_ticket')); ?></a>
        </div>
    </div>
<?php endif; ?>
<?php /**PATH C:\Users\faltun\Desktop\Menu-One\themes/adminlte4/partials/license-expired-banner.blade.php ENDPATH**/ ?>