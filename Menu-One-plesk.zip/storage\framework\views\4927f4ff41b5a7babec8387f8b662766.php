
<?php $__env->startSection('title', 'Kategori Ekle'); ?>
<?php $__env->startSection('page-title', 'Kategori Ekle'); ?>
<?php $__env->startSection('content'); ?>
<div class="card"><div class="card-body"><form method="POST" action="<?php echo e(route('admin.categories.store')); ?>"><?php echo csrf_field(); ?>
<div class="mb-3"><label class="form-label">Ad</label><input name="name" class="form-control" required></div>
<div class="mb-3"><label class="form-label">Sıra</label><input type="number" name="sort_order" class="form-control" value="0"></div>
<button class="btn btn-primary">Kaydet</button><a href="<?php echo e(route('admin.categories.index')); ?>" class="btn btn-secondary">İptal</a>
</form></div></div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('theme::layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\faltun\Desktop\Menu-One\themes/adminlte4/pages/admin/categories/create.blade.php ENDPATH**/ ?>