<?php if($reservation->guestPhoneDial()): ?>
    <a href="tel:<?php echo e($reservation->guestPhoneDial()); ?>" class="btn btn-sm btn-success" title="<?php echo e(__('menu.reservation_call_guest')); ?>">
        <i class="fa fa-phone"></i> <?php echo e(__('menu.reservation_call_guest')); ?>

    </a>
<?php else: ?>
    <span class="text-muted small">—</span>
<?php endif; ?>
<?php /**PATH C:\Users\faltun\Desktop\Menu-One\themes/adminlte4/pages/reservations/_call.blade.php ENDPATH**/ ?>