<footer class="app-footer">
    <div class="float-end d-none d-sm-inline">
        Menu-One v<?php echo e(config('app.version', '1.0.0')); ?>

        <?php if((int) config('app.build', 0) > 0): ?>
            · Build <?php echo e(config('app.build')); ?>

        <?php endif; ?>
    </div>
    <strong>Menu-One</strong> Cafe Adisyon Sistemi
</footer>
<?php /**PATH C:\Users\faltun\Desktop\Menu-One\themes/adminlte4/partials/footer.blade.php ENDPATH**/ ?>