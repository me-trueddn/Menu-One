

<?php $__env->startSection('title', __('menu.cashier')); ?>

<?php $__env->startSection('page-title', __('menu.cashier_tables')); ?>

<?php $__env->startSection('content'); ?>

<div class="card mb-3">
    <div class="card-body">
        <form method="GET" action="<?php echo e(route('cashier.tables.index')); ?>" class="row g-2 align-items-center">
            <div class="col-md-6">
                <input type="search" name="q" value="<?php echo e($search); ?>" class="form-control"
                       placeholder="<?php echo e(__('menu.search_table')); ?>" autofocus>
            </div>
            <div class="col-auto">
                <button class="btn btn-primary"><?php echo e(__('menu.search')); ?></button>
                <?php if($search): ?>
                    <a href="<?php echo e(route('cashier.tables.index')); ?>" class="btn btn-outline-secondary"><?php echo e(__('menu.clear')); ?></a>
                <?php endif; ?>
            </div>
        </form>
    </div>
</div>

<?php if($tables->isEmpty()): ?>
    <p class="text-muted"><?php echo e(__('menu.no_tables_found')); ?></p>
<?php else: ?>
    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php ($categoryTables = \App\Support\TableGrouping::tablesForCategory($tables, $category)); ?>
        <?php if($categoryTables->isNotEmpty()): ?>
            <h5 class="mb-3 mt-2"><?php echo e($category->name); ?></h5>
            <div class="row mb-4">
                <?php $__currentLoopData = $categoryTables; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $table): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php echo $__env->make('theme::partials.cashier-table-card', ['table' => $table], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    <?php if($uncategorizedTables->isNotEmpty()): ?>
        <?php if($categories->isNotEmpty()): ?>
            <h5 class="mb-3 mt-2"><?php echo e(__('menu.uncategorized_tables')); ?></h5>
        <?php endif; ?>
        <div class="row">
            <?php $__currentLoopData = $uncategorizedTables; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $table): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php echo $__env->make('theme::partials.cashier-table-card', ['table' => $table], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    <?php endif; ?>
<?php endif; ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('theme::layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\faltun\Desktop\Menu-One\themes/adminlte4/pages/cashier/tables/index.blade.php ENDPATH**/ ?>