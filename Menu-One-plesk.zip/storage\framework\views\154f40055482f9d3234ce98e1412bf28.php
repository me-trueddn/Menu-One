<?php $__env->startSection('title', __('menu.users')); ?>
<?php $__env->startSection('page-title', __('menu.users')); ?>

<?php $__env->startSection('page-actions'); ?>
<?php if($currentUser->canPlatformModule('users', 'edit')): ?>
<div class="dropdown">
    <button class="btn btn-outline-secondary btn-sm dropdown-toggle" type="button" data-bs-toggle="dropdown">
        <i class="bi bi-diagram-3"></i> <?php echo e(__('menu.user_groups')); ?>

    </button>
    <div class="dropdown-menu dropdown-menu-end p-3" style="min-width: 260px;">
        <a href="<?php echo e(route('platform.user-groups.create')); ?>" class="btn btn-primary btn-sm w-100 mb-2"><?php echo e(__('menu.create_group')); ?></a>
        <a href="<?php echo e(route('platform.user-groups.index')); ?>" class="btn btn-outline-secondary btn-sm w-100"><?php echo e(__('menu.manage_groups')); ?></a>
    </div>
</div>
<?php endif; ?>
<?php if($currentUser->canPlatformModule('users', 'view')): ?>
<a href="<?php echo e(route('platform.users.security')); ?>" class="btn btn-outline-warning btn-sm">
    <i class="bi bi-shield-lock"></i> <?php echo e(__('menu.security_settings')); ?>

</a>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="card-header d-flex justify-content-between align-items-center">
        <h5 class="mb-0"><?php echo e(__('menu.platform_users')); ?></h5>
        <a href="<?php echo e(route('platform.users.create')); ?>" class="btn btn-primary btn-sm">
            <i class="bi bi-plus-lg"></i> <?php echo e(__('menu.add')); ?>

        </a>
    </div>
    <div class="card-body table-responsive p-0">
        <table class="table table-hover mb-0 align-middle">
            <thead>
                <tr>
                    <th><?php echo e(__('menu.user_id')); ?></th>
                    <th><?php echo e(__('menu.full_name')); ?></th>
                    <th><?php echo e(__('menu.email')); ?></th>
                    <th><?php echo e(__('menu.phone')); ?></th>
                    <th><?php echo e(__('menu.role')); ?></th>
                    <th><?php echo e(__('menu.status')); ?></th>
                    <th class="text-end"><?php echo e(__('menu.actions')); ?></th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td><code><?php echo e($user->public_id); ?></code></td>
                        <td><?php echo e($user->name); ?> <?php if($user->is_super_admin): ?><span class="badge text-bg-dark"><?php echo e(__('menu.super_admin')); ?></span><?php endif; ?></td>
                        <td><?php echo e($user->email); ?></td>
                        <td><?php echo e($user->phone ?? '—'); ?></td>
                        <td><?php echo e($user->roleLabel()); ?></td>
                        <td>
                            <span class="badge <?php echo e($user->is_active ? 'text-bg-success' : 'text-bg-secondary'); ?>">
                                <?php echo e($user->is_active ? __('menu.active') : __('menu.inactive')); ?>

                            </span>
                        </td>
                        <td class="text-end">
                            <div class="btn-group btn-group-sm flex-wrap justify-content-end">
                                <?php if (! ($user->is_super_admin)): ?>
                                    <button type="button" class="btn btn-outline-secondary" data-bs-toggle="modal" data-bs-target="#resetPwd<?php echo e($user->id); ?>"><?php echo e(__('menu.reset_password')); ?></button>
                                    <form action="<?php echo e(route('platform.users.toggle-2fa', $user)); ?>" method="POST" class="d-inline">
                                        <?php echo csrf_field(); ?>
                                        <button class="btn btn-outline-secondary" <?php if(!\App\Support\SecurityPolicy::bool('security_2fa_enabled_globally') || ! $user->hasTwoFactorConfigured()): echo 'disabled'; endif; ?> title="<?php echo e(\App\Support\SecurityPolicy::bool('security_2fa_enabled_globally') ? '' : __('menu.two_factor_disabled_globally')); ?>">
                                            <?php echo e(__('menu.disable_2fa')); ?>

                                        </button>
                                    </form>
                                    <form action="<?php echo e(route('platform.users.reset-2fa', $user)); ?>" method="POST" class="d-inline" onsubmit="return confirm('<?php echo e(__('menu.two_factor_reset_confirm')); ?>')">
                                        <?php echo csrf_field(); ?>
                                        <button class="btn btn-outline-warning" <?php if(!\App\Support\SecurityPolicy::bool('security_2fa_enabled_globally') || ! $user->hasTwoFactorConfigured()): echo 'disabled'; endif; ?>>
                                            <?php echo e(__('menu.reset_2fa')); ?>

                                        </button>
                                    </form>
                                    <button type="button" class="btn btn-outline-secondary" data-bs-toggle="modal" data-bs-target="#changeEmail<?php echo e($user->id); ?>"><?php echo e(__('menu.change_email')); ?></button>
                                    <form action="<?php echo e(route('platform.users.send-reset-link', $user)); ?>" method="POST" class="d-inline">
                                        <?php echo csrf_field(); ?>
                                        <button class="btn btn-outline-info"><?php echo e(__('menu.send_reset_link')); ?></button>
                                    </form>
                                    <form action="<?php echo e(route('platform.users.toggle-active', $user)); ?>" method="POST" class="d-inline">
                                        <?php echo csrf_field(); ?>
                                        <button class="btn btn-outline-warning"><?php echo e($user->is_active ? __('menu.deactivate') : __('menu.activate')); ?></button>
                                    </form>
                                    <a href="<?php echo e(route('platform.users.edit', $user)); ?>" class="btn btn-outline-primary"><?php echo e(__('menu.edit')); ?></a>
                                    <?php if($currentUser->canPlatformModule('users', 'edit') && $user->id !== $currentUser->id): ?>
                                        <form action="<?php echo e(route('platform.users.destroy', $user)); ?>" method="POST" class="d-inline" onsubmit="return confirm('<?php echo e(__('menu.confirm_delete')); ?>')">
                                            <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                                            <button class="btn btn-outline-danger"><?php echo e(__('menu.delete')); ?></button>
                                        </form>
                                    <?php endif; ?>
                                <?php else: ?>
                                    <span class="text-muted small"><?php echo e(__('menu.super_admin_protected')); ?></span>
                                <?php endif; ?>
                            </div>

                            <?php if (! ($user->is_super_admin)): ?>
                            <div class="modal fade" id="resetPwd<?php echo e($user->id); ?>" tabindex="-1">
                                <div class="modal-dialog">
                                    <div class="modal-content">
                                        <form method="POST" action="<?php echo e(route('platform.users.reset-password', $user)); ?>">
                                            <?php echo csrf_field(); ?>
                                            <div class="modal-header"><h5 class="modal-title"><?php echo e(__('menu.reset_password')); ?></h5><button type="button" class="btn-close" data-bs-dismiss="modal"></button></div>
                                            <div class="modal-body">
                                                <div class="mb-3"><label class="form-label"><?php echo e(__('menu.password')); ?></label><input type="password" name="password" class="form-control" required></div>
                                                <div class="mb-3"><label class="form-label"><?php echo e(__('menu.password_confirm')); ?></label><input type="password" name="password_confirmation" class="form-control" required></div>
                                            </div>
                                            <div class="modal-footer"><button class="btn btn-primary"><?php echo e(__('menu.save')); ?></button></div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                            <div class="modal fade" id="changeEmail<?php echo e($user->id); ?>" tabindex="-1">
                                <div class="modal-dialog">
                                    <div class="modal-content">
                                        <form method="POST" action="<?php echo e(route('platform.users.change-email', $user)); ?>">
                                            <?php echo csrf_field(); ?>
                                            <div class="modal-header"><h5 class="modal-title"><?php echo e(__('menu.change_email')); ?></h5><button type="button" class="btn-close" data-bs-dismiss="modal"></button></div>
                                            <div class="modal-body">
                                                <input type="email" name="email" class="form-control" value="<?php echo e($user->email); ?>" required>
                                            </div>
                                            <div class="modal-footer"><button class="btn btn-primary"><?php echo e(__('menu.save')); ?></button></div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr><td colspan="7" class="text-center text-muted"><?php echo e(__('menu.no_data')); ?></td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
    <?php if($users->hasPages()): ?>
        <div class="card-footer"><?php echo e($users->links()); ?></div>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('theme::layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\faltun\Desktop\Menu-One\themes/adminlte4/pages/platform/users/index.blade.php ENDPATH**/ ?>