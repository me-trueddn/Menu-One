<?php $__env->startSection('content'); ?>
<div class="locale-row">
    <?php echo $__env->make('theme::partials.auth.locale-switcher', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
</div>

<div class="brand-name"><?php echo e(strtoupper(\App\Support\SiteConfig::name())); ?></div>

<h1 class="login-title"><?php echo e(__('menu.forgot_password')); ?></h1>
<p class="login-subtitle"><?php echo e(__('menu.forgot_password_hint')); ?></p>

<?php if(session('status')): ?>
    <div class="alert alert-success alert-login"><?php echo e(session('status')); ?></div>
<?php endif; ?>

<?php if($errors->any()): ?>
    <div class="alert alert-danger alert-login">
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div><?php echo e($error); ?></div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
<?php endif; ?>

<form method="POST" action="<?php echo e(route('password.email')); ?>">
    <?php echo csrf_field(); ?>
    <input type="hidden" name="captcha_check" value="1">

    <div class="mb-3">
        <input id="email" type="email" name="email" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
               value="<?php echo e(old('email')); ?>" placeholder="<?php echo e(__('menu.email')); ?>" required autofocus>
    </div>

    <?php echo $__env->make('theme::partials.auth.captcha', ['context' => \App\Support\CaptchaPolicy::CONTEXT_PASSWORD_RESET], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <div class="d-flex gap-3 flex-wrap mt-3">
        <button type="submit" class="btn-login"><?php echo e(__('menu.send_reset_link')); ?></button>
        <a href="<?php echo e(route('login')); ?>" class="btn-register"><?php echo e(__('menu.back_to_login')); ?></a>
    </div>
</form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('theme::layouts.auth', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\faltun\Desktop\Menu-One\resources\views/auth/forgot-password.blade.php ENDPATH**/ ?>