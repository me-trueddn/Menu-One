<?php $__env->startSection('title', __('menu.add_staff')); ?>
<?php $__env->startSection('page-title', __('menu.add_staff')); ?>
<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="card-body">
        <p class="text-muted"><?php echo e(__('menu.staff_add_hint')); ?></p>
        <form method="POST" action="<?php echo e(route('admin.staff.store')); ?>" id="staffAttachForm">
            <?php echo csrf_field(); ?>
            <div class="mb-3">
                <label class="form-label"><?php echo e(__('menu.email')); ?></label>
                <div class="input-group">
                    <input type="email" name="email" id="staffEmail" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                           value="<?php echo e(old('email')); ?>" required>
                    <button type="button" class="btn btn-outline-secondary" id="staffLookupBtn"><?php echo e(__('menu.search_user')); ?></button>
                </div>
                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="invalid-feedback d-block"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div id="staffLookupResult" class="alert d-none mb-3"></div>
            <div class="mb-3">
                <label class="form-label"><?php echo e(__('menu.role')); ?></label>
                <select name="role" class="form-select" required>
                    <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($role); ?>" <?php if(old('role') === $role): echo 'selected'; endif; ?>><?php echo e(__('menu.role_'.$role)); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <button type="submit" class="btn btn-primary" id="staffSubmitBtn" disabled><?php echo e(__('menu.send_invitation')); ?></button>
            <a href="<?php echo e(route('admin.staff.index')); ?>" class="btn btn-secondary"><?php echo e(__('menu.cancel')); ?></a>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
document.addEventListener('DOMContentLoaded', function () {
    const emailInput = document.getElementById('staffEmail');
    const lookupBtn = document.getElementById('staffLookupBtn');
    const resultBox = document.getElementById('staffLookupResult');
    const submitBtn = document.getElementById('staffSubmitBtn');
    const csrf = document.querySelector('meta[name="csrf-token"]').content;

    async function lookup() {
        resultBox.classList.add('d-none');
        submitBtn.disabled = true;
        const response = await fetch(<?php echo json_encode(route('admin.staff.lookup'), 15, 512) ?>, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'X-CSRF-TOKEN': csrf,
                'Accept': 'application/json',
            },
            body: JSON.stringify({ email: emailInput.value }),
        });
        const data = await response.json();
        resultBox.classList.remove('d-none', 'alert-success', 'alert-danger');
        if (data.found) {
            resultBox.classList.add('alert-success');
            resultBox.textContent = data.name + ' (' + data.email + ')';
            submitBtn.disabled = false;
        } else {
            resultBox.classList.add('alert-danger');
            resultBox.textContent = data.message;
        }
    }

    lookupBtn.addEventListener('click', lookup);
    emailInput.addEventListener('keydown', function (e) {
        if (e.key === 'Enter') {
            e.preventDefault();
            lookup();
        }
    });
});
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('theme::layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\faltun\Desktop\Menu-One\themes/adminlte4/pages/admin/staff/create.blade.php ENDPATH**/ ?>