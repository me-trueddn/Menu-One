<?php $__env->startSection('title', __('menu.site_management')); ?>
<?php $__env->startSection('page-title', __('menu.site_management')); ?>

<?php $__env->startSection('content'); ?>
<form method="POST" action="<?php echo e(route('platform.settings.site.update')); ?>" enctype="multipart/form-data">
    <?php echo csrf_field(); ?> <?php echo method_field('PUT'); ?>

    <div class="card">
        <div class="card-header">
            <h5 class="mb-0"><?php echo e(__('menu.site_settings')); ?></h5>
        </div>
        <div class="card-body">
            <div class="row">
                <div class="col-md-6 mb-3">
                    <label class="form-label"><?php echo e(__('menu.site_name')); ?></label>
                    <input name="site_name" class="form-control <?php $__errorArgs = ['site_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                           value="<?php echo e(old('site_name', $settings['site_name'])); ?>" required>
                    <?php $__errorArgs = ['site_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="invalid-feedback"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="col-md-6 mb-3">
                    <label class="form-label"><?php echo e(__('menu.default_language')); ?></label>
                    <select name="default_locale" class="form-select <?php $__errorArgs = ['default_locale'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required>
                        <?php $__currentLoopData = config('locale.available', []); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $code): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($code); ?>" <?php if(old('default_locale', $settings['default_locale']) === $code): echo 'selected'; endif; ?>>
                                <?php echo e(config('locale.names.'.$code, $code)); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <?php $__errorArgs = ['default_locale'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="invalid-feedback"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>

            <div class="row">
                <div class="col-md-6 mb-3">
                    <label class="form-label"><?php echo e(__('menu.panel_url')); ?></label>
                    <input name="panel_url" type="url" class="form-control <?php $__errorArgs = ['panel_url'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                           value="<?php echo e(old('panel_url', $settings['panel_url'])); ?>" required
                           placeholder="https://panel.example.com">
                    <?php $__errorArgs = ['panel_url'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="invalid-feedback"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    <div class="form-text"><?php echo e(__('menu.panel_url_hint')); ?></div>
                </div>
                <div class="col-md-6 mb-3">
                    <label class="form-label"><?php echo e(__('menu.main_site_url')); ?></label>
                    <input name="main_site_url" type="url" class="form-control <?php $__errorArgs = ['main_site_url'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                           value="<?php echo e(old('main_site_url', $settings['main_site_url'])); ?>" required
                           placeholder="https://example.com">
                    <?php $__errorArgs = ['main_site_url'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="invalid-feedback"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    <div class="form-text"><?php echo e(__('menu.main_site_url_hint')); ?></div>
                </div>
            </div>

            <div class="row">
                <div class="col-md-6 mb-3">
                    <label class="form-label"><?php echo e(__('menu.contact_phone')); ?></label>
                    <input name="contact_phone" class="form-control <?php $__errorArgs = ['contact_phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                           value="<?php echo e(old('contact_phone', $settings['contact_phone'])); ?>">
                    <?php $__errorArgs = ['contact_phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="invalid-feedback"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="col-md-6 mb-3">
                    <label class="form-label"><?php echo e(__('menu.support_email')); ?></label>
                    <input name="support_email" type="email" class="form-control <?php $__errorArgs = ['support_email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                           value="<?php echo e(old('support_email', $settings['support_email'])); ?>">
                    <?php $__errorArgs = ['support_email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="invalid-feedback"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>
        </div>
    </div>

    <div class="card mt-3">
        <div class="card-header">
            <h5 class="mb-0"><?php echo e(__('menu.captcha_settings')); ?></h5>
        </div>
        <div class="card-body">
            <div class="row">
                <div class="col-md-4 mb-3">
                    <label class="form-label"><?php echo e(__('menu.captcha_provider')); ?></label>
                    <select name="captcha_provider" class="form-select <?php $__errorArgs = ['captcha_provider'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required>
                        <option value="none" <?php if(old('captcha_provider', $settings['captcha_provider']) === 'none'): echo 'selected'; endif; ?>><?php echo e(__('menu.captcha_none')); ?></option>
                        <option value="google" <?php if(old('captcha_provider', $settings['captcha_provider']) === 'google'): echo 'selected'; endif; ?>>Google reCAPTCHA</option>
                        <option value="turnstile" <?php if(old('captcha_provider', $settings['captcha_provider']) === 'turnstile'): echo 'selected'; endif; ?>>Cloudflare Turnstile</option>
                    </select>
                    <?php $__errorArgs = ['captcha_provider'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="invalid-feedback"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="col-md-4 mb-3">
                    <label class="form-label"><?php echo e(__('menu.captcha_site_key')); ?></label>
                    <input name="captcha_site_key" class="form-control <?php $__errorArgs = ['captcha_site_key'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                           value="<?php echo e(old('captcha_site_key')); ?>"
                           placeholder="<?php echo e($settings['has_captcha_site_key'] ? $settings['captcha_site_key_masked'] : ''); ?>"
                           autocomplete="off">
                    <?php $__errorArgs = ['captcha_site_key'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="invalid-feedback"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    <?php if($settings['has_captcha_site_key']): ?>
                        <div class="form-text"><?php echo e(__('menu.secret_configured', ['value' => $settings['captcha_site_key_masked']])); ?></div>
                    <?php else: ?>
                        <div class="form-text text-muted"><?php echo e(__('menu.secret_not_configured')); ?></div>
                    <?php endif; ?>
                </div>
                <div class="col-md-4 mb-3">
                    <label class="form-label"><?php echo e(__('menu.captcha_secret_key')); ?></label>
                    <input type="password" name="captcha_secret_key" class="form-control <?php $__errorArgs = ['captcha_secret_key'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                           placeholder="<?php echo e($settings['has_captcha_secret'] ? $settings['captcha_secret_key_masked'] : ''); ?>"
                           autocomplete="new-password">
                    <?php $__errorArgs = ['captcha_secret_key'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="invalid-feedback"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    <?php if($settings['has_captcha_secret']): ?>
                        <div class="form-text"><?php echo e(__('menu.secret_configured', ['value' => $settings['captcha_secret_key_masked']])); ?></div>
                    <?php else: ?>
                        <div class="form-text text-muted"><?php echo e(__('menu.secret_not_configured')); ?></div>
                    <?php endif; ?>
                </div>
            </div>

            <p class="text-muted small"><?php echo e(__('menu.captcha_context_hint')); ?></p>

            <div class="row">
                <div class="col-md-3 mb-3">
                    <input type="hidden" name="registration_enabled" value="0">
                    <div class="form-check form-switch">
                        <input class="form-check-input" type="checkbox" name="registration_enabled" id="registration_enabled" value="1"
                               <?php if(old('registration_enabled', $settings['registration_enabled'])): echo 'checked'; endif; ?>>
                        <label class="form-check-label" for="registration_enabled"><?php echo e(__('menu.registration_enabled')); ?></label>
                    </div>
                </div>
                <div class="col-md-3 mb-3">
                    <input type="hidden" name="captcha_login_enabled" value="0">
                    <div class="form-check form-switch">
                        <input class="form-check-input" type="checkbox" name="captcha_login_enabled" id="captcha_login_enabled" value="1"
                               <?php if(old('captcha_login_enabled', $settings['captcha_login_enabled'])): echo 'checked'; endif; ?>>
                        <label class="form-check-label" for="captcha_login_enabled"><?php echo e(__('menu.captcha_on_login')); ?></label>
                    </div>
                </div>
                <div class="col-md-3 mb-3">
                    <input type="hidden" name="captcha_register_enabled" value="0">
                    <div class="form-check form-switch">
                        <input class="form-check-input" type="checkbox" name="captcha_register_enabled" id="captcha_register_enabled" value="1"
                               <?php if(old('captcha_register_enabled', $settings['captcha_register_enabled'])): echo 'checked'; endif; ?>>
                        <label class="form-check-label" for="captcha_register_enabled"><?php echo e(__('menu.captcha_on_register')); ?></label>
                    </div>
                </div>
                <div class="col-md-3 mb-3">
                    <input type="hidden" name="captcha_password_reset_enabled" value="0">
                    <div class="form-check form-switch">
                        <input class="form-check-input" type="checkbox" name="captcha_password_reset_enabled" id="captcha_password_reset_enabled" value="1"
                               <?php if(old('captcha_password_reset_enabled', $settings['captcha_password_reset_enabled'])): echo 'checked'; endif; ?>>
                        <label class="form-check-label" for="captcha_password_reset_enabled"><?php echo e(__('menu.captcha_on_password_reset')); ?></label>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="card mt-3">
        <div class="card-header">
            <h5 class="mb-0"><?php echo e(__('menu.oauth_settings')); ?></h5>
        </div>
        <div class="card-body">
            <p class="text-muted small"><?php echo e(__('menu.oauth_settings_hint')); ?></p>
            <div class="row">
                <div class="col-lg-6 mb-4">
                    <h6 class="mb-3">Google</h6>
                    <input type="hidden" name="oauth_google_enabled" value="0">
                    <div class="form-check form-switch mb-3">
                        <input class="form-check-input" type="checkbox" name="oauth_google_enabled" id="oauth_google_enabled" value="1"
                               <?php if(old('oauth_google_enabled', $settings['oauth_google_enabled'])): echo 'checked'; endif; ?>>
                        <label class="form-check-label" for="oauth_google_enabled"><?php echo e(__('menu.oauth_enabled')); ?></label>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Client ID</label>
                        <input name="oauth_google_client_id" class="form-control"
                               value="<?php echo e(old('oauth_google_client_id', $settings['oauth_google_client_id'])); ?>">
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Client Secret</label>
                        <input type="password" name="oauth_google_client_secret" class="form-control"
                               placeholder="<?php echo e($settings['has_oauth_google_secret'] ? '••••••••' : ''); ?>">
                    </div>
                    <div class="form-text"><?php echo e(__('menu.oauth_redirect')); ?>: <code><?php echo e($settings['oauth_google_redirect']); ?></code></div>
                </div>
                <div class="col-lg-6 mb-4">
                    <h6 class="mb-3">Microsoft</h6>
                    <input type="hidden" name="oauth_microsoft_enabled" value="0">
                    <div class="form-check form-switch mb-3">
                        <input class="form-check-input" type="checkbox" name="oauth_microsoft_enabled" id="oauth_microsoft_enabled" value="1"
                               <?php if(old('oauth_microsoft_enabled', $settings['oauth_microsoft_enabled'])): echo 'checked'; endif; ?>>
                        <label class="form-check-label" for="oauth_microsoft_enabled"><?php echo e(__('menu.oauth_enabled')); ?></label>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Client ID</label>
                        <input name="oauth_microsoft_client_id" class="form-control"
                               value="<?php echo e(old('oauth_microsoft_client_id', $settings['oauth_microsoft_client_id'])); ?>">
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Client Secret</label>
                        <input type="password" name="oauth_microsoft_client_secret" class="form-control"
                               placeholder="<?php echo e($settings['has_oauth_microsoft_secret'] ? '••••••••' : ''); ?>">
                    </div>
                    <div class="form-text"><?php echo e(__('menu.oauth_redirect')); ?>: <code><?php echo e($settings['oauth_microsoft_redirect']); ?></code></div>
                </div>
            </div>
            <div class="row">
                <div class="col-md-6 mb-3">
                    <input type="hidden" name="oauth_allow_login" value="0">
                    <div class="form-check form-switch">
                        <input class="form-check-input" type="checkbox" name="oauth_allow_login" id="oauth_allow_login" value="1"
                               <?php if(old('oauth_allow_login', $settings['oauth_allow_login'])): echo 'checked'; endif; ?>>
                        <label class="form-check-label" for="oauth_allow_login"><?php echo e(__('menu.oauth_allow_login')); ?></label>
                    </div>
                </div>
                <div class="col-md-6 mb-3">
                    <input type="hidden" name="oauth_allow_register" value="0">
                    <div class="form-check form-switch">
                        <input class="form-check-input" type="checkbox" name="oauth_allow_register" id="oauth_allow_register" value="1"
                               <?php if(old('oauth_allow_register', $settings['oauth_allow_register'])): echo 'checked'; endif; ?>>
                        <label class="form-check-label" for="oauth_allow_register"><?php echo e(__('menu.oauth_allow_register')); ?></label>
                    </div>
                </div>
            </div>
            <hr>
            <h6 class="mb-3"><?php echo e(__('menu.branding')); ?></h6>
            <div class="row">
                <div class="col-md-6 mb-3">
                    <label class="form-label"><?php echo e(__('menu.site_logo')); ?></label>
                    <input type="file" name="site_logo" class="form-control" accept="image/*">
                    <?php if($settings['site_logo_path']): ?>
                        <div class="form-text mt-1"><?php echo e(__('menu.logo_uploaded_hint')); ?></div>
                    <?php endif; ?>
                </div>
                <div class="col-md-6 mb-3">
                    <label class="form-label"><?php echo e(__('menu.site_favicon')); ?></label>
                    <input type="file" name="site_favicon" class="form-control" accept="image/*,.ico">
                    <?php if($settings['site_favicon_path']): ?><img src="<?php echo e(\App\Support\Branding::faviconUrl()); ?>" class="mt-2" style="height:24px"><?php endif; ?>
                </div>
                <div class="col-md-3 mb-3">
                    <label class="form-label" for="site_logo_height"><?php echo e(__('menu.site_logo_height')); ?></label>
                    <div class="input-group">
                        <input type="number" id="site_logo_height" name="site_logo_height" class="form-control"
                               min="16" max="160" step="1"
                               value="<?php echo e(old('site_logo_height', $settings['site_logo_height'])); ?>" required>
                        <span class="input-group-text">px</span>
                    </div>
                    <div class="form-text"><?php echo e(__('menu.site_logo_height_hint')); ?></div>
                    <?php $__errorArgs = ['site_logo_height'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="text-danger small"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="col-md-3 mb-3">
                    <label class="form-label" for="site_logo_height_register"><?php echo e(__('menu.site_logo_height_register')); ?></label>
                    <div class="input-group">
                        <input type="number" id="site_logo_height_register" name="site_logo_height_register" class="form-control"
                               min="16" max="120" step="1"
                               value="<?php echo e(old('site_logo_height_register', $settings['site_logo_height_register'])); ?>" required>
                        <span class="input-group-text">px</span>
                    </div>
                    <div class="form-text"><?php echo e(__('menu.site_logo_height_register_hint')); ?></div>
                    <?php $__errorArgs = ['site_logo_height_register'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="text-danger small"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="col-md-3 mb-3">
                    <label class="form-label" for="site_sidebar_logo_height"><?php echo e(__('menu.site_sidebar_logo_height')); ?></label>
                    <div class="input-group">
                        <input type="number" id="site_sidebar_logo_height" name="site_sidebar_logo_height" class="form-control"
                               min="16" max="120" step="1"
                               value="<?php echo e(old('site_sidebar_logo_height', $settings['site_sidebar_logo_height'])); ?>" required>
                        <span class="input-group-text">px</span>
                    </div>
                    <div class="form-text"><?php echo e(__('menu.site_sidebar_logo_height_hint')); ?></div>
                    <?php $__errorArgs = ['site_sidebar_logo_height'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="text-danger small"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="col-md-3 mb-3">
                    <label class="form-label" for="site_sidebar_brand_height"><?php echo e(__('menu.site_sidebar_brand_height')); ?></label>
                    <div class="input-group">
                        <input type="number" id="site_sidebar_brand_height" name="site_sidebar_brand_height" class="form-control"
                               min="40" max="160" step="1"
                               value="<?php echo e(old('site_sidebar_brand_height', $settings['site_sidebar_brand_height'])); ?>" required>
                        <span class="input-group-text">px</span>
                    </div>
                    <div class="form-text"><?php echo e(__('menu.site_sidebar_brand_height_hint')); ?></div>
                    <?php $__errorArgs = ['site_sidebar_brand_height'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="text-danger small"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <?php if($settings['site_logo_path']): ?>
                <div class="col-md-6 mb-3">
                    <label class="form-label text-muted small"><?php echo e(__('menu.site_logo_height')); ?> — <?php echo e(__('menu.email_template_preview')); ?></label>
                    <div class="border rounded bg-body-tertiary p-3 text-center">
                        <img src="<?php echo e(\App\Support\Branding::logoUrl()); ?>" alt="" id="siteLogoPreview"
                             style="height: <?php echo e(old('site_logo_height', $settings['site_logo_height'])); ?>px; width: auto; object-fit: contain;">
                    </div>
                </div>
                <div class="col-md-6 mb-3">
                    <label class="form-label text-muted small"><?php echo e(__('menu.site_logo_height_register')); ?> — <?php echo e(__('menu.email_template_preview')); ?></label>
                    <div class="border rounded bg-body-tertiary p-3 text-center" style="max-width: 280px;">
                        <img src="<?php echo e(\App\Support\Branding::logoUrl()); ?>" alt="" id="registerLogoPreview"
                             style="height: <?php echo e(old('site_logo_height_register', $settings['site_logo_height_register'])); ?>px; width: auto; max-width: 100%; object-fit: contain;">
                    </div>
                </div>
                <div class="col-12 mb-3">
                    <label class="form-label text-muted small"><?php echo e(__('menu.sidebar_brand_preview')); ?></label>
                    <div id="sidebarBrandPreview" class="border rounded bg-dark d-flex align-items-center px-3"
                         style="width: 220px; height: <?php echo e(old('site_sidebar_brand_height', $settings['site_sidebar_brand_height'])); ?>px;">
                        <img src="<?php echo e(\App\Support\Branding::logoUrl()); ?>" alt="" id="sidebarLogoPreview"
                             style="height: <?php echo e(old('site_sidebar_logo_height', $settings['site_sidebar_logo_height'])); ?>px; max-height: calc(100% - 8px); width: auto; object-fit: contain;">
                    </div>
                </div>
                <?php endif; ?>
            </div>
            <?php if($settings['site_logo_path']): ?>
            <?php $__env->startPush('scripts'); ?>
            <script>
            document.getElementById('site_logo_height')?.addEventListener('input', function () {
                const preview = document.getElementById('siteLogoPreview');
                if (preview) preview.style.height = this.value + 'px';
            });
            document.getElementById('site_logo_height_register')?.addEventListener('input', function () {
                const preview = document.getElementById('registerLogoPreview');
                if (preview) preview.style.height = this.value + 'px';
            });
            document.getElementById('site_sidebar_logo_height')?.addEventListener('input', function () {
                const preview = document.getElementById('sidebarLogoPreview');
                if (preview) preview.style.height = this.value + 'px';
            });
            document.getElementById('site_sidebar_brand_height')?.addEventListener('input', function () {
                const bar = document.getElementById('sidebarBrandPreview');
                if (bar) bar.style.height = this.value + 'px';
            });
            </script>
            <?php $__env->stopPush(); ?>
            <?php endif; ?>
            <hr>
            <h6 class="mb-3"><?php echo e(__('menu.default_company_info')); ?></h6>
            <div class="row">
                <div class="col-md-6 mb-3"><label class="form-label"><?php echo e(__('menu.company_name')); ?></label><input name="default_company_name" class="form-control" value="<?php echo e(old('default_company_name', $settings['default_company_name'])); ?>"></div>
                <div class="col-md-6 mb-3"><label class="form-label"><?php echo e(__('menu.company_tax_number')); ?></label><input name="default_company_tax_number" class="form-control" value="<?php echo e(old('default_company_tax_number', $settings['default_company_tax_number'])); ?>"></div>
                <div class="col-md-6 mb-3"><label class="form-label"><?php echo e(__('menu.company_phone')); ?></label><input name="default_company_phone" class="form-control" value="<?php echo e(old('default_company_phone', $settings['default_company_phone'])); ?>"></div>
                <div class="col-md-6 mb-3"><label class="form-label"><?php echo e(__('menu.company_email')); ?></label><input name="default_company_email" class="form-control" value="<?php echo e(old('default_company_email', $settings['default_company_email'])); ?>"></div>
                <div class="col-12 mb-3"><label class="form-label"><?php echo e(__('menu.company_address')); ?></label><textarea name="default_company_address" class="form-control" rows="2"><?php echo e(old('default_company_address', $settings['default_company_address'])); ?></textarea></div>
            </div>
        </div>
    </div>

    <div class="card mt-3">
        <div class="card-header border-bottom-0 pb-0">
            <h5 class="mb-3"><?php echo e(__('menu.notification_templates')); ?></h5>
            <ul class="nav nav-tabs card-header-tabs" id="notificationTemplateTabs" role="tablist">
                <li class="nav-item" role="presentation">
                    <button class="nav-link active" id="tab-verification" data-bs-toggle="tab" data-bs-target="#pane-verification" type="button" role="tab">
                        <?php echo e(__('menu.notification_tab_verification')); ?>

                    </button>
                </li>
                <li class="nav-item" role="presentation">
                    <button class="nav-link" id="tab-password-reset" data-bs-toggle="tab" data-bs-target="#pane-password-reset" type="button" role="tab">
                        <?php echo e(__('menu.notification_tab_password_reset')); ?>

                    </button>
                </li>
                <li class="nav-item" role="presentation">
                    <button class="nav-link" id="tab-staff-invitation" data-bs-toggle="tab" data-bs-target="#pane-staff-invitation" type="button" role="tab">
                        <?php echo e(__('menu.notification_tab_staff_invitation')); ?>

                    </button>
                </li>
                <li class="nav-item" role="presentation">
                    <button class="nav-link" id="tab-two-factor" data-bs-toggle="tab" data-bs-target="#pane-two-factor" type="button" role="tab">
                        <?php echo e(__('menu.notification_tab_two_factor')); ?>

                    </button>
                </li>
            </ul>
        </div>
        <div class="card-body">
            <div class="tab-content">
                <div class="tab-pane fade show active" id="pane-verification" role="tabpanel">
                    <?php echo $__env->make('theme::partials.notification-template-fields', [
                        'expiresName' => 'verification_link_expires_minutes',
                        'expiresValue' => $settings['verification_link_expires_minutes'],
                        'subjectName' => 'email_verification_subject',
                        'subjectValue' => $settings['email_verification_subject'],
                        'bodyName' => 'email_verification_body',
                        'bodyValue' => $settings['email_verification_body'],
                        'hint' => __('menu.email_template_hint_verification'),
                        'previewKey' => 'verification',
                    ], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                </div>
                <div class="tab-pane fade" id="pane-password-reset" role="tabpanel">
                    <?php echo $__env->make('theme::partials.notification-template-fields', [
                        'expiresName' => 'password_reset_expires_minutes',
                        'expiresValue' => $settings['password_reset_expires_minutes'],
                        'subjectName' => 'password_reset_subject',
                        'subjectValue' => $settings['password_reset_subject'],
                        'bodyName' => 'password_reset_body',
                        'bodyValue' => $settings['password_reset_body'],
                        'hint' => __('menu.email_template_hint_password_reset'),
                        'previewKey' => 'password_reset',
                    ], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                </div>
                <div class="tab-pane fade" id="pane-staff-invitation" role="tabpanel">
                    <?php echo $__env->make('theme::partials.notification-template-fields', [
                        'expiresName' => 'staff_invitation_expires_minutes',
                        'expiresValue' => $settings['staff_invitation_expires_minutes'],
                        'subjectName' => 'staff_invitation_subject',
                        'subjectValue' => $settings['staff_invitation_subject'],
                        'bodyName' => 'staff_invitation_body',
                        'bodyValue' => $settings['staff_invitation_body'],
                        'hint' => __('menu.email_template_hint_staff_invitation'),
                        'previewKey' => 'staff_invitation',
                    ], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                </div>
                <div class="tab-pane fade" id="pane-two-factor" role="tabpanel">
                    <h6 class="text-muted mb-3"><?php echo e(__('menu.two_factor_enabled_template')); ?></h6>
                    <?php echo $__env->make('theme::partials.notification-template-fields', [
                        'subjectName' => 'two_factor_enabled_subject',
                        'subjectValue' => $settings['two_factor_enabled_subject'],
                        'bodyName' => 'two_factor_enabled_body',
                        'bodyValue' => $settings['two_factor_enabled_body'],
                        'hint' => __('menu.email_template_hint_two_factor'),
                        'previewKey' => 'two_factor_enabled',
                    ], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                    <hr>
                    <h6 class="text-muted mb-3"><?php echo e(__('menu.two_factor_disabled_template')); ?></h6>
                    <?php echo $__env->make('theme::partials.notification-template-fields', [
                        'subjectName' => 'two_factor_disabled_subject',
                        'subjectValue' => $settings['two_factor_disabled_subject'],
                        'bodyName' => 'two_factor_disabled_body',
                        'bodyValue' => $settings['two_factor_disabled_body'],
                        'hint' => __('menu.email_template_hint_two_factor'),
                        'previewKey' => 'two_factor_disabled',
                    ], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                </div>
            </div>
        </div>
        <div class="card-footer">
            <button class="btn btn-primary"><?php echo e(__('menu.save')); ?></button>
        </div>
    </div>
</form>

<?php $__env->startPush('scripts'); ?>
<?php echo $__env->make('theme::partials.notification-template-preview-script', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('theme::layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\faltun\Desktop\Menu-One\themes/adminlte4/pages/platform/settings/site.blade.php ENDPATH**/ ?>