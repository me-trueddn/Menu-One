

<?php $__env->startSection('content'); ?>
<div class="login-form-container">
    <div class="mb-4 text-center">
        <a href="<?php echo e(route('home')); ?>"><img src="<?php echo e(\App\Support\Branding::logoUrl()); ?>" alt="<?php echo e(config('app.name')); ?>" style="height: <?php echo e(\App\Support\Branding::logoHeight()); ?>px;"></a>
    </div>
    <div class="card shadow-sm">
        <div class="card-body p-4">
            <h4 class="mb-3"><?php echo e(__('menu.verify_email_title')); ?></h4>
            <p class="text-muted"><?php echo e(__('menu.verify_email_hint', ['email' => $email ?? ''])); ?></p>

            <?php if(session('success')): ?>
                <div class="alert alert-success"><?php echo e(session('success')); ?></div>
            <?php endif; ?>

            <form method="POST" action="<?php echo e(route('verification.resend')); ?>">
                <?php echo csrf_field(); ?>
                <button type="submit" class="btn btn-primary"><?php echo e(__('menu.resend_verification')); ?></button>
            </form>

            <a href="<?php echo e(route('login')); ?>" class="btn btn-link mt-3"><?php echo e(__('menu.back_to_login')); ?></a>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('theme::layouts.auth', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\faltun\Desktop\Menu-One\themes/adminlte4/pages/auth/verify-email.blade.php ENDPATH**/ ?>