<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames(([
    'invitations',
    'revokeRoute',
]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter(([
    'invitations',
    'revokeRoute',
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<div class="card mt-3">
    <div class="card-header">
        <h6 class="mb-0"><?php echo e(__('menu.staff_invitations')); ?></h6>
    </div>
    <div class="card-body p-0">
        <div class="table-responsive">
            <table class="table table-sm mb-0">
                <thead>
                    <tr>
                        <th><?php echo e(__('menu.full_name')); ?></th>
                        <th><?php echo e(__('menu.email')); ?></th>
                        <th><?php echo e(__('menu.role')); ?></th>
                        <th><?php echo e(__('menu.invitation_sent_at')); ?></th>
                        <th><?php echo e(__('menu.expires_at')); ?></th>
                        <th><?php echo e(__('menu.status')); ?></th>
                        <th class="text-end"><?php echo e(__('menu.actions')); ?></th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $invitations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $invitation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td><?php echo e($invitation->user->name); ?></td>
                            <td><?php echo e($invitation->user->email); ?></td>
                            <td><?php echo e(__('menu.role_'.$invitation->role)); ?></td>
                            <td class="text-nowrap small text-muted">
                                <?php echo e($invitation->created_at->timezone(config('app.timezone'))->format('d.m.Y H:i')); ?>

                                <?php if($invitation->invitedBy): ?>
                                    <div class="text-muted"><?php echo e(__('menu.invited_by')); ?>: <?php echo e($invitation->invitedBy->name); ?></div>
                                <?php endif; ?>
                            </td>
                            <td class="text-nowrap small text-muted">
                                <?php echo e($invitation->expires_at->timezone(config('app.timezone'))->format('d.m.Y H:i')); ?>

                            </td>
                            <td>
                                <span class="badge <?php echo e($invitation->statusBadgeClass()); ?>"><?php echo e($invitation->statusLabel()); ?></span>
                                <?php if($invitation->status() === 'revoked' && $invitation->revokedBy): ?>
                                    <div class="small text-muted mt-1"><?php echo e($invitation->revokedBy->name); ?></div>
                                <?php endif; ?>
                            </td>
                            <td class="text-end">
                                <?php if($invitation->isPending()): ?>
                                    <form method="POST" action="<?php echo e($revokeRoute($invitation)); ?>" class="d-inline"
                                          onsubmit="return confirm('<?php echo e(__('menu.confirm_revoke_invitation')); ?>')">
                                        <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                                        <button type="submit" class="btn btn-sm btn-outline-danger"><?php echo e(__('menu.revoke_invitation')); ?></button>
                                    </form>
                                <?php else: ?>
                                    <span class="text-muted small">—</span>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="7" class="text-center text-muted py-3"><?php echo e(__('menu.no_staff_invitations')); ?></td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php /**PATH C:\Users\faltun\Desktop\Menu-One\themes/adminlte4/partials/staff-invitations-panel.blade.php ENDPATH**/ ?>