

<?php $__env->startSection('content'); ?>
<div class="locale-row">
    <?php echo $__env->make('theme::partials.auth.locale-switcher', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
</div>

<div class="brand-name">
    <a href="<?php echo e(route('home')); ?>"><img src="<?php echo e(\App\Support\Branding::logoUrl()); ?>" alt="<?php echo e(\App\Support\SiteConfig::name()); ?>" style="height: <?php echo e(\App\Support\Branding::logoHeight()); ?>px;"></a>
</div>

<h1 class="login-title"><?php echo e(__('menu.two_factor_challenge_title')); ?></h1>
<p class="login-subtitle"><?php echo e(__('menu.two_factor_challenge_hint')); ?></p>

<?php if($errors->any()): ?>
    <div class="alert alert-danger alert-login">
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div><?php echo e($error); ?></div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
<?php endif; ?>

<form method="POST" action="<?php echo e(route('two-factor.verify')); ?>">
    <?php echo csrf_field(); ?>

    <div class="mb-4">
        <input id="code" type="text" name="code" inputmode="numeric" pattern="[0-9]*" maxlength="6"
               class="form-control text-center <?php $__errorArgs = ['code'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
               placeholder="000000" autocomplete="one-time-code" required autofocus>
        <?php $__errorArgs = ['code'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="invalid-feedback"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>

    <div class="d-flex gap-3 flex-wrap">
        <button type="submit" class="btn-login"><?php echo e(__('menu.verify')); ?></button>
        <a href="<?php echo e(route('login')); ?>" class="btn-register"><?php echo e(__('menu.back_to_login')); ?></a>
    </div>
</form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('theme::layouts.auth', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\faltun\Desktop\Menu-One\resources\views/auth/two-factor-challenge.blade.php ENDPATH**/ ?>