<?php $__env->startSection('title', $table->name); ?>
<?php $__env->startSection('page-title', __('menu.table').': '.$table->name); ?>
<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-lg-5">
        <div class="card mb-3">
            <div class="card-header d-flex justify-content-between align-items-center">
                <h5 class="mb-0"><?php echo e(__('menu.reservations')); ?></h5>
                <a href="<?php echo e(route('reservations.create', ['table' => $table->id])); ?>" class="btn btn-sm btn-outline-primary"><?php echo e(__('menu.add_reservation')); ?></a>
            </div>
            <div class="card-body p-0">
                <?php $__empty_1 = true; $__currentLoopData = $upcomingReservations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reservation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <div class="border-bottom p-3">
                        <div class="d-flex justify-content-between align-items-start gap-2">
                            <div>
                                <span class="badge <?php echo e($reservation->isCurrent() ? 'text-bg-danger' : 'text-bg-warning'); ?>">
                                    <?php echo e($reservation->isCurrent() ? __('menu.reservation_in_progress') : __('menu.reservation_upcoming')); ?>

                                </span>
                                <div class="mt-2"><strong><?php echo e($reservation->guest_name); ?></strong></div>
                                <?php if($reservation->guest_phone): ?>
                                    <div class="mt-1"><?php echo $__env->make('theme::pages.reservations._call', ['reservation' => $reservation], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?></div>
                                <?php endif; ?>
                                <div><?php echo e($reservation->party_size); ?> <?php echo e(__('menu.seats')); ?></div>
                                <div class="text-muted small">
                                    <?php echo $__env->make('theme::pages.reservations._period', ['reservation' => $reservation], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                                </div>
                                <?php if($reservation->notes): ?>
                                    <div class="small text-muted mt-1"><?php echo e($reservation->notes); ?></div>
                                <?php endif; ?>
                                <div class="small text-muted mt-1">
                                    <?php echo e(__('menu.reservation_created_by')); ?>: <?php echo e($reservation->user?->name ?? '—'); ?>

                                </div>
                            </div>
                            <div class="d-flex flex-column gap-1">
                                <a href="<?php echo e(route('reservations.edit', $reservation)); ?>" class="btn btn-sm btn-outline-primary"><?php echo e(__('menu.edit')); ?></a>
                                <?php echo $__env->make('theme::pages.reservations._complete', ['reservation' => $reservation, 'block' => true], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                                <form method="POST" action="<?php echo e(route('reservations.destroy', $reservation)); ?>"
                                      onsubmit="return confirm('<?php echo e(__('menu.confirm_cancel_reservation')); ?>')">
                                    <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                                    <button type="submit" class="btn btn-sm btn-outline-danger w-100"><?php echo e(__('menu.reservation_cancel')); ?></button>
                                </form>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <p class="text-muted p-3 mb-0"><?php echo e(__('menu.no_reservations_for_table')); ?></p>
                <?php endif; ?>
            </div>
        </div>

        <div class="card mb-3">
            <div class="card-header d-flex justify-content-between align-items-center">
                <h5 class="mb-0">Adisyon</h5>
                <?php if(!$activeOrder): ?>
                    <form method="POST" action="<?php echo e(route('waiter.orders.create', $table)); ?>"><?php echo csrf_field(); ?>
                        <button class="btn btn-success btn-sm">Adisyon Aç</button>
                    </form>
                <?php endif; ?>
            </div>
            <?php if($activeOrder): ?>
            <div class="card-body p-0">
                <div class="px-3 pt-2">
                    <span class="badge <?php echo e($activeOrder->status->badgeClass()); ?>"><?php echo e($activeOrder->status->label()); ?></span>
                </div>
                <table class="table mb-0">
                    <thead><tr><th>Ürün</th><th>Adet</th><th>Durum</th><th>Tutar</th><th></th></tr></thead>
                    <tbody>
                    <?php $__currentLoopData = $activeOrder->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($item->product->name); ?></td>
                            <td>
                                <?php if($item->status->value === 'pending'): ?>
                                    <form method="POST" action="<?php echo e(route('waiter.orders.items.update', [$activeOrder, $item])); ?>"
                                          class="d-inline-flex align-items-center gap-1">
                                        <?php echo csrf_field(); ?> <?php echo method_field('PATCH'); ?>
                                        <input type="number" name="qty" value="<?php echo e(old('qty.'.$item->id, $item->qty)); ?>"
                                               min="1" max="99" class="form-control form-control-sm" style="width:4.5rem"
                                               aria-label="<?php echo e(__('menu.qty')); ?>">
                                        <button type="submit" class="btn btn-sm btn-outline-primary" title="<?php echo e(__('menu.update_qty')); ?>">
                                            <i class="bi bi-check-lg"></i>
                                        </button>
                                    </form>
                                <?php else: ?>
                                    <?php echo e($item->qty); ?>

                                <?php endif; ?>
                            </td>
                            <td><span class="badge text-bg-secondary"><?php echo e($item->status->label()); ?></span>
                                <?php if($item->status->value === 'ready'): ?>
                                <form method="POST" action="<?php echo e(route('waiter.orders.items.served', [$activeOrder, $item])); ?>" class="d-inline"><?php echo csrf_field(); ?>
                                    <button class="btn btn-xs btn-sm btn-outline-success">Servis</button>
                                </form>
                                <?php endif; ?>
                            </td>
                            <td><?php echo e(number_format($item->lineTotal(), 2)); ?> ₺</td>
                            <td class="text-end">
                                <?php if($item->status->value === 'pending'): ?>
                                <form method="POST" action="<?php echo e(route('waiter.orders.items.destroy', [$activeOrder, $item])); ?>" class="d-inline"
                                      onsubmit="return confirm('<?php echo e(__('menu.confirm_remove_item')); ?>')">
                                    <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                                    <button type="submit" class="btn btn-sm btn-outline-danger" title="<?php echo e(__('menu.remove_item')); ?>">×</button>
                                </form>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                    <tfoot><tr><th colspan="4">Toplam</th><th><?php echo e(number_format($activeOrder->total, 2)); ?> ₺</th></tr></tfoot>
                </table>
            </div>
            <div class="card-footer d-flex gap-2 flex-wrap">
                <?php if($activeOrder->status->value === 'awaiting_payment'): ?>
                    <span class="text-muted"><?php echo e(__('menu.awaiting_cashier_payment')); ?></span>
                <?php elseif($activeOrder->items->isEmpty()): ?>
                    <form method="POST" action="<?php echo e(route('waiter.orders.close', $activeOrder)); ?>"
                          onsubmit="return confirm('<?php echo e(__('menu.confirm_close_empty_bill')); ?>')"><?php echo csrf_field(); ?>
                        <button type="submit" class="btn btn-outline-secondary"><?php echo e(__('menu.close_empty_bill')); ?></button>
                    </form>
                <?php else: ?>
                <form method="POST" action="<?php echo e(route('waiter.orders.send', $activeOrder)); ?>"><?php echo csrf_field(); ?>
                    <button class="btn btn-warning"><?php echo e(__('menu.send_to_kitchen')); ?></button>
                </form>
                <form method="POST" action="<?php echo e(route('waiter.orders.request-payment', $activeOrder)); ?>"
                      onsubmit="return confirm('<?php echo e(__('menu.confirm_request_payment')); ?>')"><?php echo csrf_field(); ?>
                    <button class="btn btn-primary"><?php echo e(__('menu.close_bill')); ?></button>
                </form>
                <?php endif; ?>
            </div>
            <?php else: ?>
            <div class="card-body text-muted">Bu masada açık adisyon yok.</div>
            <?php endif; ?>
        </div>
    </div>
    <?php if($activeOrder && $activeOrder->status->value !== 'awaiting_payment'): ?>
    <div class="col-lg-7">
        <div class="card">
            <div class="card-header d-flex justify-content-between align-items-center flex-wrap gap-2">
                <h5 class="mb-0"><?php echo e(__('menu.add_product')); ?></h5>
                <input type="search" id="productSearch" class="form-control form-control-sm" style="max-width:260px"
                       placeholder="<?php echo e(__('menu.search_product')); ?>" autocomplete="off">
            </div>
            <div class="card-body" id="productPicker">
                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($category->products->count()): ?>
                    <div class="product-category mb-3" data-category="<?php echo e($category->name); ?>">
                        <h6><?php echo e($category->name); ?></h6>
                        <div class="row">
                        <?php $__currentLoopData = $category->products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-md-6 mb-2 product-item" data-name="<?php echo e(mb_strtolower($product->name)); ?>" data-category="<?php echo e(mb_strtolower($category->name)); ?>">
                                <form method="POST" action="<?php echo e(route('waiter.orders.items.store', $activeOrder)); ?>" class="border rounded p-2 h-100"><?php echo csrf_field(); ?>
                                    <input type="hidden" name="product_id" value="<?php echo e($product->id); ?>">
                                    <div class="d-flex align-items-center gap-2">
                                        <img src="<?php echo e($product->imageUrl()); ?>" alt="<?php echo e($product->name); ?>"
                                             class="product-picker-thumb flex-shrink-0 rounded">
                                        <div class="flex-grow-1 min-w-0">
                                            <div class="fw-semibold text-truncate"><?php echo e($product->name); ?></div>
                                            <div class="small text-muted"><?php echo e(number_format($product->price, 2)); ?> ₺</div>
                                        </div>
                                        <div class="d-flex gap-1 flex-shrink-0">
                                            <input type="number" name="qty" value="1" min="1" max="99" class="form-control form-control-sm" style="width:60px">
                                            <button class="btn btn-sm btn-primary">+</button>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <p id="productSearchEmpty" class="text-muted d-none mb-0"><?php echo e(__('menu.no_products_found')); ?></p>
            </div>
        </div>
    </div>
    <?php endif; ?>
</div>
<a href="<?php echo e(route('waiter.tables.index')); ?>" class="btn btn-secondary mt-2">← Masalara Dön</a>
<?php $__env->stopSection(); ?>

<?php if($activeOrder && $activeOrder->status->value !== 'awaiting_payment'): ?>
<?php $__env->startPush('styles'); ?>
<style>
    .product-picker-thumb {
        width: 52px;
        height: 52px;
        object-fit: cover;
        background: var(--bs-tertiary-bg);
    }
</style>
<?php $__env->stopPush(); ?>
<?php $__env->startPush('scripts'); ?>
<script>
document.addEventListener('DOMContentLoaded', function () {
    const input = document.getElementById('productSearch');
    const items = document.querySelectorAll('.product-item');
    const categories = document.querySelectorAll('.product-category');
    const empty = document.getElementById('productSearchEmpty');

    if (!input) return;

    input.addEventListener('input', function () {
        const q = input.value.trim().toLowerCase();
        let visible = 0;

        items.forEach(function (el) {
            const match = q === '' || el.dataset.name.includes(q) || el.dataset.category.includes(q);
            el.classList.toggle('d-none', !match);
            if (match) visible++;
        });

        categories.forEach(function (cat) {
            const hasVisible = cat.querySelector('.product-item:not(.d-none)');
            cat.classList.toggle('d-none', !hasVisible);
        });

        empty.classList.toggle('d-none', visible > 0);
    });
});
</script>
<?php $__env->stopPush(); ?>
<?php endif; ?>

<?php echo $__env->make('theme::layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\faltun\Desktop\Menu-One\themes/adminlte4/pages/waiter/tables/show.blade.php ENDPATH**/ ?>