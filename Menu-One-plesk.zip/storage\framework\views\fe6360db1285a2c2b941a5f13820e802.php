<?php if(\App\Support\CaptchaPolicy::requiredFor($context)): ?>
    <div class="mb-3 captcha-wrap">
        <?php if(\App\Support\CaptchaPolicy::provider() === 'google'): ?>
            <div class="g-recaptcha" data-sitekey="<?php echo e(\App\Support\CaptchaPolicy::siteKey()); ?>"></div>
        <?php elseif(\App\Support\CaptchaPolicy::provider() === 'turnstile'): ?>
            <div class="cf-turnstile" data-sitekey="<?php echo e(\App\Support\CaptchaPolicy::siteKey()); ?>"></div>
        <?php endif; ?>
        <?php $__errorArgs = ['captcha'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="text-danger small mt-1"><?php echo e($message); ?></div>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
    <input type="hidden" name="captcha_check" value="1">
<?php endif; ?>
<?php /**PATH C:\Users\faltun\Desktop\Menu-One\themes/adminlte4/partials/auth/captcha.blade.php ENDPATH**/ ?>