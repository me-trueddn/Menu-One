<div class="dropdown">
    <button class="btn btn-sm btn-outline-secondary dropdown-toggle" type="button" data-bs-toggle="dropdown">
        <i class="bi bi-globe"></i> <?php echo e(config('locale.names.'.app()->getLocale(), app()->getLocale())); ?>

    </button>
    <ul class="dropdown-menu dropdown-menu-end">
        <?php $__currentLoopData = config('locale.available', []); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $code): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li>
                <a class="dropdown-item <?php echo e(app()->getLocale() === $code ? 'active' : ''); ?>"
                   href="<?php echo e(route('locale.switch', $code)); ?>">
                    <?php echo e(config('locale.names.'.$code, $code)); ?>

                </a>
            </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
</div>
<?php /**PATH C:\Users\faltun\Desktop\Menu-One\themes/adminlte4/partials/locale-switcher.blade.php ENDPATH**/ ?>