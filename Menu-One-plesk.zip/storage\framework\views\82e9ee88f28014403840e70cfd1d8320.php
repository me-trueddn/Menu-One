

<?php $__env->startSection('title', 'Dashboard'); ?>
<?php $__env->startSection('page-title', 'Dashboard'); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-md-4">
        <div class="small-box text-bg-success">
            <div class="inner">
                <h3><?php echo e(number_format($dailyRevenue, 2)); ?> ₺</h3>
                <p>Bugünkü Ciro</p>
            </div>
            <i class="small-box-icon bi bi-currency-exchange"></i>
        </div>
    </div>
    <div class="col-md-4">
        <div class="small-box text-bg-warning">
            <div class="inner">
                <h3><?php echo e($openOrders); ?></h3>
                <p>Açık Adisyon</p>
            </div>
            <i class="small-box-icon bi bi-receipt"></i>
        </div>
    </div>
</div>

<div class="card">
    <div class="card-header"><h5 class="mb-0">En Çok Satan Ürünler</h5></div>
    <div class="card-body table-responsive p-0">
        <table class="table mb-0">
            <thead><tr><th>Ürün</th><th>Adet</th><th>Ciro</th></tr></thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $topProducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td><?php echo e($row->product?->name ?? '-'); ?></td>
                        <td><?php echo e($row->total_qty); ?></td>
                        <td><?php echo e(number_format($row->total_revenue, 2)); ?> ₺</td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr><td colspan="3" class="text-muted text-center">Veri yok</td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('theme::layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\faltun\Desktop\Menu-One\themes/adminlte4/pages/admin/dashboard.blade.php ENDPATH**/ ?>