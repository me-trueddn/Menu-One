<tr>
    <td><?php echo e($table->name); ?></td>
    <td><?php echo e($table->capacity); ?></td>
    <td><span class="badge <?php echo e($table->status->badgeClass()); ?>"><?php echo e($table->status->label()); ?></span></td>
    <td class="text-end">
        <a href="<?php echo e(route('admin.tables.edit', $table)); ?>" class="btn btn-sm btn-outline-primary"><?php echo e(__('menu.edit')); ?></a>
        <form action="<?php echo e(route('admin.tables.destroy', $table)); ?>" method="POST" class="d-inline"
              onsubmit="return confirm('<?php echo e(__('menu.confirm_delete')); ?>')">
            <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
            <button class="btn btn-sm btn-outline-danger"><?php echo e(__('menu.delete')); ?></button>
        </form>
    </td>
</tr>
<?php /**PATH C:\Users\faltun\Desktop\Menu-One\themes/adminlte4/partials/admin/table-row.blade.php ENDPATH**/ ?>