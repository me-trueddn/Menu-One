

<?php $__env->startSection('title', __('menu.edit_table')); ?>
<?php $__env->startSection('page-title', __('menu.edit_table')); ?>

<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="card-body">
        <form method="POST" action="<?php echo e(route('admin.tables.update', $table)); ?>">
            <?php echo csrf_field(); ?> <?php echo method_field('PUT'); ?>
            <?php if($tableCategories->isNotEmpty()): ?>
                <div class="mb-3">
                    <label class="form-label" for="tableCategory"><?php echo e(__('menu.table_category')); ?></label>
                    <select id="tableCategory" name="table_category_id" class="form-select">
                        <option value=""><?php echo e(__('menu.no_table_category')); ?></option>
                        <?php $__currentLoopData = $tableCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($category->id); ?>" <?php if((string) old('table_category_id', $table->table_category_id) === (string) $category->id): echo 'selected'; endif; ?>>
                                <?php echo e($category->name); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <?php $__errorArgs = ['table_category_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="text-danger small"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            <?php endif; ?>
            <div class="mb-3">
                <label class="form-label" for="tableName"><?php echo e(__('menu.table_name')); ?></label>
                <input id="tableName" name="name" class="form-control" value="<?php echo e(old('name', $table->name)); ?>" required>
                <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="text-danger small"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="mb-3">
                <label class="form-label" for="tableCapacity"><?php echo e(__('menu.table_capacity_label')); ?></label>
                <input id="tableCapacity" type="number" name="capacity" class="form-control" value="<?php echo e(old('capacity', $table->capacity)); ?>" min="1" required>
                <?php $__errorArgs = ['capacity'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="text-danger small"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="mb-3">
                <label class="form-label" for="tableStatus"><?php echo e(__('menu.table_status')); ?></label>
                <select id="tableStatus" name="status" class="form-select">
                    <?php $__currentLoopData = $statuses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($status->value); ?>" <?php if(old('status', $table->status->value) === $status->value): echo 'selected'; endif; ?>><?php echo e($status->label()); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php $__errorArgs = ['status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="text-danger small"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <button class="btn btn-primary"><?php echo e(__('menu.save')); ?></button>
            <a href="<?php echo e(route('admin.tables.index')); ?>" class="btn btn-secondary"><?php echo e(__('menu.cancel')); ?></a>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('theme::layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\faltun\Desktop\Menu-One\themes/adminlte4/pages/admin/tables/edit.blade.php ENDPATH**/ ?>