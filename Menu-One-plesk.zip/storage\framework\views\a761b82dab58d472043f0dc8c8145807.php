<aside class="app-sidebar bg-body-secondary shadow" data-bs-theme="dark">
    <div class="sidebar-brand">
        <?php echo $__env->make('theme::partials.brand-logo', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    </div>
    <div class="sidebar-wrapper">
        <nav class="mt-2">
            <ul class="nav sidebar-menu flex-column" role="menu">
                <?php ($inSupportMode = !empty($inSupportMode)); ?>

                <?php if($inSupportMode): ?>
                    <li class="nav-header"><?php echo e(__('menu.support_mode')); ?></li>
                    <li class="nav-item">
                        <form method="POST" action="<?php echo e(route('platform.support.disconnect')); ?>" class="w-100">
                            <?php echo csrf_field(); ?>
                            <button type="submit" class="nav-link btn btn-link text-start w-100 text-warning border-0">
                                <i class="nav-icon bi bi-box-arrow-left"></i>
                                <p><?php echo e(__('menu.exit_support')); ?></p>
                            </button>
                        </form>
                    </li>
                <?php endif; ?>

                <?php if($currentUser->canAccessPlatformPanel() && ! $inSupportMode): ?>
                    <li class="nav-header"><?php echo e(__('menu.management')); ?></li>
                    <?php $__currentLoopData = config('platform_modules.modules', []); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $moduleKey => $module): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($currentUser->canPlatformModule($moduleKey, 'view')): ?>
                            <li class="nav-item">
                                <a href="<?php echo e(route($module['route'])); ?>" class="nav-link <?php echo e(collect($module['route_patterns'] ?? [])->contains(fn ($p) => request()->routeIs($p)) ? 'active' : ''); ?>">
                                    <i class="nav-icon bi <?php echo e($module['icon']); ?>"></i>
                                    <p><?php echo e(__($module['label'])); ?></p>
                                </a>
                            </li>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>

                <?php if($currentUser->showsCafeSidebar()): ?>
                    <li class="nav-header"><?php echo e(__('menu.management')); ?></li>
                    <li class="nav-item">
                        <a href="<?php echo e(route('admin.dashboard')); ?>" class="nav-link <?php echo e(request()->routeIs('admin.dashboard') ? 'active' : ''); ?>">
                            <i class="nav-icon bi bi-speedometer2"></i>
                            <p><?php echo e(__('menu.dashboard')); ?></p>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="<?php echo e(route('admin.tables.index')); ?>" class="nav-link <?php echo e(request()->routeIs('admin.tables.*', 'admin.table-categories.*') ? 'active' : ''); ?>">
                            <i class="nav-icon bi bi-grid-3x3"></i>
                            <p><?php echo e(__('menu.tables')); ?></p>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="<?php echo e(route('admin.categories.index')); ?>" class="nav-link <?php echo e(request()->routeIs('admin.categories.*') ? 'active' : ''); ?>">
                            <i class="nav-icon bi bi-tags"></i>
                            <p><?php echo e(__('menu.categories')); ?></p>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="<?php echo e(route('admin.products.index')); ?>" class="nav-link <?php echo e(request()->routeIs('admin.products.*') ? 'active' : ''); ?>">
                            <i class="nav-icon bi bi-cup-hot"></i>
                            <p><?php echo e(__('menu.products')); ?></p>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="<?php echo e(route('admin.operations.index')); ?>" class="nav-link <?php echo e(request()->routeIs('admin.operations.*') ? 'active' : ''); ?>">
                            <i class="nav-icon bi bi-activity"></i>
                            <p><?php echo e(__('menu.operations')); ?></p>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="<?php echo e(route('kitchen.index')); ?>" class="nav-link <?php echo e(request()->routeIs('kitchen.*') ? 'active' : ''); ?>">
                            <i class="nav-icon bi bi-fire"></i>
                            <p><?php echo e(__('menu.kitchen')); ?></p>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="<?php echo e(route('cashier.tables.index')); ?>" class="nav-link <?php echo e(request()->routeIs('cashier.*') ? 'active' : ''); ?>">
                            <i class="nav-icon bi bi-cash-coin"></i>
                            <p><?php echo e(__('menu.cashier')); ?></p>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="<?php echo e(route('reservations.index')); ?>" class="nav-link <?php echo e(request()->routeIs('reservations.*') ? 'active' : ''); ?>">
                            <i class="nav-icon bi bi-calendar-check"></i>
                            <p><?php echo e(__('menu.reservations')); ?></p>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="<?php echo e(route('waiter.tables.index')); ?>" class="nav-link <?php echo e(request()->routeIs('waiter.*') ? 'active' : ''); ?>">
                            <i class="nav-icon bi bi-cup-straw"></i>
                            <p><?php echo e(__('menu.waiter')); ?></p>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="<?php echo e(route('admin.staff.index')); ?>" class="nav-link <?php echo e(request()->routeIs('admin.staff.*') ? 'active' : ''); ?>">
                            <i class="nav-icon bi bi-people"></i>
                            <p><?php echo e(__('menu.staff')); ?></p>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="<?php echo e(route('admin.reports.index')); ?>" class="nav-link <?php echo e(request()->routeIs('admin.reports.*') ? 'active' : ''); ?>">
                            <i class="nav-icon bi bi-bar-chart"></i>
                            <p><?php echo e(__('menu.reports')); ?></p>
                        </a>
                    </li>
                <?php endif; ?>

                <?php if($currentUser->hasRole('waiter') && ! $currentUser->hasRole('cashier')): ?>
                    <li class="nav-header"><?php echo e(__('menu.waiter')); ?></li>
                    <li class="nav-item">
                        <a href="<?php echo e(route('waiter.tables.index')); ?>" class="nav-link <?php echo e(request()->routeIs('waiter.tables.*') ? 'active' : ''); ?>">
                            <i class="nav-icon bi bi-grid-3x3"></i>
                            <p><?php echo e(__('menu.tables')); ?></p>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="<?php echo e(route('reservations.index')); ?>" class="nav-link <?php echo e(request()->routeIs('reservations.*') ? 'active' : ''); ?>">
                            <i class="nav-icon bi bi-calendar-check"></i>
                            <p><?php echo e(__('menu.reservations')); ?></p>
                        </a>
                    </li>
                <?php endif; ?>

                <?php if($currentUser->hasRole('cashier')): ?>
                    <li class="nav-header"><?php echo e(__('menu.cashier')); ?></li>
                    <li class="nav-item">
                        <a href="<?php echo e(route('cashier.tables.index')); ?>" class="nav-link <?php echo e(request()->routeIs('cashier.*') ? 'active' : ''); ?>">
                            <i class="nav-icon bi bi-cash-coin"></i>
                            <p><?php echo e(__('menu.cashier_tables')); ?></p>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="<?php echo e(route('reservations.index')); ?>" class="nav-link <?php echo e(request()->routeIs('reservations.*') ? 'active' : ''); ?>">
                            <i class="nav-icon bi bi-calendar-check"></i>
                            <p><?php echo e(__('menu.reservations')); ?></p>
                        </a>
                    </li>
                <?php endif; ?>

                <?php if($currentUser->hasRole('kitchen')): ?>
                    <li class="nav-header"><?php echo e(__('menu.kitchen')); ?></li>
                    <li class="nav-item">
                        <a href="<?php echo e(route('kitchen.index')); ?>" class="nav-link <?php echo e(request()->routeIs('kitchen.*') ? 'active' : ''); ?>">
                            <i class="nav-icon bi bi-fire"></i>
                            <p><?php echo e(__('menu.orders')); ?></p>
                        </a>
                    </li>
                <?php endif; ?>
            </ul>
        </nav>
    </div>
</aside>
<?php /**PATH C:\Users\faltun\Desktop\Menu-One\themes/adminlte4/partials/sidebar.blade.php ENDPATH**/ ?>