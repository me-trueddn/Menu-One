<?php if(!empty($isImpersonating)): ?>
<div class="impersonation-banner alert alert-warning border-0 rounded-0 mb-0 py-2 px-3 d-flex align-items-center justify-content-between flex-wrap gap-2">
    <div class="d-flex align-items-center gap-2">
        <i class="bi bi-person-badge"></i>
        <span><?php echo e(__('menu.impersonating_as', ['name' => auth()->user()->name, 'email' => auth()->user()->email])); ?></span>
    </div>
    <form method="POST" action="<?php echo e(route('impersonation.leave')); ?>" class="mb-0">
        <?php echo csrf_field(); ?>
        <button type="submit" class="btn btn-sm btn-dark">
            <i class="bi bi-box-arrow-left"></i> <?php echo e(__('menu.exit_impersonation')); ?>

        </button>
    </form>
</div>
<?php endif; ?>
<?php /**PATH C:\Users\faltun\Desktop\Menu-One\themes/adminlte4/partials/impersonation-banner.blade.php ENDPATH**/ ?>