<a href="<?php echo e(route('home')); ?>" class="brand-link d-flex align-items-center gap-2 text-decoration-none">
    <img src="<?php echo e(\App\Support\Branding::cafeLogoUrl()); ?>" alt="<?php echo e(config('app.name')); ?>" class="sidebar-brand-logo">
</a>
<?php /**PATH C:\Users\faltun\Desktop\Menu-One\themes/adminlte4/partials/brand-logo.blade.php ENDPATH**/ ?>