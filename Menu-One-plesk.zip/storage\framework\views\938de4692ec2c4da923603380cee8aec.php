<?php
    $isPublicPage = $isPublicPage ?? true;
    $gtmId = \App\Support\SeoPolicy::tagManagerId();
    $yandexMetrikaId = \App\Support\SeoPolicy::yandexMetrikaId();
?>
<?php if(\App\Support\SeoPolicy::shouldInject($isPublicPage) && $gtmId !== ''): ?>
    <noscript><iframe src="https://www.googletagmanager.com/ns.html?id=<?php echo e($gtmId); ?>"
        height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
<?php endif; ?>
<?php if(\App\Support\SeoPolicy::shouldInject($isPublicPage) && $yandexMetrikaId !== ''): ?>
    <noscript><div><img src="https://mc.yandex.ru/watch/<?php echo e($yandexMetrikaId); ?>" style="position:absolute; left:-9999px;" alt=""></div></noscript>
<?php endif; ?>
<?php /**PATH C:\Users\faltun\Desktop\Menu-One\themes/adminlte4/partials/seo-body.blade.php ENDPATH**/ ?>