<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames(([
    'expiresName' => null,
    'expiresValue' => null,
    'subjectName',
    'subjectValue',
    'bodyName',
    'bodyValue',
    'hint',
    'previewKey' => null,
]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter(([
    'expiresName' => null,
    'expiresValue' => null,
    'subjectName',
    'subjectValue',
    'bodyName',
    'bodyValue',
    'hint',
    'previewKey' => null,
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<div class="row notification-template-fields" <?php if($previewKey): ?> data-preview-key="<?php echo e($previewKey); ?>" <?php endif; ?>>
    <?php if($expiresName): ?>
        <div class="col-md-4 mb-3">
            <label class="form-label" for="<?php echo e($expiresName); ?>"><?php echo e(__('menu.link_expires_minutes')); ?></label>
            <input type="number" id="<?php echo e($expiresName); ?>" name="<?php echo e($expiresName); ?>" class="form-control notification-expires-input"
                   min="5" max="10080" value="<?php echo e(old($expiresName, $expiresValue)); ?>">
        </div>
        <div class="col-md-8 mb-3">
            <label class="form-label" for="<?php echo e($subjectName); ?>"><?php echo e(__('menu.email_subject')); ?></label>
            <input id="<?php echo e($subjectName); ?>" name="<?php echo e($subjectName); ?>" class="form-control notification-subject-input"
                   value="<?php echo e(old($subjectName, $subjectValue)); ?>">
        </div>
    <?php else: ?>
        <div class="col-12 mb-3">
            <label class="form-label" for="<?php echo e($subjectName); ?>"><?php echo e(__('menu.email_subject')); ?></label>
            <input id="<?php echo e($subjectName); ?>" name="<?php echo e($subjectName); ?>" class="form-control notification-subject-input"
                   value="<?php echo e(old($subjectName, $subjectValue)); ?>">
        </div>
    <?php endif; ?>
    <div class="col-lg-6 mb-3">
        <label class="form-label" for="<?php echo e($bodyName); ?>"><?php echo e(__('menu.email_body')); ?></label>
        <textarea id="<?php echo e($bodyName); ?>" name="<?php echo e($bodyName); ?>" class="form-control font-monospace notification-body-input" rows="14"><?php echo e(old($bodyName, $bodyValue)); ?></textarea>
        <div class="form-text"><?php echo e($hint); ?></div>
    </div>
    <?php if($previewKey): ?>
        <div class="col-lg-6 mb-3">
            <label class="form-label text-muted small"><?php echo e(__('menu.email_template_preview')); ?></label>
            <div class="email-template-preview-panel border rounded bg-body-tertiary p-3 h-100">
                <div class="small text-muted mb-2">
                    <span class="fw-semibold"><?php echo e(__('menu.email_template_preview_subject')); ?>:</span>
                    <span class="notification-preview-subject" data-preview-subject></span>
                </div>
                <div class="notification-preview-body bg-white border rounded p-3 overflow-auto" data-preview-body style="min-height: 320px; max-height: 420px;"></div>
            </div>
        </div>
    <?php endif; ?>
</div>
<?php /**PATH C:\Users\faltun\Desktop\Menu-One\themes/adminlte4/partials/notification-template-fields.blade.php ENDPATH**/ ?>